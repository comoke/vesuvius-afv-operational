# Guarded autowind crop runner (opt-in source candidate)

This opt-in runner freezes an admitted local autowind crop plan, runs one or two isolated crop workers, verifies committed checkpoints, and asks upstream autowind to assemble them. It does not change the default `autowind chains` command. Upstream already provides parallel crop workers and basic checkpoint resume. This candidate adds strict source/config/runtime identity checks, validated checkpoint reuse, complete-plan assembly checks, exclusive output ownership, and a last-written finish receipt for the assembled file and checkpoint set. It is source-only: it contains no mask, CT, model, checkpoint, output, wheel, or upstream source tree.

## Exact source boundary

Use the official `CanadaApollo6/vesuvius-spiral-chains` commit `87dc53454943bd5c4462aabaab2d01355c31bea9` (upstream Apache-2.0). The adapter imports `tools/autowind/{cli,core}.py` and `tools/auto_windings.py` from the `source_root` named in the spec; `freeze` hashes these and all local `tools/autowind/*.py` and `eval/*.py`. Apply `EDGE_PATH_BATCH_V1.patch` to that exact commit before freezing. The patch has SHA-256 `5aabd0060309ce488a8c394e1890b8e4a4333f5373ef653d20e846d4e92c30bc`; the resulting `tools/auto_windings.py` has SHA-256 `04f088c9829910a3773258df9a9a5bbe27905c07b7b21506c7883c4528f4dfd4` in the tested source. The unpatched upstream file has SHA-256 `4a71ef21caf520a9406b149b21395b729fb29acffd88f3f16dd4a9b64d66f438`.

```sh
git clone https://github.com/CanadaApollo6/vesuvius-spiral-chains.git SOURCE
git -C SOURCE checkout 87dc53454943bd5c4462aabaab2d01355c31bea9
git -C SOURCE apply --check /absolute/path/to/EDGE_PATH_BATCH_V1.patch
git -C SOURCE apply /absolute/path/to/EDGE_PATH_BATCH_V1.patch
shasum -a 256 SOURCE/tools/auto_windings.py
```

This is a source application recipe, not a claim that this package bootstraps a fresh machine. The tested host used Python 3.14.9 on macOS arm64. Its direct imported versions were NumPy 2.5.4, SciPy 1.18.1, connected-components-3d 4.1.0, Zarr 3.4.1, tifffile 2026.9.20, scikit-image 0.26.0, numcodecs 0.17.1, and fsspec 2025.9.0. Upstream `pyproject.toml` declares its broader requirements; install those from their official registries in an isolated environment. The plan records executable hash, import origins, selected versions and thread settings, so a different environment cannot silently resume the same plan. This candidate does not contain a dependency wheel lock.

## Admission and operation

Copy `spec.example.json` to a new file and replace all placeholders with absolute paths. Admit the exact local mask, official source objects and frame *before* freeze. `freeze` requires Zarr v2 `uint8` level 0, zero fill and 192³ slash-separated chunks, plus the source-specific metadata plan, HEAD receipt, verified payload receipt, pre-payload actual crop plan and level-3 source receipt. Their required relationships are checked in `guarded.py:freeze`; this package does not create or authenticate those receipts. Present objects are bound to SHA-256, size and ETag; officially absent objects require 404 receipts before and after acquisition. A missing local file alone is insufficient. The mask is trusted local data, and checkpoints use pickle; never load untrusted checkpoint bytes.

`autowind_argv` contains the normal arguments **after** `chains`; include `--mask`, authoritative `--umbilicus`, source frame/voxel size, selected z/theta band, `--raise off`, unique `--out`, unique `--work`, and `--conf-json`. The source root and mask must agree with the spec. Choose an empty work cache, a new plan path, a new committed workdir and an empty output path for each arm. Freeze is the scientific/input boundary; do not reselect after seeing outputs.

```sh
python guarded.py freeze SPEC.json PLAN.json --workers 2
python guarded.py run PLAN.json RUN_ROOT
python guarded.py verify PLAN.json RUN_ROOT
python guarded.py finish PLAN.json RUN_ROOT
```

Omit `--workers 2` for the one-worker default. Repeat `run` with the **same** plan and workdir to resume. It validates every committed crop before reuse and launches only missing workers. `finish` checks all commits, hardlinks their exact checkpoint files to `RUN_ROOT/crops_for_autowind`, claims an empty output directory for this plan/workdir, and invokes upstream `no_solve` assembly. It writes `.guarded-finish.json` last with the complete output file hashes and checkpoint/plan ownership. Repeat `finish` verifies that receipt and returns without reassembly. Changed outputs or a partial output without its receipt refuse overwrite. A foreign plan or workdir cannot take over that output. The separately versioned attested review operator requires this V4 receipt; historical review V2 does not. The tested two-worker plan used 55% sampled system-free-memory preflight, 45% sampled abort and a 300-second wall limit. `memory_pressure -Q` and `fcntl.flock` make the runtime path macOS/POSIX-specific as tested. The sampled pressure guard is not a continuous process-tree memory cap; choose bounds for the host before freezing.

## Focused checks

```sh
python guarded.py --help
python test_model_free.py
python test_two_worker_model_free.py
python test_output_owner.py
python test_finish_receipt_model_free.py
```

These checks use synthetic inputs and do not run model inference. The separate sparse-404 check in the saved Paris4 evidence requires its cached mask and is deliberately outside this source-only package. Existing separate real-run evidence covers a 20-crop Paris4 one-ray source-admitted band, exact V3/V4 checkpoint and assembled-output parity, warm zero-worker reuse and V4 output-owner refusal. The earlier V3 adapter (SHA-256 `5aa7fac6a18203529b64938f47264a5588df4464a2ead5fc6d2be7a2ce9fa6d6`) freshly computed 20 crops of a source-admitted neighboring-Z Paris4 m7 one-ray run; that run used an existing pinned source directory, not a clean installation from this archive. This new V4 adapter (SHA-256 `ad315de3fbd5a5b494e91d599b0cf038311bd687371e61131e5aa4c380a6dac7`) was tested with 20 copied, verified same-source checkpoints and no crop inference: five scientific assembled files matched the prior output byte-for-byte; repeat finish reused the receipt, and changed/missing/extra outputs were refused before review. A later independent bounded review of the exact V4 guarded runner with the V4 reader accepted the tested same-source, no-solver assembly and attested read-only completion; it did not rerun crop inference. These are bounded same-source engineering checks, not winding accuracy, reading quality, full-band throughput, remote-source support or a continuous memory cap. This archive has not been tested as an installable wheel, on a clean OS or against a newer upstream commit.

## Remaining portability boundaries

The admission receipts and selected geometry must be generated and independently reviewed for each source; `spec.example.json` is only a field template. The runtime fingerprint is deliberately same-host/path-specific. A native Windows memory/lock backend, generic remote Zarr ingestion, a dependency lock and a clean-OS installation test are outside this candidate. Upstream source and the task-authored edge patch remain separate inputs; this directory does not bundle upstream history.
