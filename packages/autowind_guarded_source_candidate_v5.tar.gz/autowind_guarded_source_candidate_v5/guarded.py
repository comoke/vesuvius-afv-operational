#!/usr/bin/env python3
"""Private opt-in, manifest-bound crop checkpoints for autowind chains.

Only local, trusted source trees and masks are supported. The default autowind
CLI is not changed. `finish` hands verified crop pickles to its `--no-solve` path.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
import pathlib
import platform
import pickle
import re
import subprocess
import sys
import time
import uuid

NAME = re.compile(r"^[0-9]+_-?[0-9]+(?:\.[0-9]+)?_[0-9]+\.pkl$")
SOURCE_FILES = ('tools/auto_windings.py',)
RUNTIME_PACKAGES = {'numpy': 'numpy', 'scipy': 'scipy', 'connected-components-3d': 'cc3d',
                    'zarr': 'zarr', 'tifffile': 'tifffile', 'scikit-image': 'skimage',
                    'numcodecs': 'numcodecs', 'fsspec': 'fsspec'}
THREAD_DEFAULTS = {'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
                   'MKL_NUM_THREADS': '1', 'NUMPY_MADVISE_HUGEPAGE': '0',
                   'AUTOWIND_EDGE_BATCH_SIZE': '128'}
for _key, _value in THREAD_DEFAULTS.items():
    os.environ.setdefault(_key, _value)


def sha(path: pathlib.Path) -> str:
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def canonical(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def json_sha(obj: object) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def runtime_fingerprint() -> dict:
    """Same-host runtime pin; no unrelated environment variables are recorded."""
    executable = pathlib.Path(sys.executable).resolve()
    packages = {}
    for distribution, module_name in RUNTIME_PACKAGES.items():
        module = importlib.import_module(module_name)
        packages[distribution] = {'version': importlib.metadata.version(distribution),
                                  'origin': str(pathlib.Path(module.__file__).resolve())}
    return {'guarded_sha256': sha(pathlib.Path(__file__).resolve()),
            'python_implementation': platform.python_implementation(),
            'python_version': platform.python_version(),
            'python_executable': str(executable), 'python_executable_sha256': sha(executable),
            'platform': platform.platform(), 'machine': platform.machine(),
            'thread_settings': {key: os.environ[key] for key in THREAD_DEFAULTS},
            'packages': packages}


def write_fsync(path: pathlib.Path, data: bytes) -> None:
    with path.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


@contextlib.contextmanager
def lock(path: pathlib.Path, seconds: float):
    path.parent.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    with path.open('a+b') as f:
        while True:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                remaining = seconds - (time.monotonic() - start)
                if remaining <= 0:
                    raise RuntimeError(f'active lock timeout: {path.name}') from None
                time.sleep(min(0.1, remaining))
        try:
            yield
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def load_plan(path: pathlib.Path) -> dict:
    p = json.loads(path.read_text())
    if set(p) != {'version', 'source_commit', 'source_root', 'options', 'config', 'runtime',
                  'input_sha256', 'shared_inputs', 'crop_inputs', 'crops', 'workers', 'lock_wait_seconds',
                  'free_preflight_floor_percent', 'free_abort_floor_percent', 'wall_limit_seconds'}:
        raise RuntimeError('unsupported plan fields')
    if p['version'] != 1 or not isinstance(p['crops'], dict) or not p['crops']:
        raise RuntimeError('invalid crop plan')
    if p['workers'] not in (1, 2) or not 0 <= p['lock_wait_seconds'] <= p['wall_limit_seconds']:
        raise RuntimeError('invalid worker or lock bound')
    for name, crop in p['crops'].items():
        if not NAME.fullmatch(name) or name != f"{crop['zc']}_{crop['theta']:g}_{crop['k']}.pkl":
            raise RuntimeError(f'crop name mismatch: {name}')
        if not all(k in crop for k in ('zc', 'zs', 'theta', 'k', 'rk', 'o')):
            raise RuntimeError(f'incomplete crop: {name}')
    if not isinstance(p['input_sha256'], dict) or not p['input_sha256']:
        raise RuntimeError('missing input hash map')
    if (not isinstance(p['shared_inputs'], list) or not isinstance(p['crop_inputs'], dict)
            or set(p['crop_inputs']) != set(p['crops'])
            or any(not isinstance(paths, list) for paths in p['crop_inputs'].values())):
        raise RuntimeError('invalid crop input closure')
    covered = set(p['shared_inputs'])
    for paths in p['crop_inputs'].values():
        covered.update(paths)
    if covered != set(p['input_sha256']):
        raise RuntimeError('incomplete input identity closure')
    return p


def verify_inputs(plan: dict, name: str | None = None) -> None:
    if plan['runtime'] != runtime_fingerprint():
        raise RuntimeError('guarded adapter/runtime identity mismatch')
    paths = (plan['input_sha256'] if name is None
             else set(plan['shared_inputs']) | set(plan['crop_inputs'][name]))
    for item in paths:
        path = pathlib.Path(item)
        expected = plan['input_sha256'][item]
        if not path.is_absolute():
            raise RuntimeError(f'input identity mismatch: {item}')
        if expected is None:
            if path.exists() or path.is_symlink():
                raise RuntimeError(f'official sparse chunk became present: {item}')
        elif not path.is_file() or sha(path) != expected:
            raise RuntimeError(f'input identity mismatch: {item}')


def manifest(workdir: pathlib.Path, plan: dict) -> None:
    workdir.mkdir(parents=True, exist_ok=True)
    expected = {'plan_sha256': json_sha(plan), 'source_commit': plan['source_commit'],
                'crops': list(plan['crops'])}
    path = workdir / 'MANIFEST.json'
    if path.exists():
        if json.loads(path.read_text()) != expected:
            raise RuntimeError('resume manifest mismatch')
    else:
        try:
            write_fsync(path, json.dumps(expected, indent=2).encode() + b'\n')
        except FileExistsError:
            if json.loads(path.read_text()) != expected:
                raise RuntimeError('concurrent manifest mismatch')


def validate_payload(raw: bytes, crop: dict) -> dict:
    """Structural guard for trusted local pickle bytes, not a scientific validator."""
    value = pickle.loads(raw)
    if not isinstance(value, tuple) or len(value) != 2 or canonical(value[0]) != canonical(crop):
        raise RuntimeError('checkpoint crop identity mismatch')
    result = value[1]
    if result is None:
        return {'state': 'none', 'z_count': 0}
    if not isinstance(result, dict) or not set(result).issubset(set(crop['zs'])):
        raise RuntimeError('invalid checkpoint result keys')
    for row in result.values():
        if not isinstance(row, dict) or not {'cr', 'tc', 'tlo', 'thi'} <= set(row):
            raise RuntimeError('invalid checkpoint result row')
        if not isinstance(row['cr'], list) or not all(isinstance(row[k], (int, float)) and math.isfinite(row[k])
                                                     for k in ('tc', 'tlo', 'thi')):
            raise RuntimeError('invalid checkpoint result fields')
    return {'state': 'mapping', 'z_count': len(result)}


def committed(workdir: pathlib.Path, plan: dict, name: str) -> dict | None:
    final = workdir / 'committed' / name.removesuffix('.pkl')
    if not final.exists() and not final.is_symlink():
        return None
    if not final.is_dir() or final.is_symlink() or {p.name for p in final.iterdir()} != {'checkpoint.pkl', 'receipt.json'}:
        raise RuntimeError(f'incomplete committed crop: {name}')
    meta = json.loads((final / 'receipt.json').read_text())
    raw = (final / 'checkpoint.pkl').read_bytes()
    if (not isinstance(meta, dict) or meta.get('checkpoint_bytes') != len(raw)
            or meta.get('checkpoint_sha256') != hashlib.sha256(raw).hexdigest()):
        raise RuntimeError(f'committed crop payload mismatch: {name}')
    summary = validate_payload(raw, plan['crops'][name])
    expected = {'plan_sha256': json_sha(plan), 'name': name,
                'crop_sha256': json_sha(plan['crops'][name]),
                'checkpoint_sha256': hashlib.sha256(raw).hexdigest(),
                'checkpoint_bytes': len(raw), 'summary': summary}
    if meta != expected:
        raise RuntimeError(f'committed crop receipt mismatch: {name}')
    return meta


def verify_committed_set(workdir: pathlib.Path, plan: dict) -> tuple[list[str], list[str]]:
    root = workdir / 'committed'
    root.mkdir(exist_ok=True)
    unexpected = {p.name for p in root.iterdir()} - {n.removesuffix('.pkl') for n in plan['crops']}
    if unexpected:
        raise RuntimeError(f'unexpected committed entries: {sorted(unexpected)}')
    reused, pending = [], []
    for name in plan['crops']:
        (reused if committed(workdir, plan, name) else pending).append(name)
    return reused, pending


def commit_one(workdir: pathlib.Path, plan: dict, name: str, solver) -> str:
    """The solver callback returns (crop, result). It is called only when no valid commit exists."""
    if solver is not real_solver and not plan['source_commit'].startswith('synthetic-'):
        raise RuntimeError('alternate solver callback is test-only')
    with lock(workdir / 'locks' / f'{name}.lock', plan['lock_wait_seconds']):
        verify_inputs(plan, name)
        manifest(workdir, plan)
        if committed(workdir, plan, name):
            return 'reused_after_lock'
        crop = plan['crops'][name]
        scratch = workdir / 'scratch'
        scratch.mkdir(exist_ok=True)
        attempt = uuid.uuid4().hex
        worker_config = dict(plan['config'])
        worker_config['crop_cache'] = str(scratch / f'{name}.{attempt}.m7_L0')
        raw = pickle.dumps(solver(crop, worker_config), protocol=pickle.HIGHEST_PROTOCOL)
        summary = validate_payload(raw, crop)
        verify_inputs(plan, name)
        meta = {'plan_sha256': json_sha(plan), 'name': name, 'crop_sha256': json_sha(crop),
                'checkpoint_sha256': hashlib.sha256(raw).hexdigest(), 'checkpoint_bytes': len(raw),
                'summary': summary}
        stage = scratch / f'{name}.{uuid.uuid4().hex}.stage'
        stage.mkdir()
        write_fsync(stage / 'checkpoint.pkl', raw)
        write_fsync(stage / 'receipt.json', json.dumps(meta, sort_keys=True, indent=2).encode() + b'\n')
        fd = os.open(stage, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        final = workdir / 'committed' / name.removesuffix('.pkl')
        final.parent.mkdir(exist_ok=True)
        if final.exists() or final.is_symlink():
            raise RuntimeError(f'commit target appeared: {name}')
        os.rename(stage, final)
        fd = os.open(final.parent, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        return 'computed'


def publish_crops(workdir: pathlib.Path, plan: dict) -> pathlib.Path:
    verify_inputs(plan)
    manifest(workdir, plan)
    reused, pending = verify_committed_set(workdir, plan)
    if pending:
        raise RuntimeError(f'{len(pending)} crops lack commits')
    out = workdir / 'crops_for_autowind'
    out.mkdir(exist_ok=True)
    if {p.name for p in out.iterdir()} - set(reused):
        raise RuntimeError('unexpected published crop entries')
    for name in reused:
        source = workdir / 'committed' / name.removesuffix('.pkl') / 'checkpoint.pkl'
        target = out / name
        if target.exists() or target.is_symlink():
            if not target.is_file() or not os.path.samefile(source, target):
                raise RuntimeError(f'published crop identity mismatch: {name}')
        else:
            os.link(source, target)
    return out


def claim_output_owner(workdir: pathlib.Path, plan: dict) -> pathlib.Path:
    """Bind assembly output to one committed workdir before upstream writes files."""
    out = pathlib.Path(plan['options']['out'])
    if not out.is_absolute() or out.is_symlink():
        raise RuntimeError('unsafe assembly output path')
    expected = {'plan_sha256': json_sha(plan), 'workdir': str(workdir.resolve())}
    out.mkdir(parents=True, exist_ok=True)
    marker = out / '.guarded-output-owner.json'
    if marker.is_symlink():
        raise RuntimeError('unsafe assembly owner marker')
    if marker.exists():
        if not marker.is_file() or json.loads(marker.read_text()) != expected:
            raise RuntimeError('assembly output owned by another workdir or plan')
    else:
        if any(out.iterdir()):
            raise RuntimeError('refusing nonempty unclaimed assembly output')
        # Write a complete marker beside the output and publish it by an
        # exclusive hard link. A competing claimant must never read an empty
        # marker created by open('x') before its JSON has been written.
        stage = out.parent / f'.{out.name}.guarded-owner.{uuid.uuid4().hex}.tmp'
        try:
            write_fsync(stage, json.dumps(expected, sort_keys=True, indent=2).encode() + b'\n')
            try:
                os.link(stage, marker)
            except FileExistsError:
                if marker.is_symlink() or not marker.is_file() or json.loads(marker.read_text()) != expected:
                    raise RuntimeError('assembly output claimed concurrently by another workdir') from None
        finally:
            stage.unlink(missing_ok=True)
        fd = os.open(out, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    return out


FINISH_RECEIPT = '.guarded-finish.json'
FINISH_REQUIRED = {'chains.json', 'relative_windings.json', 'steps.csv',
                   'summary.json', 'autowind_run.json', 'umbilicus_maskframe.json'}


def assembly_files(out: pathlib.Path) -> dict[str, str]:
    """Hash the complete published file set, excluding the owner and receipt."""
    result = {}
    for path in sorted(out.rglob('*')):
        if path.is_symlink() or (not path.is_file() and not path.is_dir()):
            raise RuntimeError('unsafe assembly output entry')
        if path.is_file():
            name = path.relative_to(out).as_posix()
            if name not in {'.guarded-output-owner.json', FINISH_RECEIPT}:
                result[name] = sha(path)
    if not FINISH_REQUIRED <= set(result):
        raise RuntimeError('incomplete assembled output file set')
    return result


def assembly_receipt(workdir: pathlib.Path, plan: dict, out: pathlib.Path) -> dict:
    reused, pending = verify_committed_set(workdir, plan)
    if pending:
        raise RuntimeError('cannot attest incomplete crop set')
    files = assembly_files(out)
    run = json.loads((out / 'autowind_run.json').read_text())
    if run['options']['out'] != plan['options']['out'] or run['options']['no_solve'] is not True:
        raise RuntimeError('assembled run options differ from guarded plan')
    if any(run['sha256'].get(name) != files[name] for name in ('chains.json', 'relative_windings.json')):
        raise RuntimeError('assembled output differs from upstream recorded hashes')
    checkpoints = [{'name': name,
                    'checkpoint_sha256': sha(workdir / 'committed' / name.removesuffix('.pkl') / 'checkpoint.pkl'),
                    'receipt_sha256': sha(workdir / 'committed' / name.removesuffix('.pkl') / 'receipt.json')}
                   for name in sorted(reused)]
    return {'schema': 'guarded_finish_v1', 'plan_sha256': json_sha(plan),
            'workdir': str(workdir.resolve()),
            'output_owner_sha256': sha(out / '.guarded-output-owner.json'),
            'checkpoints': checkpoints, 'outputs_sha256': files}


def verify_finish_receipt(workdir: pathlib.Path, plan: dict) -> dict:
    out = pathlib.Path(plan['options']['out'])
    path = out / FINISH_RECEIPT
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('missing guarded finish receipt')
    actual = json.loads(path.read_text())
    if actual != assembly_receipt(workdir, plan, out):
        raise RuntimeError('guarded finish receipt or output mismatch')
    return actual


def finish_assembly(workdir: pathlib.Path, plan: dict) -> str:
    crop_dir = publish_crops(workdir, plan)
    out = claim_output_owner(workdir, plan)
    receipt_path = out / FINISH_RECEIPT
    if receipt_path.exists() or receipt_path.is_symlink():
        verify_finish_receipt(workdir, plan)
        return 'reused_verified_assembly'
    if {p.name for p in out.iterdir()} != {'.guarded-output-owner.json'}:
        raise RuntimeError('unattested partial assembly; refusing overwrite')
    cli, core = autowind_modules(plan)
    o = argparse.Namespace(**plan['options'])
    o.crops = str(crop_dir)
    o.crops_ro = None
    o.no_solve = True
    core.run_chains(o)
    receipt = assembly_receipt(workdir, plan, out)
    stage = out.parent / f'.{out.name}.guarded-finish.{uuid.uuid4().hex}.tmp'
    try:
        write_fsync(stage, json.dumps(receipt, sort_keys=True, indent=2).encode() + b'\n')
        os.link(stage, receipt_path)
    finally:
        stage.unlink(missing_ok=True)
    fd = os.open(out, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return 'assembled_and_attested'


def new_attempt_log(workdir: pathlib.Path, name: str):
    folder = workdir / 'logs' / name.removesuffix('.pkl')
    folder.mkdir(parents=True, exist_ok=True)
    for i in range(10000):
        path = folder / f'attempt_{i:04d}.log'
        try:
            return path, path.open('x')
        except FileExistsError:
            continue
    raise RuntimeError('too many crop attempts')


def free_percent() -> int:
    p = subprocess.run(['memory_pressure', '-Q'], capture_output=True, text=True, timeout=10)
    m = re.search(r'System-wide memory free percentage: (\d+)%', p.stdout)
    if p.returncode or not m:
        raise RuntimeError('system memory pressure probe unavailable')
    return int(m.group(1))


def run_guarded(plan_path: pathlib.Path, workdir: pathlib.Path, plan: dict, command_factory=None) -> dict:
    """At most two isolated workers; each publishes its own checked crop."""
    start = time.monotonic()
    minimum = free_percent()
    if minimum < plan['free_preflight_floor_percent']:
        raise RuntimeError('free memory below frozen preflight floor')
    reused, pending = verify_committed_set(workdir, plan)
    actions = []
    while pending:
        batch, pending = pending[:plan['workers']], pending[plan['workers']:]
        active = {}
        try:
            for name in batch:
                log_path, log = new_attempt_log(workdir, name)
                command = ([sys.executable, str(pathlib.Path(__file__).resolve()), 'worker',
                            str(plan_path), str(workdir), name] if command_factory is None
                           else command_factory(name))
                try:
                    child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
                except BaseException:
                    log.close()
                    raise
                active[name] = (child, log, log_path)
            while active:
                current = free_percent()
                minimum = min(minimum, current)
                if current < plan['free_abort_floor_percent']:
                    raise RuntimeError('free memory below frozen abort floor')
                if time.monotonic() - start > plan['wall_limit_seconds']:
                    raise RuntimeError('wall limit exceeded')
                for name, (child, log, log_path) in list(active.items()):
                    rc = child.poll()
                    if rc is None:
                        continue
                    log.close()
                    del active[name]
                    if rc:
                        raise RuntimeError(f'worker {name} failed; see {log_path}')
                    lines = log_path.read_text().splitlines()
                    try:
                        last = json.loads(lines[-1])
                    except (IndexError, json.JSONDecodeError) as exc:
                        raise RuntimeError(f'worker completion receipt missing: {name}') from exc
                    if last.get('name') != name or last.get('action') not in ('computed', 'reused_after_lock'):
                        raise RuntimeError(f'worker completion receipt invalid: {name}')
                    if committed(workdir, plan, name) is None:
                        raise RuntimeError(f'worker completed without a checkpoint: {name}')
                    actions.append({'name': name, 'action': last['action'], 'log': str(log_path)})
                if active:
                    time.sleep(0.5)
        except BaseException:
            for child, _, _ in active.values():
                if child.poll() is None:
                    child.terminate()
            for child, log, _ in active.values():
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait()
                log.close()
            raise
    verify_inputs(plan)
    final, remaining = verify_committed_set(workdir, plan)
    receipt = {'status': 'COMPLETE' if not remaining else 'INCOMPLETE', 'plan_sha256': json_sha(plan),
               'reused_at_start': reused, 'worker_actions': actions, 'valid_committed': final,
               'remaining': remaining, 'minimum_system_free_percent': minimum,
               'wall_seconds': time.monotonic() - start,
               'pressure_guard': 'sampled system-wide free percentage, not continuous process-tree RSS'}
    serial = len(list(workdir.glob('RUN_*.json')))
    write_fsync(workdir / f'RUN_{serial:02d}.json', json.dumps(receipt, indent=2).encode() + b'\n')
    return receipt


def autowind_modules(plan: dict):
    root = pathlib.Path(plan['source_root'])
    sys.path.insert(0, str(root / 'tools'))
    from autowind import cli, core
    if (pathlib.Path(core.__file__).resolve() != (root / 'tools/autowind/core.py').resolve()
            or pathlib.Path(cli.__file__).resolve() != (root / 'tools/autowind/cli.py').resolve()
            or pathlib.Path(core.aw.__file__).resolve() != (root / 'tools/auto_windings.py').resolve()):
        raise RuntimeError('autowind import origin differs from frozen source root')
    for name in ('p0139_graph', 'p0139_crossings', 'p0139_sites', 'winding_sites', 'contact_check', 'separation'):
        module = sys.modules.get(name)
        if module is not None and pathlib.Path(module.__file__).resolve() != (root / 'eval' / f'{name}.py').resolve():
            raise RuntimeError(f'{name} import origin differs from frozen source root')
    return cli, core


def real_solver(crop: dict, config: dict):
    _, core = autowind_modules({'source_root': config['source_root']})
    core.configure(config)
    cache = pathlib.Path(config['crop_cache'])
    cache.mkdir(parents=True, exist_ok=True)
    return core.aw._band_crop((crop, {'cache': str(cache),
                                      'seg': config['seg'], 'url': config['mask']}))


def freeze(spec_path: pathlib.Path, plan_path: pathlib.Path, workers: int | None = None) -> None:
    """Plan through the existing autowind planner; local 192-cubed Zarr only."""
    spec = json.loads(spec_path.read_text())
    if os.environ['AUTOWIND_EDGE_BATCH_SIZE'] != '128':
        raise RuntimeError('this guarded band requires edge batch size 128')
    if not re.fullmatch(r'[0-9a-f]{40}', spec['source_commit']):
        raise RuntimeError('freeze requires a full upstream source commit')
    root = pathlib.Path(spec['source_root']).resolve()
    mask = pathlib.Path(spec['mask']).resolve()
    if '://' in spec['mask'] or not mask.is_dir():
        raise RuntimeError('freeze supports only an existing local mask')
    zarray = json.loads((mask / '0/.zarray').read_text())
    if zarray['chunks'] != [192, 192, 192] or zarray.get('dimension_separator', '.') != '/':
        raise RuntimeError('expected local 192-cubed slash-separated mask chunks')
    if zarray.get('zarr_format') != 2 or zarray.get('fill_value') != 0 or zarray.get('dtype') != '|u1':
        raise RuntimeError('sparse input requires pinned Zarr v2 uint8 zero-fill contract')
    metadata_path = pathlib.Path(spec['metadata_plan']).resolve()
    head_path = pathlib.Path(spec['head_receipt']).resolve()
    payload_path = pathlib.Path(spec['payload_receipt']).resolve()
    actual_path = pathlib.Path(spec['actual_crop_plan']).resolve()
    level3_receipt_path = pathlib.Path(spec['level3_receipt']).resolve()
    if not payload_path.is_file():
        raise RuntimeError('verified payload receipt missing; no plan can be frozen')
    metadata = json.loads(metadata_path.read_text())
    head = json.loads(head_path.read_text())
    payload = json.loads(payload_path.read_text())
    actual = json.loads(actual_path.read_text())
    level3_receipt = json.loads(level3_receipt_path.read_text())
    if (head['plan_sha256'] != sha(metadata_path)
            or head['status'] != 'HEAD_VALID_UNDER_CAP'
            or metadata['level0_metadata_sha256']['0/.zarray'] != sha(mask / '0/.zarray')
            or metadata['level0_metadata_sha256']['.zgroup'] != sha(mask / '.zgroup')
            or metadata['level0_metadata_sha256']['.zattrs'] != sha(mask / '.zattrs')
            or payload['head_receipt_sha256'] != sha(head_path)
            or payload['source_asset'] != metadata['source_asset']
            or actual['head_receipt_sha256'] != sha(head_path)
            or actual['level3_receipt_sha256'] != sha(level3_receipt_path)
            or set(payload_rows := {r['key']: r for r in payload['rows']}) != set(actual['present_keys'])
            or payload['absent_keys'] != actual['absent_keys']):
        raise RuntimeError('source admission receipt identity mismatch')
    for phase in ('absent_recheck_before', 'absent_recheck_after'):
        check = payload.get(phase)
        if (not isinstance(check, dict) or not isinstance(check.get('checked_utc'), str)
                or check.get('rows') != [{'key': key, 'status': 404} for key in actual['absent_keys']]):
            raise RuntimeError(f'current official sparse absence receipt missing: {phase}')
    head_rows = {r['key']: r for r in head['rows']}
    if len(head_rows) != len(head['rows']) or len(payload_rows) != len(payload['rows']):
        raise RuntimeError('duplicate source admission key')
    if {r['key']: r['sha256'] for r in level3_receipt['requests']} != actual['level3_local_sha256']:
        raise RuntimeError('level-3 planner source receipt mismatch')
    for key, expected in actual['level3_local_sha256'].items():
        if sha(mask / key) != expected:
            raise RuntimeError(f'level-3 planner input mismatch: {key}')
    source_paths = [root / rel for rel in SOURCE_FILES]
    source_paths.extend(sorted((root / 'eval').glob('*.py')))
    source_paths.extend(sorted((root / 'tools/autowind').glob('*.py')))
    source_map = {str(p): sha(p) for p in source_paths}
    cli, core = autowind_modules({'source_root': str(root)})
    o = cli.resolve(cli.build_parser().parse_args(['chains', *spec['autowind_argv']]))
    if o.crops or o.crops_ro or o.no_solve or str(pathlib.Path(o.mask).resolve()) != str(mask):
        raise RuntimeError('freeze requires this mask and no existing crop inputs')
    if o.raise_ != 'off':
        raise RuntimeError('guarded integration currently supports --raise off only')
    o.mask = str(mask)
    o.umbilicus = str(pathlib.Path(o.umbilicus).resolve())
    o.conf_json = str(pathlib.Path(o.conf_json).resolve())
    o.work = str(pathlib.Path(o.work or pathlib.Path(o.out) / 'work').resolve())
    o.out = str(pathlib.Path(o.out).resolve())
    if o.umbilicus_transform:
        o.umbilicus_transform = str(pathlib.Path(o.umbilicus_transform).resolve())
    work_path = pathlib.Path(o.work)
    if work_path.exists() and (not work_path.is_dir() or any(work_path.iterdir())):
        raise RuntimeError('freeze requires a new empty work cache')
    work_path.mkdir(parents=True, exist_ok=True)
    xyz = core.load_umbilicus(o.umbilicus, o.umbilicus_transform)
    cfg = {'source_root': str(root), 'mask': str(mask), 'work': o.work,
           'shape': list(core.mask_shape(str(mask))), 'umbilicus_xyz': xyz.tolist(), 'seg': o.seg}
    core.configure(cfg)
    _, crops = core.plan(o, cfg)
    crop_map = {core._key(c): c for c in crops}
    if len(crop_map) != len(crops) or not crops:
        raise RuntimeError('empty or duplicate upstream crop plan')
    if crops != actual['crops']:
        raise RuntimeError('actual planner crops changed from pre-payload freeze')
    input_map = dict(source_map)
    shared_paths = set(input_map)
    extent_files = sorted(pathlib.Path(cfg['work']).glob('l3_*.npy'))
    if not extent_files:
        raise RuntimeError('planner did not produce a frozen radial-extent cache')
    for p in extent_files:
        input_map[str(p.resolve())] = sha(p)
        shared_paths.add(str(p.resolve()))
    for p in (pathlib.Path(o.umbilicus), pathlib.Path(o.conf_json), mask / '.zgroup', mask / '.zattrs',
              mask / '0/.zarray', metadata_path, head_path, payload_path, actual_path, level3_receipt_path):
        if not p.is_file():
            raise RuntimeError(f'required local input missing: {p}')
        input_map[str(p.resolve())] = sha(p)
        shared_paths.add(str(p.resolve()))
    for key in actual['level3_local_sha256']:
        p = (mask / key).resolve()
        input_map[str(p)] = sha(p)
        shared_paths.add(str(p))
    if o.umbilicus_transform:
        p = pathlib.Path(o.umbilicus_transform).resolve()
        input_map[str(p)] = sha(p)
        shared_paths.add(str(p))
    src = core.aw.M7Chunks(url=str(mask), cache=pathlib.Path(cfg['work']) / 'm7_L0')
    crop_inputs = {}
    for name, c in crop_map.items():
        paths = []
        for i, j, k in src.chunks_of(tuple(c['o'])):
            p = mask / '0' / str(i) / str(j) / str(k)
            key = str(p)
            if key not in input_map:
                rel = f'0/{i}/{j}/{k}'
                row = head_rows.get(rel)
                if row is None:
                    raise RuntimeError(f'crop chunk outside frozen HEAD envelope: {rel}')
                if row['status'] == 404 and not p.exists() and not p.is_symlink():
                    input_map[key] = None
                elif row['status'] == 200 and p.is_file():
                    got = sha(p)
                    pay = payload_rows.get(rel)
                    if (pay is None or pay.get('sha256') != got
                            or pay.get('bytes') != row['content_length']
                            or pay.get('etag') != row['etag'] or p.stat().st_size != row['content_length']):
                        raise RuntimeError(f'present source chunk mismatch: {rel}')
                    input_map[key] = got
                else:
                    raise RuntimeError(f'official sparse source mismatch: {rel}')
            paths.append(key)
        crop_inputs[name] = sorted(set(paths))
    plan = {'version': 1, 'source_commit': spec['source_commit'], 'source_root': str(root),
            'runtime': runtime_fingerprint(),
            'options': {k: str(v) if isinstance(v, pathlib.Path) else v for k, v in vars(o).items()},
            'config': cfg, 'input_sha256': dict(sorted(input_map.items())),
            'shared_inputs': sorted(shared_paths), 'crop_inputs': crop_inputs, 'crops': crop_map,
            'workers': workers if workers is not None else 1,
            'lock_wait_seconds': spec.get('lock_wait_seconds', 30),
            'free_preflight_floor_percent': spec.get('free_preflight_floor_percent', 55),
            'free_abort_floor_percent': spec.get('free_abort_floor_percent', 45),
            'wall_limit_seconds': spec.get('wall_limit_seconds', 180)}
    if plan_path.exists():
        raise RuntimeError('refusing to replace an existing frozen plan')
    write_fsync(plan_path, json.dumps(plan, sort_keys=True, indent=2).encode() + b'\n')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('action', choices=('freeze', 'run', 'worker', 'finish', 'verify'))
    ap.add_argument('plan_or_spec')
    ap.add_argument('workdir_or_plan')
    ap.add_argument('name', nargs='?')
    ap.add_argument('--workers', type=int, choices=(1, 2), help='freeze only; default 1, opt in to 2')
    a = ap.parse_args()
    if a.action == 'freeze':
        freeze(pathlib.Path(a.plan_or_spec), pathlib.Path(a.workdir_or_plan), a.workers)
        return 0
    if a.workers is not None:
        raise RuntimeError('--workers applies only when freezing a new plan')
    path = pathlib.Path(a.plan_or_spec)
    workdir = pathlib.Path(a.workdir_or_plan)
    plan = load_plan(path)
    verify_inputs(plan, a.name if a.action == 'worker' else None)
    manifest(workdir, plan)
    if a.action == 'worker':
        if a.name not in plan['crops']:
            raise RuntimeError('worker crop outside frozen plan')
        action = commit_one(workdir, plan, a.name, real_solver)
        print(json.dumps({'name': a.name, 'action': action}), flush=True)
        return 0
    if a.name:
        raise RuntimeError('unexpected crop name')
    if a.action == 'verify':
        reused, pending = verify_committed_set(workdir, plan)
        print(json.dumps({'committed': reused, 'pending': pending}))
        return 0
    if a.action == 'finish':
        with lock(workdir / '.scheduler.lock', 0):
            print(json.dumps({'finish': finish_assembly(workdir, plan)}), flush=True)
        return 0
    with lock(workdir / '.scheduler.lock', 0):
        print(json.dumps(run_guarded(path, workdir, plan), indent=2), flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError, KeyError) as exc:
        print(f'guarded autowind: {exc}', file=sys.stderr)
        raise SystemExit(2)
