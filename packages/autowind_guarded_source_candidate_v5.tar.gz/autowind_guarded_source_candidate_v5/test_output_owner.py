#!/usr/bin/env python3
"""Model-free assembly-output ownership and refusal checks."""
import concurrent.futures
import json
import pathlib
import tempfile
import threading

import guarded

def expect_refusal(fn, phrase):
    try:
        fn()
    except RuntimeError as exc:
        assert phrase in str(exc), str(exc)
    else:
        raise AssertionError('unsafe output claim accepted')

with tempfile.TemporaryDirectory(prefix='output_owner_', dir=pathlib.Path(__file__).parent) as td:
    root = pathlib.Path(td)
    a, b = root / 'work_a', root / 'work_b'
    a.mkdir(); b.mkdir()
    out = root / 'output'
    plan = {'options': {'out': str(out)}, 'crops': {'synthetic': True}}
    assert guarded.claim_output_owner(a, plan) == out
    marker = json.loads((out / '.guarded-output-owner.json').read_text())
    assert marker == {'plan_sha256': guarded.json_sha(plan), 'workdir': str(a.resolve())}
    (out / 'chains.json').write_bytes(b'accepted original')
    assert guarded.claim_output_owner(a, plan) == out
    expect_refusal(lambda: guarded.claim_output_owner(b, plan), 'owned by another workdir')
    assert (out / 'chains.json').read_bytes() == b'accepted original'

    changed = {'options': {'out': str(out)}, 'crops': {'synthetic': False}}
    expect_refusal(lambda: guarded.claim_output_owner(a, changed), 'owned by another workdir')
    assert (out / 'chains.json').read_bytes() == b'accepted original'

    legacy = root / 'legacy'
    legacy.mkdir()
    (legacy / 'chains.json').write_bytes(b'legacy original')
    expect_refusal(lambda: guarded.claim_output_owner(a, {'options': {'out': str(legacy)}}),
                   'nonempty unclaimed')
    assert (legacy / 'chains.json').read_bytes() == b'legacy original'

    link = root / 'linked'
    link.symlink_to(out, target_is_directory=True)
    expect_refusal(lambda: guarded.claim_output_owner(a, {'options': {'out': str(link)}}),
                   'unsafe assembly output path')

    race_out = root / 'race'
    race_plan = {'options': {'out': str(race_out)}, 'crops': {'synthetic': True}}
    barrier = threading.Barrier(2)
    def contender(workdir):
        barrier.wait()
        try:
            guarded.claim_output_owner(workdir, race_plan)
            return 'won'
        except RuntimeError:
            return 'refused'
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(contender, (a, b)))
    assert sorted(results) == ['refused', 'won'], results
    assert json.loads((race_out / '.guarded-output-owner.json').read_text())['workdir'] in {str(a), str(b)}
print('output_owner_same_reuse_cross_workdir_plan_legacy_symlink_race_pass')
