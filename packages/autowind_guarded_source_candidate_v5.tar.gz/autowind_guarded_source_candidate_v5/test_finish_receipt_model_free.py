#!/usr/bin/env python3
"""Small synthetic finish-receipt integrity test; no model or data asset."""
from __future__ import annotations

import json
import pathlib
import tempfile

import guarded as g


def refused(fn, fragment: str) -> None:
    try:
        fn()
    except RuntimeError as exc:
        assert fragment in str(exc), str(exc)
    else:
        raise AssertionError(f'expected refusal: {fragment}')


with tempfile.TemporaryDirectory(prefix='guarded_finish_test_') as tmp:
    root = pathlib.Path(tmp)
    source = root / 'source'
    source.write_bytes(b'synthetic source')
    out = root / 'out'
    work = root / 'work'
    crop = {'zc': 1, 'zs': [1], 'theta': 0.0, 'k': 0, 'rk': 5.0, 'o': [0, 0, 0]}
    name = '1_0_0.pkl'
    plan = {'version': 1, 'source_commit': 'synthetic-only', 'source_root': str(root),
            'runtime': g.runtime_fingerprint(), 'options': {'out': str(out), 'no_solve': True},
            'config': {'seg': 10}, 'input_sha256': {str(source): g.sha(source)},
            'shared_inputs': [str(source)], 'crop_inputs': {name: []}, 'crops': {name: crop},
            'workers': 1, 'lock_wait_seconds': 1, 'free_preflight_floor_percent': 55,
            'free_abort_floor_percent': 45, 'wall_limit_seconds': 5}
    g.manifest(work, plan)
    assert g.commit_one(work, plan, name, lambda c, cfg: (c, {})) == 'computed'
    g.claim_output_owner(work, plan)
    for filename in g.FINISH_REQUIRED - {'autowind_run.json'}:
        (out / filename).write_text('{}\n')
    run = {'options': {'out': str(out), 'no_solve': True},
           'sha256': {filename: g.sha(out / filename)
                      for filename in ('chains.json', 'relative_windings.json')}}
    (out / 'autowind_run.json').write_text(json.dumps(run) + '\n')
    receipt = g.assembly_receipt(work, plan, out)
    (out / g.FINISH_RECEIPT).write_text(json.dumps(receipt) + '\n')
    assert g.verify_finish_receipt(work, plan) == receipt
    step = out / 'steps.csv'
    prior = step.read_bytes()
    step.write_bytes(prior + b' ')
    refused(lambda: g.verify_finish_receipt(work, plan), 'finish receipt or output mismatch')
    step.write_bytes(prior)
    extra = out / 'extra.txt'
    extra.write_text('extra')
    refused(lambda: g.verify_finish_receipt(work, plan), 'finish receipt or output mismatch')
    extra.unlink()
    checkpoint_receipt = work / 'committed/1_0_0/receipt.json'
    prior = checkpoint_receipt.read_bytes()
    checkpoint_receipt.write_bytes(prior + b' ')
    refused(lambda: g.verify_finish_receipt(work, plan), 'finish receipt or output mismatch')
    checkpoint_receipt.write_bytes(prior)
    assert g.verify_finish_receipt(work, plan) == receipt

print('PASS: attested finish, changed step, extra file, changed checkpoint receipt')
