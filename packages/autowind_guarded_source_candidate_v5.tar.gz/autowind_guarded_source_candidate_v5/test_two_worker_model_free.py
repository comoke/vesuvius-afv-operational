#!/usr/bin/env python3
"""Two real subprocesses, synthetic crops and timed orphan; no model work."""
from __future__ import annotations

import copy
import fcntl
import json
import pathlib
import subprocess
import sys
import tempfile
import time

import guarded as g


def expect_error(fn, phrase: str) -> None:
    try:
        fn()
    except RuntimeError as exc:
        assert phrase in str(exc), str(exc)
    else:
        raise AssertionError(f'expected error {phrase}')


def held(path: pathlib.Path) -> bool:
    if not path.exists():
        return False
    with path.open('a+b') as f:
        try:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        else:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            return False


def wait_for_lock(path: pathlib.Path, process: subprocess.Popen) -> None:
    deadline = time.monotonic() + 5
    while not held(path):
        if process.poll() is not None or time.monotonic() > deadline:
            raise RuntimeError('test orphan never held crop lock')
        time.sleep(0.02)


def main() -> None:
    stub = pathlib.Path(__file__).with_name('stub_two_worker_model_free.py')
    original_free = g.free_percent
    g.free_percent = lambda: 100  # model-free scheduling test, not a resource benchmark
    try:
        with tempfile.TemporaryDirectory(prefix='guarded_two_worker_', dir=pathlib.Path(__file__).resolve().parent) as td:
            root = pathlib.Path(td)
            source = root / 'source_chunk'
            source.write_bytes(b'frozen synthetic input')
            names = ['1_0_0.pkl', '1_0_1.pkl']
            chunks = [root / 'crop_chunk_0', root / 'crop_chunk_1']
            for i, chunk in enumerate(chunks):
                chunk.write_bytes(f'frozen crop chunk {i}'.encode())
            crops = {name: {'zc': 1, 'zs': [1], 'theta': 0.0, 'k': i, 'rk': 5.0 + i,
                            'o': [0, 0, i]} for i, name in enumerate(names)}
            plan = {'version': 1, 'source_commit': 'synthetic-only', 'source_root': str(root),
                    'runtime': g.runtime_fingerprint(),
                    'options': {}, 'config': {'seg': 10},
                    'input_sha256': {str(p): g.sha(p) for p in [source, *chunks]},
                    'shared_inputs': [str(source)],
                    'crop_inputs': {name: [str(chunks[i])] for i, name in enumerate(names)},
                    'crops': crops, 'workers': 2, 'lock_wait_seconds': 5,
                    'free_preflight_floor_percent': 0, 'free_abort_floor_percent': 0,
                    'wall_limit_seconds': 15}
            plan_path = root / 'PLAN.json'
            plan_path.write_text(json.dumps(plan, indent=2) + '\n')
            plan = g.load_plan(plan_path)
            incomplete_plan = copy.deepcopy(plan)
            del incomplete_plan['crop_inputs'][names[1]]
            incomplete_path = root / 'INCOMPLETE_PLAN.json'
            incomplete_path.write_text(json.dumps(incomplete_plan))
            expect_error(lambda: g.load_plan(incomplete_path), 'invalid crop input closure')
            chunks[1].write_bytes(b'changed other crop chunk')
            g.verify_inputs(plan, names[0])
            expect_error(lambda: g.verify_inputs(plan), 'input identity mismatch')
            chunks[1].write_bytes(b'frozen crop chunk 1')
            g.verify_inputs(plan)
            command = lambda work: (lambda name: [sys.executable, str(stub), str(plan_path), str(work), name])

            # Both workers start together; crop 1 publishes first.
            order = root / 'out_of_order'
            g.manifest(order, plan)
            (order / 'SCHEDULE.json').write_text(json.dumps({names[0]: 1.3, names[1]: 0.05}))
            receipt = g.run_guarded(plan_path, order, plan, command(order))
            assert receipt['status'] == 'COMPLETE' and receipt['remaining'] == []
            assert [a['name'] for a in receipt['worker_actions']] == [names[1], names[0]]
            assert [a['action'] for a in receipt['worker_actions']] == ['computed', 'computed']
            assert len(list((order / 'compute_events').iterdir())) == 2
            caches = [p.read_text().strip() for p in (order / 'compute_events').iterdir()]
            assert len(set(caches)) == 2 and all(str(order / 'scratch') in cache for cache in caches)
            assert g.verify_committed_set(order, plan) == (names, [])
            assert {p.name for p in g.publish_crops(order, plan).iterdir()} == set(names)

            # A surviving orphan owns crop 0. Parent starts both workers; its
            # crop 0 waits, rechecks the commit, and skips duplicate computation.
            orphan = root / 'orphan'
            g.manifest(orphan, plan)
            (orphan / 'SCHEDULE.json').write_text(json.dumps({names[0]: 1.1, names[1]: 0.05}))
            direct_log = (orphan / 'direct_orphan.log').open('x')
            direct = subprocess.Popen(command(orphan)(names[0]), stdout=direct_log, stderr=subprocess.STDOUT)
            try:
                wait_for_lock(orphan / 'locks' / f'{names[0]}.lock', direct)
                resumed = g.run_guarded(plan_path, orphan, plan, command(orphan))
                assert direct.wait(timeout=5) == 0
            finally:
                if direct.poll() is None:
                    direct.kill(); direct.wait()
                direct_log.close()
            actions = {row['name']: row['action'] for row in resumed['worker_actions']}
            assert actions == {names[0]: 'reused_after_lock', names[1]: 'computed'}
            assert len(list((orphan / 'compute_events').glob(f'{names[0]}.*'))) == 1
            assert len(list((orphan / 'compute_events').glob(f'{names[1]}.*'))) == 1
            assert g.verify_committed_set(orphan, plan) == (names, [])
            assert g.run_guarded(plan_path, orphan, plan, command(orphan))['worker_actions'] == []

            # Missing or corrupt receipts refuse reuse before any new worker log.
            missing = root / 'missing_receipt'
            g.manifest(missing, plan)
            incomplete = missing / 'committed' / names[0].removesuffix('.pkl')
            incomplete.mkdir(parents=True)
            (incomplete / 'checkpoint.pkl').write_bytes(b'partial')
            expect_error(lambda: g.run_guarded(plan_path, missing, plan, command(missing)),
                         'incomplete committed crop')
            assert not (missing / 'logs').exists()
            receipt_path = orphan / 'committed' / names[0].removesuffix('.pkl') / 'receipt.json'
            receipt_bytes = receipt_path.read_bytes()
            receipt_path.write_text('{}')
            prior_log_count = len(list((orphan / 'logs').rglob('*.log')))
            expect_error(lambda: g.run_guarded(plan_path, orphan, plan, command(orphan)),
                         'committed crop payload mismatch')
            assert len(list((orphan / 'logs').rglob('*.log'))) == prior_log_count
            receipt_path.write_bytes(receipt_bytes)
            assert g.verify_committed_set(orphan, plan) == (names, [])

        result = {'status': 'PASS', 'workers': 2, 'synthetic_crops': 2,
                  'out_of_order_actions': [names[1], names[0]],
                  'orphan_actions': actions, 'orphan_compute_count': 1,
                  'missing_and_corrupt_receipts_rejected_before_launch': True,
                  'resource_measurement': 'free_percent stubbed to 100; no memory inference'}
        output = pathlib.Path(__file__).with_name('TWO_WORKER_MODEL_FREE_RESULT.json')
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))
    finally:
        g.free_percent = original_free


if __name__ == '__main__':
    main()
