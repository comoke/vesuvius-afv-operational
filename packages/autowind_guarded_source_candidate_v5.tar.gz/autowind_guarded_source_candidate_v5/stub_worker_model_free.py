#!/usr/bin/env python3
"""Test-only subprocess worker; never imported by guarded.py production CLI."""
import json
import pathlib
import sys

import guarded as g

plan_path, workdir, name = map(pathlib.Path, sys.argv[1:4])
name = str(name)
marker = workdir / 'simulated_stop_once'
if not marker.exists():
    marker.write_text('stopped before commit\n')
    print('test-only stop before commit', flush=True)
    raise SystemExit(3)
plan = g.load_plan(plan_path)
def solve(crop, config):
    return crop, {crop['zs'][0]: {'cr': [], 'tc': 1.0, 'tlo': 0.0, 'thi': 2.0}}
action = g.commit_one(workdir, plan, name, solve)
print(json.dumps({'name': name, 'action': action}), flush=True)
