# Source and license boundaries

`guarded.py`, the synthetic tests, this README and the field template are original task-authored additions covered by `LICENSE-TASK-ADDITIONS.txt` under the project owner's existing MIT approval. No individual contributor identity or assignment is inferred.

`EDGE_PATH_BATCH_V1.patch` changes files in `CanadaApollo6/vesuvius-spiral-chains` commit `87dc53454943bd5c4462aabaab2d01355c31bea9`. Its original task-authored additions fall under the same approved grant; unchanged upstream context and the upstream source remain under their own Apache-2.0 notice, copied as `LICENSE-UPSTREAM-APACHE-2.0.txt`. Preserve that notice when applying or distributing a derivative source tree. The patch is included as a source dependency, not as a claim of upstream adoption.

The upstream source tree, dependencies, public predictions, CT, model assets, geometric inputs, cached checkpoints and outputs are not included or licensed by this package. Publication of this source package does not imply upstream adoption or a prize submission.
