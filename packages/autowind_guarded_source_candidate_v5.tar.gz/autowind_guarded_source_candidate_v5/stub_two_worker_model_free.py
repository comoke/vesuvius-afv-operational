#!/usr/bin/env python3
"""Test-only crop worker with controlled timing; no model or real data."""
import json
import pathlib
import sys
import time
import uuid

import guarded as g

plan_path = pathlib.Path(sys.argv[1])
workdir = pathlib.Path(sys.argv[2])
name = sys.argv[3]
plan = g.load_plan(plan_path)
schedule = json.loads((workdir / 'SCHEDULE.json').read_text())

def solve(crop, config):
    events = workdir / 'compute_events'
    events.mkdir(exist_ok=True)
    (events / f'{name}.{uuid.uuid4().hex}').write_text(config['crop_cache'] + '\n')
    time.sleep(schedule[name])
    return crop, {}

action = g.commit_one(workdir, plan, name, solve)
print(json.dumps({'name': name, 'action': action}), flush=True)
