#!/usr/bin/env python3
"""Small synthetic checkpoint contract test; no autowind model is run."""
from __future__ import annotations

import copy
import json
import pathlib
import sys
import tempfile

import guarded as g


def expect_error(fn, fragment: str) -> None:
    try:
        fn()
    except RuntimeError as exc:
        assert fragment in str(exc), str(exc)
    else:
        raise AssertionError(f'expected failure containing {fragment!r}')


def main() -> None:
    calls = []
    with tempfile.TemporaryDirectory(prefix='guarded_model_free_', dir=pathlib.Path(__file__).resolve().parent) as td:
        root = pathlib.Path(td)
        source = root / 'source_chunk'
        source.write_bytes(b'fixed synthetic source')
        crops = {
            '1_0_0.pkl': {'zc': 1, 'zs': [1], 'theta': 0.0, 'k': 0, 'rk': 5.0, 'o': [0, 0, 0]},
            '1_0_1.pkl': {'zc': 1, 'zs': [1], 'theta': 0.0, 'k': 1, 'rk': 6.0, 'o': [0, 0, 1]},
        }
        plan = {'version': 1, 'source_commit': 'synthetic-only', 'source_root': str(root),
                'runtime': g.runtime_fingerprint(),
                'options': {}, 'config': {'seg': 10}, 'input_sha256': {str(source): g.sha(source)},
                'shared_inputs': [str(source)], 'crop_inputs': {name: [] for name in crops},
                'crops': crops, 'workers': 1, 'lock_wait_seconds': 1,
                'free_preflight_floor_percent': 55, 'free_abort_floor_percent': 45,
                'wall_limit_seconds': 5}
        plan_file = root / 'PLAN.json'
        plan_file.write_text(json.dumps(plan, indent=2) + '\n')
        plan = g.load_plan(plan_file)
        workdir = root / 'work'
        g.verify_inputs(plan)
        g.manifest(workdir, plan)

        def solve(crop, config):
            calls.append(crop['k'])
            return crop, {1: {'cr': [], 'tc': 1.0, 'tlo': 0.0, 'thi': 2.0}}

        assert g.verify_committed_set(workdir, plan) == ([], list(crops))
        assert g.commit_one(workdir, plan, '1_0_0.pkl', solve) == 'computed'
        first = g.committed(workdir, plan, '1_0_0.pkl')
        assert first['checkpoint_sha256'] and first['crop_sha256'] == g.json_sha(crops['1_0_0.pkl'])
        assert first['summary'] == {'state': 'mapping', 'z_count': 1}
        assert g.commit_one(workdir, plan, '1_0_0.pkl', solve) == 'reused_after_lock'
        assert calls == [0]
        expect_error(lambda: g.publish_crops(workdir, plan), 'lack commits')

        # A scratch directory left before atomic rename has no committed status.
        interrupted = workdir / 'scratch' / 'interrupted.stage'
        interrupted.mkdir(parents=True)
        (interrupted / 'checkpoint.pkl').write_bytes(b'incomplete')
        assert g.commit_one(workdir, plan, '1_0_1.pkl', solve) == 'computed'
        assert calls == [0, 1]
        published = g.publish_crops(workdir, plan)
        for name in crops:
            assert (published / name).samefile(workdir / 'committed' / name.removesuffix('.pkl') / 'checkpoint.pkl')
        assert g.publish_crops(workdir, plan) == published

        # Malformed sidecar and changed payload are refused, without recomputation.
        receipt_path = workdir / 'committed' / '1_0_0' / 'receipt.json'
        original_receipt = receipt_path.read_bytes()
        receipt_path.write_text('{}')
        expect_error(lambda: g.committed(workdir, plan, '1_0_0.pkl'), 'payload mismatch')
        receipt_path.write_bytes(original_receipt)
        payload_path = workdir / 'committed' / '1_0_0' / 'checkpoint.pkl'
        original_payload = payload_path.read_bytes()
        payload_path.write_bytes(b'wrong payload')
        try:
            g.committed(workdir, plan, '1_0_0.pkl')
        except Exception:
            pass
        else:
            raise AssertionError('wrong payload accepted')
        payload_path.write_bytes(original_payload)
        assert g.committed(workdir, plan, '1_0_0.pkl') == first

        changed = copy.deepcopy(plan)
        changed['config']['seg'] = 11
        expect_error(lambda: g.manifest(workdir, changed), 'manifest mismatch')
        changed_runtime = copy.deepcopy(plan)
        changed_runtime['runtime']['guarded_sha256'] = '0' * 64
        expect_error(lambda: g.commit_one(workdir, changed_runtime, '1_0_0.pkl', solve),
                     'adapter/runtime identity mismatch')
        changed_runtime = copy.deepcopy(plan)
        changed_runtime['runtime']['packages']['numpy']['version'] = '0.0.0'
        expect_error(lambda: g.verify_inputs(changed_runtime), 'adapter/runtime identity mismatch')
        production_like = copy.deepcopy(plan)
        production_like['source_commit'] = '87dc53454943bd5c4462aabaab2d01355c31bea9'
        expect_error(lambda: g.commit_one(root / 'alternate_solver', production_like,
                                          '1_0_0.pkl', solve), 'test-only')
        source.write_bytes(b'changed synthetic source')
        expect_error(lambda: g.commit_one(workdir, plan, '1_0_0.pkl', solve), 'input identity mismatch')
        assert calls == [0, 1]
        source.write_bytes(b'fixed synthetic source')
        assert g.verify_committed_set(workdir, plan) == (list(crops), [])

        invalid = root / 'invalid_result'
        g.manifest(invalid, plan)
        expect_error(lambda: g.commit_one(invalid, plan, '1_0_0.pkl',
                                          lambda crop, config: (crop, {2: {}})),
                     'invalid checkpoint result keys')
        assert g.verify_committed_set(invalid, plan) == ([], list(crops))

        # Simulate a crash at the final directory promotion boundary.
        atomic = root / 'atomic_failure'
        g.manifest(atomic, plan)
        rename = g.os.rename
        def fail_rename(src, dst):
            raise RuntimeError('synthetic promotion failure')
        g.os.rename = fail_rename
        try:
            expect_error(lambda: g.commit_one(atomic, plan, '1_0_0.pkl',
                                               lambda crop, config: (crop, {})),
                         'synthetic promotion failure')
        finally:
            g.os.rename = rename
        assert g.verify_committed_set(atomic, plan) == ([], list(crops))
        assert list((atomic / 'scratch').glob('*.stage'))
        assert g.commit_one(atomic, plan, '1_0_0.pkl', lambda crop, config: (crop, {})) == 'computed'
        assert g.committed(atomic, plan, '1_0_0.pkl') is not None

        # Actual parent/subprocess retry: first test worker stops before commit;
        # the next invocation keeps attempt_0000 and completes both unknown outputs.
        serial = root / 'serial_run'
        g.manifest(serial, plan)
        stub = pathlib.Path(__file__).with_name('stub_worker_model_free.py')
        command = lambda name: [sys.executable, str(stub), str(plan_file), str(serial), name]
        expect_error(lambda: g.run_guarded(plan_file, serial, plan, command), 'worker 1_0_0.pkl failed')
        old_log = serial / 'logs/1_0_0/attempt_0000.log'
        assert 'test-only stop before commit' in old_log.read_text()
        assert g.verify_committed_set(serial, plan) == ([], list(crops))
        run = g.run_guarded(plan_file, serial, plan, command)
        assert run['status'] == 'COMPLETE' and run['remaining'] == []
        assert [a['action'] for a in run['worker_actions']] == ['computed', 'computed']
        assert old_log.read_text().strip() == 'test-only stop before commit'
        assert (serial / 'logs/1_0_0/attempt_0001.log').is_file()
        reused_run = g.run_guarded(plan_file, serial, plan, command)
        assert reused_run['reused_at_start'] == list(crops) and reused_run['worker_actions'] == []

    result = {'status': 'PASS', 'synthetic_crop_count': 2, 'compute_calls': calls,
              'checks': ['unknown-output receipt commit', 'resume without compute',
                         'incomplete staging ignored', 'published upstream pickle hardlinks',
                         'sidecar mismatch refusal', 'payload corruption refusal',
                         'manifest drift refusal', 'adapter/runtime refusal', 'alternate solver refusal',
                         'changed source refusal',
                         'malformed result rejected before commit',
                         'failed atomic promotion leaves no commit',
                         'subprocess stopped-log retry', 'serial parent complete reuse']}
    output = pathlib.Path(__file__).resolve().parent / 'MODEL_FREE_RESULT.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
