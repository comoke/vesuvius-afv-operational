# Multi-ROI native fiber candidate pack

This opt-in helper accepts 1–8 named ROI boxes in one frozen JSON manifest,
opens one source-bound native fiber store read-only, and emits both a
deduplicated union and a complete single-ROI pack for each box. The per-ROI
nonempty packs can be read by the included `bridge_native_roi.py` through the pinned
upstream Fiber JSON v4 transport. No geometry is clipped or edited. Upstream
`vc_object_store` already provides the spatial query and transport APIs;
this helper adds an operator-level batch manifest and deduplication.
V2 additionally checks the loaded native binding's binary SHA-256 against
the frozen input before making an output; V1 output is preserved separately.
V3 also rechecks the volume metadata and Zarr array metadata immediately
before writing the final completion marker. V4 restores the V2 meaning of
`native_prefilter_rows`: all native spatial rows before selecting
`line_points`. V5 changes only release notices from V4; earlier
source/results remain preserved separately.

The reviewed local demonstration fixed four boxes before querying: origin,
two 64-voxel half shifts, and a center control. They produced 7, 8, 20 and
0 memberships; 35 memberships reduce to 25 unique fibers and 940 original
points. Ten duplicate memberships were represented once in the union. All
four per-ROI JSONL files matched independent single-ROI exporter runs
byte-for-byte. One shifted ROI then imported all 20 fibers and 738 original
points into a standalone native store. This is a geometry-workflow result on
one task-local Scroll 3 development frame, not independent sheet validation.

## Run from extracted source

Use Python 3.14 with a compatible `vc_object_store` native binding built from
ScrollPrize/villa commit `39a8cf3a124bdd5540ee826e1cb30047c8dc8c85`.
Set `PYTHONPATH` to the directory containing that binding; Python adds this
source directory when invoking the script:

```sh
PYTHONPATH=/path/to/pinned/native/python python3 multi_roi.py freeze.json new-output-dir
```

The frozen JSON needs `experiment_id`, `status`, source store path/SHA-256,
local volume metadata and Zarr array paths/SHA-256, local `volume_id`,
`coordinate_space`, voxel size, exact
`exporter_v2_sha256` of this package's `export_native_fiber_roi.py`,
`native_binding_sha256` of the loaded extension, and unique named `rois`
with six closed-box XYZ coordinates each. See the script
for the exact protocol constants and `freeze.example.json` for placeholders.
Replace every placeholder and freeze the resulting manifest before querying;
the example itself is not an admitted input. The output path must not already exist or
alias a protected source. It writes `BATCH_MANIFEST.json`, one
`union_fibers.jsonl` row per original fiber with `roi_hits`, and a
`rois/<id>` single-ROI pack. `COMPLETE.json` is written last. Native indexed
candidates are refined by exact closed segment/box intersection. The script
hashes present local CT chunks and checks them again before completion;
those hashes attest observed bytes, not official remote origin.

To create an optional native store for one ROI, point
`bridge_native_roi.py` at `rois/<id>` with an exact source-store hash and
task-local volume/frame in its own `bridge_spec.json`. This was tested for
the 20-fiber shifted ROI. The bridge imports source-aligned fibers only; it
does not create patch objects or fiber–patch constraint edges.

## Boundaries and attribution

The source store, CT chunks, AFV, native extension and resulting `.vcobj`
are external, not included. The four-box result does not establish a public
scan transform, sheet identity, tracing quality, reading gain, speedup or
human time saving. It replaces four manual exporter invocations and union
deduplication with one batch command for this workflow; no operator-time
study was performed.

The scripts use the MIT-declared Villa object-store API at the pinned commit;
its MIT notice is included as `LICENSE-UPSTREAM-VILLA-MIT.txt`. The separate
VC3D/volume-cartographer viewer is GPL-3.0-or-later and is not included.
Original helper code and tests have the scoped MIT grant in
`LICENSE-TASK-ADDITIONS.txt`; see `NOTICE.md`. This source-only archive contains no native binary or source CT.
