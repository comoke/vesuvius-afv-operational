#!/usr/bin/env python3
"""Verify a native ROI pack and transfer its full fibers through Fiber JSON v4.

This is a private geometry transport check. It creates no links, constraints, or
sheet labels. Requires the pinned vc_object_store Python binding.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import struct
import sys

from vc_object_store import ObjectStore


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def require_hash(path: Path, expected: str, label: str) -> None:
    if path.is_symlink() or not path.is_file() or sha(path) != expected:
        raise ValueError(f"{label} missing or hash mismatch")


def checked_path(raw: str, label: str) -> Path:
    """Refuse symlinked input/output path components before resolving them."""
    path = Path(raw).expanduser().absolute()
    if any(component.is_symlink() for component in (path, *path.parents)):
        raise ValueError(f"{label} path contains symlink")
    return path.resolve()


def line_bytes(points: list) -> bytes:
    if not isinstance(points, list) or len(points) < 2:
        raise ValueError("invalid line points")
    if any(not isinstance(p, list) or len(p) != 3 for p in points):
        raise ValueError("invalid line point shape")
    return b"".join(struct.pack("<ddd", *p) for p in points)


def run(spec: dict) -> dict:
    for key in ("source_store", "source_store_sha256", "pack_dir", "output",
                "expected_volume_id", "expected_coordinate_space"):
        if key not in spec:
            raise ValueError(f"missing spec field {key}")
    source = checked_path(spec["source_store"], "source store")
    pack = checked_path(spec["pack_dir"], "ROI pack")
    output = checked_path(spec["output"], "output")
    if output.exists() or output.is_symlink():
        raise ValueError("output exists; refusing overwrite")
    if output.is_relative_to(pack) or output.is_relative_to(source.parent):
        raise ValueError("output inside source or ROI pack")
    require_hash(source, spec["source_store_sha256"], "source store")
    complete_path, manifest_path, rows_path = (pack / name for name in
                                                ("COMPLETE.json", "MANIFEST.json", "fibers.jsonl"))
    if any(p.is_symlink() for p in (complete_path, manifest_path, rows_path)):
        raise ValueError("symlink in ROI pack")
    complete = json.loads(complete_path.read_text())
    if complete.get("status") != "COMPLETE_READ_ONLY_ROI_CANDIDATES":
        raise ValueError("ROI pack incomplete")
    require_hash(manifest_path, complete["manifest_sha256"], "ROI manifest")
    require_hash(rows_path, complete["fibers_jsonl_sha256"], "ROI rows")
    manifest = json.loads(manifest_path.read_text())
    if (manifest.get("schema") != "afv_native_roi_candidate_pack_v1" or
            manifest.get("source_store_sha256") != spec["source_store_sha256"] or
            manifest.get("volume_id") != spec["expected_volume_id"] or
            manifest.get("coordinate_space") != spec["expected_coordinate_space"] or
            manifest.get("level") != 0 or manifest.get("scale_factor") != 1 or
            manifest.get("fibers_jsonl_sha256") != complete["fibers_jsonl_sha256"]):
        raise ValueError("ROI source, frame or payload mismatch")
    rows = [json.loads(line) for line in rows_path.read_text().splitlines()]
    ids = [r["object_uuid"] for r in rows]
    if (not rows or len(ids) != len(set(ids)) or ids != sorted(ids) or
            len(rows) != manifest["exact_intersecting_fibers"] or
            sum(r["line_point_count"] for r in rows) != manifest["exported_original_points"]):
        raise ValueError("ROI row count or order mismatch")
    for row in rows:
        if (len(row["points_xyz"]) != row["line_point_count"] or
                hashlib.sha256(line_bytes(row["points_xyz"])).hexdigest() !=
                row["line_points_sha256"]):
            raise ValueError("ROI line data mismatch")

    # Preflight every revision and byte array before creating any output.
    revisions = {}
    source_afv = {}
    with ObjectStore.open(str(source), read_only=True) as store:
        for row in rows:
            uid = row["object_uuid"]
            obj = store.current_object_revision(uid)
            geom = store.current_geometry(uid)
            if (obj["geometry_revision"] != row["geometry_revision_uuid"] or
                    geom["uuid"] != row["geometry_revision_uuid"] or
                    geom["content_hash"] != row["geometry_content_hash"] or
                    obj["record"]["meta"].get("coordinates") !=
                    {"volume_uuid": spec["expected_volume_id"], "scale_factor": 1} or
                    store.read_geometry_array(geom["uuid"], "line_points") !=
                    line_bytes(row["points_xyz"])):
                raise ValueError(f"source revision, binding or geometry mismatch: {uid}")
            revisions[uid] = obj["uuid"]
            source_afv[uid] = obj["record"]["meta"]["source"]["afv"]
            if (source_afv[uid]["fiber_id"] != row["source_afv_fiber_id"] or
                    source_afv[uid]["collection_uuid"] != manifest["collection_uuid"]):
                raise ValueError(f"AFV source identity mismatch: {uid}")
    require_hash(source, spec["source_store_sha256"], "source store after preflight")

    output.mkdir(parents=True, exist_ok=False)
    native = output / "fiber_json_v4"
    native.mkdir()
    transfers = []
    with ObjectStore.open(str(source), read_only=True) as store:
        for row in rows:
            uid = row["object_uuid"]
            path = native / f"{uid}.json"
            exported_revision = store.export_geometry(
                uid, str(path), object_revision_uuid=revisions[uid])
            fiber = json.loads(path.read_text())
            if (exported_revision != row["geometry_revision_uuid"] or
                    fiber.get("version") != 4 or fiber.get("uuid") != uid or
                    fiber.get("coordinates") !=
                    {"volume_uuid": spec["expected_volume_id"], "scale_factor": 1} or
                    fiber.get("afv") != source_afv[uid] or
                    fiber.get("branches") != [] or
                    fiber.get("adjacent_branches") != [] or
                    line_bytes(fiber["line_points"]) != line_bytes(row["points_xyz"])):
                raise ValueError(f"native Fiber JSON mismatch: {uid}")
            transfers.append({"object_uuid": uid,
                              "source_object_revision_uuid": revisions[uid],
                              "source_geometry_revision_uuid": exported_revision,
                              "source_line_points_sha256": row["line_points_sha256"],
                              "fiber_json_v4_sha256": sha(path),
                              "fiber_json_v4_bytes": path.stat().st_size})
    require_hash(source, spec["source_store_sha256"], "source store after export")

    target = output / "roi-fibers.vcobj"
    with ObjectStore.create(str(target), author="private-roi-bridge") as store:
        for item in transfers:
            path = native / f"{item['object_uuid']}.json"
            report = store.ingest_geometry_source("fiber", str(path))
            if (report.get("ingested") != 1 or report.get("problems") or
                    report.get("edges_imported") != 0):
                raise ValueError(f"native ingest mismatch: {item['object_uuid']}: {report}")
            uid = item["object_uuid"]
            obj = store.object(uid)
            geom = store.current_geometry(uid)
            if (obj["meta"].get("coordinates") !=
                    {"volume_uuid": spec["expected_volume_id"], "scale_factor": 1} or
                    obj["meta"]["source"] !=
                    {"afv": source_afv[uid], "filename": f"{uid}.json"} or
                    hashlib.sha256(store.read_geometry_array(geom["uuid"], "line_points")).hexdigest()
                    != item["source_line_points_sha256"]):
                raise ValueError(f"native ingested geometry mismatch: {uid}")
            item["imported_geometry_revision_uuid"] = geom["uuid"]
        store.checkpoint()
    # The native store defaults to WAL. Reuse the reviewed AFV importer
    # finalization sequence: close writers, switch the staged copy to DELETE,
    # then verify a relocated main-file-only read. This is essential for an
    # independently transferable artifact.
    with contextlib.closing(sqlite3.connect(target.resolve().as_uri() + "?mode=rw", uri=True)) as db:
        mode = db.execute("PRAGMA journal_mode=DELETE").fetchone()
        if mode is None or mode[0].lower() != "delete":
            raise ValueError("cannot finalize native store as standalone")
        if db.execute("PRAGMA integrity_check").fetchone() != ("ok",):
            raise ValueError("native store failed SQLite integrity check")
    if any(Path(str(target) + suffix).exists() for suffix in ("-wal", "-shm")):
        raise ValueError("native store still depends on WAL sidecars")
    relocated = output / "main_only_probe" / target.name
    relocated.parent.mkdir()
    shutil.copy2(target, relocated)
    # A fresh read-only open with no sidecars verifies actual portability.
    with ObjectStore.open(str(relocated), read_only=True) as store:
        imported = sorted(o["uuid"] for o in store.objects_by_kind("fiber"))
        if imported != ids:
            raise ValueError("fresh read-only imported UUID set mismatch")
        for item in transfers:
            geom = store.current_geometry(item["object_uuid"])
            if hashlib.sha256(store.read_geometry_array(geom["uuid"], "line_points")).hexdigest() != item["source_line_points_sha256"]:
                raise ValueError("fresh read-only imported line mismatch")
            uid = item["object_uuid"]
            if store.object(uid)["meta"]["source"] != \
                    {"afv": source_afv[uid], "filename": f"{uid}.json"}:
                raise ValueError("fresh read-only AFV provenance mismatch")
    if sha(relocated) != sha(target):
        raise ValueError("relocated store changed during read-only verification")
    if any(Path(str(relocated) + suffix).exists() for suffix in ("-wal", "-shm")):
        raise ValueError("read-only relocation created WAL sidecars")
    require_hash(source, spec["source_store_sha256"], "source store after import")
    result = {"schema": "afv_roi_native_bridge_v5",
              "source_store_sha256": spec["source_store_sha256"],
              "roi_manifest_sha256": sha(manifest_path),
              "roi_rows_sha256": sha(rows_path),
              "volume_id": spec["expected_volume_id"],
              "coordinate_space": spec["expected_coordinate_space"],
              "transfer_format": "Fiber JSON v4",
              "fibers": len(transfers),
              "original_line_points": sum(r["line_point_count"] for r in rows),
              "source_afv_ids_and_annotations_preserved": len(transfers),
              "ingest_added_source_filename_field": True,
              "branch_edges_in_source": 0,
              "native_store_sha256": sha(target),
              "relocated_main_only_sha256": sha(relocated),
              "sqlite_journal_mode": "delete",
              "sqlite_integrity_check": "ok",
              "transfers": transfers,
              "limit": "native transport/read only; no constraint edges, sheet identity, or reading gain"}
    (output / "RESULT.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    try:
        args = parser.parse_args()
        result = run(json.loads(args.spec.read_text()))
        print(json.dumps({k: result[k] for k in ("fibers", "original_line_points",
                                              "native_store_sha256")}, indent=2))
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(f"native ROI bridge refused: {exc}", file=sys.stderr)
        raise SystemExit(2)
