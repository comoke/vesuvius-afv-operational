"""No-data intersection checks for the private ROI source package."""
from export_native_fiber_roi import intersecting_segments, segment_intersects_box

lo, hi = [0, 0, 0], [1, 1, 1]
cases = [((-1, .5, .5), (2, .5, .5), True),
         ((-1, 2, .5), (2, 2, .5), False),
         ((-1, 1, .5), (2, 1, .5), True),
         ((.5, .5, .5), (.5, .5, .5), True),
         ((2, 2, 2), (2, 2, 2), False),
         ((-1, -1, -1), (0, 0, 0), True)]
for a, b, expected in cases:
    assert segment_intersects_box(a, b, lo, hi) is expected
assert intersecting_segments([(-1, .5, .5), (2, .5, .5)], lo, hi) == [0]
try:
    intersecting_segments([(.5, .5, .5)], lo, hi)
except ValueError as exc:
    assert "at least two points" in str(exc)
else:
    raise AssertionError("singleton point reported as segment")
print("PASS: six geometric cases, crossing without interior vertices, singleton refusal")
