# Source and license scope

The `multi_roi.py`, `export_native_fiber_roi.py`, and `bridge_native_roi.py`
helpers, model-free tests, example manifest and documentation are original
task-authored additions under the scoped MIT grant in
`LICENSE-TASK-ADDITIONS.txt`. The batch preserves the earlier reviewed
single-ROI helper code bytes.

The scripts use ScrollPrize/villa `vc_object_store` at commit
`39a8cf3a124bdd5540ee826e1cb30047c8dc8c85`. Its package metadata
declares MIT; the Villa MIT notice is preserved in
`LICENSE-UPSTREAM-VILLA-MIT.txt`. The separate VC3D/volume-cartographer
viewer has a GPL-3.0-or-later license, but no viewer source or binary is
included. The native binding, CT, AFV, model, and source object store are
external prerequisites and are not licensed by this archive.
