#!/usr/bin/env python3
"""Read-only, frame-bound native fiber ROI candidate export.

Requires the pinned vc_object_store Python extension. The output contains
complete original line arrays for fibers whose polyline intersects the ROI.
It does not infer sheet identity or clip/alter source geometry.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import resource
import struct
import sys
import time

from vc_object_store import ObjectStore


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def require_file(path: Path, expected: str, label: str) -> None:
    if not path.is_file() or path.is_symlink() or sha(path) != expected:
        raise ValueError(f"{label} missing or hash mismatch")


def checked_path(raw: str, label: str) -> Path:
    """Reject path aliases before resolution, including symlinked parents."""
    path = Path(raw).expanduser().absolute()
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError(f"{label} path contains symlink")
    return path.resolve()


def segment_intersects_box(a: tuple[float, ...], b: tuple[float, ...],
                           lower: list[float], upper: list[float]) -> bool:
    """Closed 3-D segment/AABB intersection, including boundary touches."""
    enter, leave = 0.0, 1.0
    for axis in range(3):
        delta = b[axis] - a[axis]
        if delta == 0.0:
            if a[axis] < lower[axis] or a[axis] > upper[axis]:
                return False
            continue
        lo = (lower[axis] - a[axis]) / delta
        hi = (upper[axis] - a[axis]) / delta
        if lo > hi:
            lo, hi = hi, lo
        enter, leave = max(enter, lo), min(leave, hi)
        if enter > leave:
            return False
    return True


def intersecting_segments(points: list[tuple[float, ...]],
                          lower: list[float], upper: list[float]) -> list[int]:
    if len(points) < 2:
        raise ValueError("fiber polyline needs at least two points")
    return [i for i in range(len(points) - 1)
            if segment_intersects_box(points[i], points[i + 1], lower, upper)]


def validate_spec(spec: dict) -> tuple[Path, Path, Path, Path, list[float], list[float], dict[str, str]]:
    for key in ("store", "store_sha256", "volume_meta", "volume_meta_sha256",
                "volume_zarray", "volume_zarray_sha256", "volume_id",
                "coordinate_space", "voxel_um", "roi_xyz", "output"):
        if key not in spec:
            raise ValueError(f"missing spec field {key}")
    store, meta, zarray, output = (checked_path(spec[k], k) for k in
                                  ("store", "volume_meta", "volume_zarray", "output"))
    if output.exists() or output.is_symlink():
        raise ValueError("output exists; refusing overwrite")
    if output.is_relative_to(meta.parent):
        raise ValueError("output cannot be inside the registered volume")
    require_file(store, spec["store_sha256"], "object store")
    require_file(meta, spec["volume_meta_sha256"], "volume metadata")
    require_file(zarray, spec["volume_zarray_sha256"], "volume array metadata")
    m, z = json.loads(meta.read_text()), json.loads(zarray.read_text())
    if (m.get("uuid") != spec["volume_id"] or
            m.get("coordinate_space") != spec["coordinate_space"] or
            m.get("voxelsize") != spec["voxel_um"] or
            z.get("shape") != [512, 512, 512] or
            z.get("chunks") != [64, 64, 64] or
            z.get("dimension_separator") != "." or
            z.get("dtype") != "|u1" or z.get("zarr_format") != 2 or
            meta.parent != zarray.parent):
        raise ValueError("volume ID, frame, scale or shape mismatch")
    roi = spec["roi_xyz"]
    if (not isinstance(roi, list) or len(roi) != 6 or
            any(type(v) not in (int, float) or not math.isfinite(v) for v in roi)):
        raise ValueError("ROI must be six finite XYZ numbers")
    lower, upper = roi[:3], roi[3:]
    if any(not (0 <= lower[i] < upper[i] < 512) for i in range(3)):
        raise ValueError("ROI outside declared local 512-cube")
    indices = [range(int(lower[i] // 64), int(upper[i] // 64) + 1) for i in range(3)]
    chunk_keys = [f"{z}.{y}.{x}" for z, y, x in itertools.product(indices[2], indices[1], indices[0])]
    if len(chunk_keys) > 64:
        raise ValueError("bounded exporter refuses ROI requiring over 64 CT chunks")
    chunk_hashes = {}
    for key in chunk_keys:
        path = meta.parent / key
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"missing observed CT chunk {key}")
        chunk_hashes[key] = sha(path)
    return store, meta, zarray, output, lower, upper, chunk_hashes


def validate_collection(store: ObjectStore, volume_id: str,
                        coordinate_space: str, voxel_um: float) -> tuple[str, dict, dict]:
    all_fibers = store.objects_by_kind("fiber")
    if len(all_fibers) > 10000:
        raise ValueError("bounded exporter refuses more than 10000 catalog fibers")
    matched = {f["uuid"]: f for f in all_fibers if not f.get("retired") and
               f.get("meta", {}).get("coordinates") ==
               {"volume_uuid": volume_id, "scale_factor": 1}}
    if not matched:
        raise ValueError("no fibers bound to requested local volume ID")
    collections = {f["meta"]["source"]["afv"]["collection_uuid"] for f in matched.values()}
    if len(collections) != 1:
        raise ValueError("multiple AFV collections in requested volume")
    collection_id = next(iter(collections))
    collection = store.object(collection_id)
    if collection["meta"].get("coordinates") != {"volume_uuid": volume_id, "scale_factor": 1}:
        raise ValueError("collection volume binding mismatch")
    afv = collection["meta"]["afv"]["metadata"]
    frame, root = afv["frame"], afv["root"]
    if (frame.get("vc_open_data_coordinate_space") != coordinate_space or
            frame.get("vc_open_data_source_coordinate_level") != 0 or
            frame.get("vc_open_data_source_coordinate_scale_factor") != 1 or
            root.get("coordinate_order") != "XYZ" or
            root.get("coordinate_units") != "voxel" or
            root.get("coordinate_base_shape_zyx") != [512, 512, 512] or
            root.get("vc_open_data_source_original_resolution") != voxel_um or
            collection["meta"]["local_binding"].get("source_frame") != coordinate_space):
        raise ValueError("AFV collection source frame mismatch")
    return collection_id, collection, matched


def export(spec: dict) -> dict:
    started = time.perf_counter()
    store_path, meta_path, zarray_path, output, lower, upper, chunk_hashes = validate_spec(spec)
    with ObjectStore.open(str(store_path), read_only=True) as store:
        collection_id, collection, matched = validate_collection(
            store, spec["volume_id"], spec["coordinate_space"], spec["voxel_um"])
        regions = store.spatial_regions(lower + upper, object_kind="fiber",
                                        volume=spec["volume_id"])
        line_rows = [r for r in regions if r["array_name"] == "line_points"]
        candidates = sorted({r["object_uuid"] for r in line_rows})
        if not set(candidates) <= set(matched):
            raise ValueError("spatial index returned unbound or retired fiber")
        rows = []
        for object_id in candidates:
            record = matched[object_id]
            geometry = store.current_geometry(object_id)
            revision = geometry["uuid"]
            if (geometry["coordinate_system"] != "source_xyz" or
                    any(r["revision_uuid"] != revision for r in line_rows
                        if r["object_uuid"] == object_id)):
                raise ValueError("spatial-index geometry revision mismatch")
            arrays = {a["name"]: a for a in geometry["arrays"]}
            layout = arrays.get("line_points")
            raw = store.read_geometry_array(revision, "line_points")
            if (layout is None or layout["dtype"] != "<f8" or
                    layout["shape"] != [record["fiber"]["line_point_count"], 3] or
                    len(raw) != layout["byte_length"] or len(raw) % 24):
                raise ValueError("unexpected line_points layout")
            points = list(struct.iter_unpack("<ddd", raw))
            if len(points) < 2:
                raise ValueError("fiber polyline needs at least two points")
            if not all(math.isfinite(x) for point in points for x in point):
                raise ValueError("nonfinite line coordinate")
            hit_segments = intersecting_segments(points, lower, upper)
            if not hit_segments:
                continue
            source = record["meta"]["source"]["afv"]
            if source["collection_uuid"] != collection_id:
                raise ValueError("fiber collection provenance mismatch")
            rows.append({"object_uuid": object_id,
                         "geometry_revision_uuid": revision,
                         "geometry_content_hash": geometry["content_hash"],
                         "source_afv_fiber_id": source["fiber_id"],
                         "name": record["name"],
                         "family": record["fiber"]["family"],
                         "line_points_sha256": hashlib.sha256(raw).hexdigest(),
                         "line_point_count": len(points),
                         "intersecting_segment_indices": hit_segments,
                         "points_xyz": points})
    if sha(store_path) != spec["store_sha256"]:
        raise ValueError("source store changed during export")
    if any(sha(meta_path.parent / key) != digest for key, digest in chunk_hashes.items()):
        raise ValueError("observed CT chunk changed during export")
    output.mkdir(parents=True, exist_ok=False)
    rows_path = output / "fibers.jsonl"
    with rows_path.open("x") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False) + "\n")
    manifest = {"schema": "afv_native_roi_candidate_pack_v1",
                "exporter_source_sha256": sha(Path(__file__).resolve()),
                "source_store_sha256": spec["store_sha256"],
                "volume_meta_sha256": spec["volume_meta_sha256"],
                "volume_zarray_sha256": spec["volume_zarray_sha256"],
                "observed_ct_chunk_sha256": chunk_hashes,
                "volume_id": spec["volume_id"],
                "coordinate_space": spec["coordinate_space"],
                "level": 0, "scale_factor": 1, "voxel_um": spec["voxel_um"],
                "collection_uuid": collection_id,
                "roi_xyz_closed": lower + upper,
                "selection": "exact original polyline segment intersects closed ROI; full original line points exported",
                "catalog_fibers_in_volume": len(matched),
                "native_prefilter_rows": len(regions),
                "native_line_prefilter_fibers": len(candidates),
                "exact_intersecting_fibers": len(rows),
                "exported_original_points": sum(r["line_point_count"] for r in rows),
                "fibers_jsonl_sha256": sha(rows_path),
                "interpretation_limit": "geometry candidates only; no sheet identity, branch truth or reading gain"}
    manifest_path = output / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    if (sha(store_path) != spec["store_sha256"] or
            sha(meta_path) != spec["volume_meta_sha256"] or
            sha(zarray_path) != spec["volume_zarray_sha256"] or
            any(sha(meta_path.parent / key) != digest for key, digest in chunk_hashes.items())):
        raise ValueError("source changed before ROI completion")
    complete = {"status": "COMPLETE_READ_ONLY_ROI_CANDIDATES",
                "manifest_sha256": sha(manifest_path), "fibers_jsonl_sha256": sha(rows_path),
                "elapsed_seconds": time.perf_counter() - started,
                "peak_rss_raw": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                "peak_rss_units": "bytes_on_macos_other_platforms_may_differ",
                "output_bytes": manifest_path.stat().st_size + rows_path.stat().st_size,
                "source_unchanged": True}
    (output / "COMPLETE.json").write_text(json.dumps(complete, sort_keys=True, indent=2) + "\n")
    return {**manifest, **complete}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    args = parser.parse_args()
    result = export(json.loads(args.spec.read_text()))
    print(json.dumps({k: result[k] for k in ("status", "exact_intersecting_fibers",
                                              "exported_original_points", "elapsed_seconds",
                                              "peak_rss_raw", "output_bytes")}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError) as exc:
        print(f"ROI export refused: {exc}", file=sys.stderr)
        raise SystemExit(2)
