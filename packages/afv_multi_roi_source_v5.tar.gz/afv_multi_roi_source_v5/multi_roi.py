#!/usr/bin/env python3
"""One-open, read-only native fiber selection for several source-bound ROIs.

Each ROI receives a complete single-ROI candidate pack usable by the existing
native bridge. A union file records each original fiber once with per-ROI hit
segments. This creates no patch constraints or modified geometry.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import struct
import sys

from vc_object_store import ObjectStore
from vc_object_store import _native as native_binding
from export_native_fiber_roi import (checked_path, intersecting_segments,
                                      require_file, validate_collection,
                                      validate_spec)


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def write_rows(path: Path, rows: list[dict]) -> None:
    with path.open("x") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False) + "\n")


def run(freeze_path: Path, output_raw: str) -> dict:
    freeze_path = checked_path(str(freeze_path), "freeze")
    output = checked_path(output_raw, "output")
    if output.exists() or output.is_symlink():
        raise ValueError("output exists; refusing overwrite")
    freeze = json.loads(freeze_path.read_text())
    if (freeze.get("experiment_id") != "TASK10-AFV-MULTI-ROI-20261101" or
            freeze.get("status") != "frozen_before_selection" or
            freeze.get("selection") !=
            "native index prefilter followed by exact closed segment-AABB; full original line once per unique UUID"):
        raise ValueError("unexpected frozen protocol")
    source_module = Path(sys.modules[intersecting_segments.__module__].__file__).resolve()
    if sha(source_module) != freeze["exporter_v2_sha256"]:
        raise ValueError("single-ROI geometry validator source differs")
    if sha(Path(native_binding.__file__).resolve()) != freeze["native_binding_sha256"]:
        raise ValueError("native object-store binding differs from frozen source")
    if not freeze.get("no_public_scan_or_patch_identity"):
        raise ValueError("source/frame scope not declared")
    rois = freeze.get("rois")
    if (not isinstance(rois, list) or not 1 <= len(rois) <= 8 or
            len({r.get("id") for r in rois if isinstance(r, dict)}) != len(rois)):
        raise ValueError("expected 1–8 uniquely named ROIs")
    base = {"store": freeze["source_store"],
            "store_sha256": freeze["source_store_sha256"],
            "volume_meta": freeze["volume_meta"],
            "volume_meta_sha256": freeze["volume_meta_sha256"],
            "volume_zarray": freeze["volume_zarray"],
            "volume_zarray_sha256": freeze["volume_zarray_sha256"],
            "volume_id": freeze["volume_id"],
            "coordinate_space": freeze["coordinate_space"],
            "voxel_um": freeze["voxel_um"]}
    validated = {}
    union_chunks = {}
    for roi in rois:
        name = roi.get("id")
        if (not isinstance(name, str) or not name or
                any(c not in "abcdefghijklmnopqrstuvwxyz0123456789_" for c in name)):
            raise ValueError("ROI ID must be lowercase alphanumeric/underscore")
        spec = {**base, "roi_xyz": roi["roi_xyz"], "output": str(output / "rois" / name)}
        store_path, meta_path, zarray_path, _, lo, hi, chunks = validate_spec(spec)
        if output.is_relative_to(store_path.parent):
            raise ValueError("output inside source-store directory")
        validated[name] = {"lo": lo, "hi": hi, "chunks": chunks}
        for key, digest in chunks.items():
            if key in union_chunks and union_chunks[key] != digest:
                raise ValueError("CT chunk changed during preflight")
            union_chunks[key] = digest
    require_file(store_path, base["store_sha256"], "source store before selection")
    requested_by: dict[str, set[str]] = {}
    native_rows = {}
    native_prefilter_row_counts = {}
    native_candidate_counts = {}
    with ObjectStore.open(str(store_path), read_only=True) as store:
        collection_id, _, matched = validate_collection(
            store, base["volume_id"], base["coordinate_space"], base["voxel_um"])
        for name, item in validated.items():
            regions = store.spatial_regions(item["lo"] + item["hi"],
                                            object_kind="fiber", volume=base["volume_id"])
            native_prefilter_row_counts[name] = len(regions)
            line_rows = [r for r in regions if r["array_name"] == "line_points"]
            native_rows[name] = line_rows
            candidates = {r["object_uuid"] for r in line_rows}
            native_candidate_counts[name] = len(candidates)
            if not candidates <= set(matched):
                raise ValueError("native index returned unbound or retired fiber")
            for uid in candidates:
                requested_by.setdefault(uid, set()).add(name)
        all_rows = []
        for uid in sorted(requested_by):
            record = matched[uid]
            geometry = store.current_geometry(uid)
            revision = geometry["uuid"]
            if geometry["coordinate_system"] != "source_xyz":
                raise ValueError("non-source geometry frame")
            if any(r["revision_uuid"] != revision for name in requested_by[uid]
                   for r in native_rows[name] if r["object_uuid"] == uid):
                raise ValueError("native index geometry revision mismatch")
            layout = {a["name"]: a for a in geometry["arrays"]}.get("line_points")
            raw = store.read_geometry_array(revision, "line_points")
            if (layout is None or layout["dtype"] != "<f8" or
                    layout["shape"] != [record["fiber"]["line_point_count"], 3] or
                    layout["byte_length"] != len(raw) or len(raw) % 24):
                raise ValueError("unexpected line_points layout")
            points = list(struct.iter_unpack("<ddd", raw))
            if len(points) < 2 or not all(math.isfinite(v) for p in points for v in p):
                raise ValueError("invalid fiber polyline")
            source = record["meta"]["source"]["afv"]
            if source["collection_uuid"] != collection_id:
                raise ValueError("AFV collection mismatch")
            hits = {name: intersecting_segments(points, validated[name]["lo"], validated[name]["hi"])
                    for name in sorted(requested_by[uid])}
            hits = {name: indices for name, indices in hits.items() if indices}
            if not hits:
                continue
            all_rows.append({"object_uuid": uid, "geometry_revision_uuid": revision,
                             "geometry_content_hash": geometry["content_hash"],
                             "source_afv_fiber_id": source["fiber_id"],
                             "name": record["name"], "family": record["fiber"]["family"],
                             "line_points_sha256": hashlib.sha256(raw).hexdigest(),
                             "line_point_count": len(points),
                             "points_xyz": points, "roi_hits": hits})
    require_file(store_path, base["store_sha256"], "source store after selection")
    require_file(meta_path, base["volume_meta_sha256"], "volume metadata after selection")
    require_file(zarray_path, base["volume_zarray_sha256"], "array metadata after selection")
    if any(sha(meta_path.parent / key) != digest for key, digest in union_chunks.items()):
        raise ValueError("observed CT chunk changed during selection")

    output.mkdir(parents=True, exist_ok=False)
    (output / "rois").mkdir()
    exporter_sha = sha(Path(__file__).resolve())
    per_roi = {}
    for name, item in validated.items():
        directory = output / "rois" / name
        directory.mkdir()
        rows = []
        for row in all_rows:
            if name in row["roi_hits"]:
                one = {k: v for k, v in row.items() if k != "roi_hits"}
                one["intersecting_segment_indices"] = row["roi_hits"][name]
                rows.append(one)
        rows_path = directory / "fibers.jsonl"
        write_rows(rows_path, rows)
        manifest = {"schema": "afv_native_roi_candidate_pack_v1",
                    "exporter_source_sha256": exporter_sha,
                    "source_store_sha256": base["store_sha256"],
                    "volume_meta_sha256": base["volume_meta_sha256"],
                    "volume_zarray_sha256": base["volume_zarray_sha256"],
                    "observed_ct_chunk_sha256": item["chunks"],
                    "volume_id": base["volume_id"],
                    "coordinate_space": base["coordinate_space"],
                    "level": 0, "scale_factor": 1, "voxel_um": base["voxel_um"],
                    "collection_uuid": collection_id,
                    "roi_xyz_closed": item["lo"] + item["hi"],
                    "selection": "exact original polyline segment intersects closed ROI; full original line points exported",
                    "catalog_fibers_in_volume": len(matched),
                    "native_prefilter_rows": native_prefilter_row_counts[name],
                    "native_line_prefilter_fibers": native_candidate_counts[name],
                    "exact_intersecting_fibers": len(rows),
                    "exported_original_points": sum(r["line_point_count"] for r in rows),
                    "fibers_jsonl_sha256": sha(rows_path),
                    "interpretation_limit": "geometry candidates only; no sheet identity, branch truth or reading gain"}
        manifest_path = directory / "MANIFEST.json"
        write_json(manifest_path, manifest)
        write_json(directory / "COMPLETE.json",
                   {"status": "COMPLETE_READ_ONLY_ROI_CANDIDATES",
                    "manifest_sha256": sha(manifest_path),
                    "fibers_jsonl_sha256": sha(rows_path),
                    "source_unchanged": True})
        per_roi[name] = {"roi_xyz": item["lo"] + item["hi"],
                         "fiber_ids": [r["object_uuid"] for r in rows],
                         "point_count_repeated": sum(r["line_point_count"] for r in rows),
                         "pack_manifest_sha256": sha(manifest_path),
                         "pack_rows_sha256": sha(rows_path)}
    union_path = output / "union_fibers.jsonl"
    write_rows(union_path, all_rows)
    manifest_path = output / "BATCH_MANIFEST.json"
    manifest = {"schema": "afv_multi_roi_candidate_batch_v1",
                "freeze_sha256": sha(freeze_path),
                "batch_source_sha256": exporter_sha,
                "source_store_sha256": base["store_sha256"],
                "volume_id": base["volume_id"],
                "coordinate_space": base["coordinate_space"],
                "voxel_um": base["voxel_um"],
                "level": 0, "scale_factor": 1,
                "observed_ct_chunks_unique": len(union_chunks),
                "unique_ct_chunk_sha256": union_chunks,
                "per_roi": per_roi,
                "unique_fibers": len(all_rows),
                "unique_original_points": sum(r["line_point_count"] for r in all_rows),
                "roi_memberships": sum(len(r["roi_hits"]) for r in all_rows),
                "duplicate_memberships_avoided": sum(len(r["roi_hits"]) - 1 for r in all_rows),
                "union_fibers_jsonl_sha256": sha(union_path),
                "limit": "source-bound geometry candidates; no patch links or sheet/reading validation"}
    write_json(manifest_path, manifest)
    require_file(store_path, base["store_sha256"], "source store before completion")
    require_file(meta_path, base["volume_meta_sha256"], "volume metadata before completion")
    require_file(zarray_path, base["volume_zarray_sha256"], "array metadata before completion")
    if any(sha(meta_path.parent / key) != digest for key, digest in union_chunks.items()):
        raise ValueError("observed CT chunk changed before completion")
    write_json(output / "COMPLETE.json",
               {"status": "COMPLETE_MULTI_ROI_CANDIDATES",
                "batch_manifest_sha256": sha(manifest_path),
                "union_fibers_jsonl_sha256": sha(union_path),
                "source_unchanged": True})
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("freeze", type=Path)
    parser.add_argument("output")
    try:
        args = parser.parse_args()
        result = run(args.freeze, args.output)
        print(json.dumps({k: result[k] for k in ("unique_fibers", "unique_original_points",
                                                "roi_memberships", "duplicate_memberships_avoided")},
                         indent=2))
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(f"multi-ROI export refused: {exc}", file=sys.stderr)
        raise SystemExit(2)
