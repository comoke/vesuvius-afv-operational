"""No-data check of both scripts' declared path-alias refusal."""
from pathlib import Path
import tempfile

from bridge_native_roi import checked_path as bridge_path
from export_native_fiber_roi import checked_path as exporter_path

with tempfile.TemporaryDirectory(prefix="roi-path-", dir=Path(__file__).resolve().parent) as temp:
    root = Path(temp)
    ordinary = root / "ordinary"
    ordinary.write_text("fixture")
    link = root / "link"
    link.symlink_to(ordinary)
    parent = root / "parent"
    parent.symlink_to(root, target_is_directory=True)
    for checker in (bridge_path, exporter_path):
        assert checker(str(ordinary), "fixture") == ordinary
        for alias in (link, parent / "ordinary"):
            try:
                checker(str(alias), "fixture")
            except ValueError as exc:
                assert "contains symlink" in str(exc)
            else:
                raise AssertionError(f"accepted alias: {alias}")

print("PASS: both scripts reject leaf and parent aliases; ordinary path accepted")
