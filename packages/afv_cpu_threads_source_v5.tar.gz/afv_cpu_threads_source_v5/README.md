# Opt-in CPU thread setting for the AFV operator

This source-only patch adds a recorded two-or-eight-thread choice to the
task-authored AFV operator for Villa commit
`8ff06f7620dcb663ed327028dbb8a0cf7e9a8198`. The two-thread setting
remains the default. A source-pinned manifest may set `config.cpu_threads`
to `8`; the operator binds that choice and its entry hash to checkpoint
identity and refuses an incomplete workdir created with a different choice.
The entry uses PyTorch's existing `torch.set_num_threads`. It does not alter
the model, tiling algorithm, spline extraction, CT or native importer.

The complete patched `operator_cpu_threads_v2.py` and `afv_8thread_entry.py`
files are included. `OPERATOR_CPU_THREADS_V2.patch` and
`AFV_CPU_THREADS_OPT_IN.patch` document their deltas against earlier
task-authored operator/entry files, which are not included in the AFV
source-only package. These patches are for review, not independent upstream
Villa patches; do not apply them to the Villa source tree.

A reproduction requires the exact Villa Python wheel, Python/model stack,
compatible checkpoint, source-backed CT, admitted operator manifest, and
the external schema-17 importer/native reader. None is bundled here.

The external resource-guard script is selected by `source.guard_rel` and
bound by `pins.guard_sha256` for both thread settings. The original
two-thread model entry is also external: its `source.model_entry_rel`
file must match `pins.model_entry_sha256` and the admitted SHA-256
`2e2c8f24bf7ca8d1789d106d7c2d9307ad9dd3e486d742769444cf3d4cb2379f`.
The bundled `afv_8thread_entry.py` has SHA-256
`24ba706ddd5337bfc75dc41279f4400ebea8772b100637e05f524b9283cc5cd0`
and is admitted only when the manifest selects eight threads. The
reviewed AFV metadata template at `legacy.afv_rel`, bound by
`legacy.afv_sha256`, is required even for a fresh run to validate its
source frame and generator metadata. This source archive alone cannot
reproduce either measured arm without the admitted manifest and these
matching external inputs.

This
bounded operator accepts only the reviewed four-block 512-by-64-by-64
Scroll 3 development region with a locally registered matching volume;
the input paths and hashes must be filled for that source. It is not a
general-purpose AFV scheduler. The accepted default remains two threads.

On one cached Scroll 3 development four-block input, paired current-source
runs at two and eight threads took 70.352 and 49.909 seconds end to end and
51.288 and 31.156 seconds for four wrapped inference calls. Both produced
exactly matching 192-fiber/4,756-point geometry; a wrong-thread restart was
refused before new model work. A separate cached Scroll 5 core also had
exact two/eight-thread current-source geometry in both tested orders; its
comparison with an older untiled output failed exact equality for two stored
bound rows by at most 7.63e-6 voxel. These same-host, sampled-memory
development results do not establish an optimal setting, general speedup,
sheet quality, reading gain, or full-scroll performance.

`LICENSE-TASK-ADDITIONS.txt` covers only original task-authored additions.
Villa and Qualzz's earlier AFV generator remain upstream work; see
`NOTICE.md` and `LICENSE-UPSTREAM-VILLA-MIT.txt`.
