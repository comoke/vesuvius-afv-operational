"""Guarded AFV entry using only the installed current-main wheel, not source injection."""
import hashlib
import json
import os
import sys
import time
from pathlib import Path

assert 'PYTHONPATH' not in os.environ
assert 'AFV_CANDIDATE_SRC' not in os.environ

import torch
from vesuvius.afv_spline_generator import cli, predict

SITE = Path(sys.prefix) / 'lib/python3.14/site-packages'
PINS = {
    'cli.py': '0cf32bfb572125c2be97021a6f71b76759030dda392d7e3201480d6925acf62e',
    'predict.py': '8230b6f18f93e15de5ab5838c5a7e82b3d2ec0134fb79214ba028d07d14a6b35',
    'checkpoint.py': 'e29212090dc2711489baac411122b4b4d57908ab9e28e8fa60769e90a2346a69',
    'tiled_conv3d.py': '4b9592c7d80122e488f7ead9c207bda50b9b1d3e854f26ffcd2b86d9a5bb49de',
}
for name, expected in PINS.items():
    path = SITE / 'vesuvius/afv_spline_generator' / name
    assert path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == expected, path
assert Path(cli.__file__).resolve().is_relative_to(SITE)
assert Path(predict.__file__).resolve().is_relative_to(SITE)

# Match the reviewed four-block entry's CPU and checkpoint-loading controls.
# Opt in to a tested CPU-only throughput setting; keep the accepted default.
threads = int(os.environ.get('AFV_CPU_THREADS', '2'))
if threads not in (2, 8):
    raise ValueError('AFV_CPU_THREADS must be 2 or 8 for this private candidate')
torch.set_num_threads(threads)
original_load = torch.load
def safe_load(path, *args, **kwargs):
    if str(path).endswith('checkpoint_final.pth'):
        kwargs['weights_only'] = True
    return original_load(path, *args, **kwargs)
torch.load = safe_load

original_predict = predict.predict_fibers
calls = 0
def timed_predict(*args, **kwargs):
    global calls
    calls += 1
    index = calls
    start = time.monotonic()
    print(json.dumps({'event': 'inference_start', 'call': index}), flush=True)
    try:
        return original_predict(*args, **kwargs)
    finally:
        print(json.dumps({'event': 'inference_end', 'call': index,
                          'seconds': time.monotonic() - start}), flush=True)
predict.predict_fibers = timed_predict

if __name__ == '__main__':
    raise SystemExit(cli.main())
