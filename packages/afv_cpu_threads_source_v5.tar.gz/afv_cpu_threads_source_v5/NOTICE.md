# Source and license scope

The task-authored thread setting, checkpoint identity guard, patch deltas,
included operator/entry files, tests and documentation are released under
the scoped MIT grant in `LICENSE-TASK-ADDITIONS.txt`. This does not assign
ownership of pre-existing code or model assets.

The AFV generator and model workflow originate with Qualzz's Villa PR #1934.
The tested Python target is ScrollPrize/villa commit
`8ff06f7620dcb663ed327028dbb8a0cf7e9a8198`; Villa's MIT license is
preserved as `LICENSE-UPSTREAM-VILLA-MIT.txt`. PyTorch supplies the existing
thread-control API. No upstream source tree, model weights, CT, native
binary or generated geometry is included.
