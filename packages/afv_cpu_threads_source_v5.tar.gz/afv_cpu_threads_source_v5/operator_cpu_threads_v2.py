"""Private exact-8ff installed wheel → fresh AFV → schema-17 native operator.

This single frozen four-block mode requires fresh model output in a new task-owned
workdir. It retains the old operator's guarded checkpoint and source admission,
then uses the independently reviewed schema-17 standalone import stages.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sqlite3
import struct
import subprocess
import sys
import tempfile
import uuid


def fail(message):
    raise RuntimeError(message)


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_sha(path, *, py_only=False):
    path = Path(path)
    h = hashlib.sha256()
    for file in sorted(p for p in path.rglob('*') if p.is_file() and (not py_only or p.suffix == '.py')):
        if file.is_symlink():
            fail(f'symlink in pinned input tree: {file}')
        h.update(str(file.relative_to(path)).encode())
        h.update(b'\0')
        with file.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(chunk)
    return h.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def require_hash(path, expected, label):
    if not Path(path).is_file():
        fail(f'{label} missing: {path}')
    actual = sha_file(path)
    if actual != expected:
        fail(f'{label} hash mismatch: {actual} != {expected}')


def load_json(path):
    return json.loads(Path(path).read_text())


def write_exclusive(path, payload):
    with Path(path).open('x') as stream:
        json.dump(payload, stream, indent=2, sort_keys=True)
        stream.write('\n')


def verify_contract(manifest, root, model_dir, importer, native_path, volume_override=None):
    source, pins, config = (manifest[k] for k in ('source', 'pins', 'config'))
    actual_contract = canonical_hash({'source': source, 'pins': pins, 'config': config})
    if actual_contract != manifest['contract_sha256']:
        fail('manifest source/config/pin mismatch; refuse old-stage reuse')
    paths = {name: root / source[key] for name, key in (
        ('volume', 'volume_rel'), ('registered_volume', 'registered_volume_rel'),
        ('code', 'model_code_rel'), ('entry', 'model_entry_rel'), ('guard', 'guard_rel'),
        ('installed_wheel', 'installed_wheel_rel'),
        ('volume_package', 'volpkg_rel'))}
    if volume_override is not None:
        paths['volume'] = volume_override.resolve()
    required = [('task root', root, True), ('--model-dir', model_dir, True),
                ('--importer', importer, False),
                ('--native-pythonpath', native_path / 'vc_object_store/__init__.py', False),
                ('CT volume', paths['volume'], True),
                ('registered local volume', paths['registered_volume'], True),
                ('pinned model source', paths['code'], True),
                ('pinned installed wheel', paths['installed_wheel'], False),
                ('model entry', paths['entry'], False),
                ('resource guard', paths['guard'], False),
                ('local volume package', paths['volume_package'], False)]
    for label, path, directory in required:
        if not (path.is_dir() if directory else path.is_file()):
            fail(f'required dependency missing ({label}): {path}')
    # Reject a different installed source or wheel before hashing CT/model trees.
    early = {
        'code_tree_sha256': tree_sha(paths['code'], py_only=True),
        'model_entry_sha256': sha_file(paths['entry']),
        'installed_wheel_sha256': sha_file(paths['installed_wheel']),
    }
    for key, actual in early.items():
        if actual != pins[key]:
            fail(f'{key} mismatch: {actual} != {pins[key]}')
    binaries = list((native_path / 'vc_object_store').glob('_native*.so'))
    if len(binaries) != 1:
        fail('expected exactly one pinned native object-store extension')
    checks = {
        'volume_tree_sha256': tree_sha(paths['volume']),
        'registered_volume_tree_sha256': tree_sha(paths['registered_volume']),
        'model_tree_sha256': tree_sha(model_dir),
        'code_tree_sha256': early['code_tree_sha256'],
        'model_entry_sha256': early['model_entry_sha256'],
        'installed_wheel_sha256': early['installed_wheel_sha256'],
        'guard_sha256': sha_file(paths['guard']),
        'importer_sha256': sha_file(importer),
        'local_meta_sha256': sha_file(paths['registered_volume'] / 'meta.json'),
        'volpkg_sha256': sha_file(paths['volume_package']),
        'native_module_sha256': sha_file(binaries[0]),
        'native_package_init_sha256': sha_file(native_path / 'vc_object_store/__init__.py'),
    }
    for key, actual in checks.items():
        if actual != pins[key]:
            fail(f'{key} mismatch: {actual} != {pins[key]}')
    zarr = load_json(paths['volume'] / '.zarray')
    attrs = load_json(paths['volume'] / '.zattrs')
    local = load_json(paths['registered_volume'] / 'meta.json')
    package = load_json(paths['volume_package'])
    entries = package.get('volumes', [])
    if len(entries) != 1 or (paths['volume_package'].parent / entries[0]['location']).resolve() != paths['registered_volume'].resolve():
        fail('volume package does not register the pinned local clone')
    tags = set(entries[0].get('tags', []))
    needed_tags = {
        'vc-open-data-coordinate-space:' + source['frame'],
        'vc-open-data-source-coordinate-level:0',
        'vc-open-data-source-original-resolution:' + str(source['spacing_um']),
        'vc-open-data-source-path:' + str(paths['registered_volume'].resolve()),
    }
    if not needed_tags.issubset(tags):
        fail('volume package frame/source tags differ from the pinned local clone')
    if (zarr['shape'] != source['shape_zyx'] or attrs['axes'] != 'ZYX' or
        attrs['global_origin_xyz'] != source['crop_origin_global_xyz'] or
        attrs['source_tiff_sha256'] != source['source_tiff_sha256'] or
        local['uuid'] != source['local_volume_id'] or
        local['coordinate_space'] != source['frame'] or
        local['voxelsize'] != source['spacing_um'] or
        local['source_tiff_sha256'] != source['source_tiff_sha256'] or
        config['voxel_size_um'] != source['spacing_um'] or
        config['native_scale'] != 1 or config['device'] != 'cpu' or
        not config['cpu_tiled_conv3d'] or not config['no_extend'] or not config['no_mirror']):
        fail('local source/frame/config contract mismatch')
    if (config['origin_xyz'] != [0, 128, 128] or config['size_xyz'] != [512, 64, 64] or
        config['block_size'] != 128 or source['shape_zyx'] != [512, 512, 512]):
        fail('this bounded operator supports only the frozen four-block Scroll 3 region')
    entry_by_threads = {
        2: '2e2c8f24bf7ca8d1789d106d7c2d9307ad9dd3e486d742769444cf3d4cb2379f',
        8: '24ba706ddd5337bfc75dc41279f4400ebea8772b100637e05f524b9283cc5cd0',
    }
    if (config.get('cpu_threads') not in entry_by_threads or
        pins['model_entry_sha256'] != entry_by_threads[config['cpu_threads']]):
        fail('CPU thread setting is not bound to its pinned entry source')
    needed = [f'{z}.{y}.{x}' for z in range(1, 4) for y in range(1, 4) for x in range(8)]
    missing = [name for name in needed if not (paths['volume'] / name).is_file()]
    if missing:
        fail(f'missing source-backed CT chunks: {missing[:5]}')
    return paths, checks


def arg_values(argv, flag, count=1):
    if argv.count(flag) != 1:
        fail(f'historical command missing or repeated {flag}')
    at = argv.index(flag) + 1
    if len(argv) < at + count:
        fail(f'historical command missing {flag} values')
    return argv[at:at + count]


def legacy_afv(manifest, root, checks):
    legacy, cfg, source = manifest['legacy'], manifest['config'], manifest['source']
    paths = {name: root / legacy[key] for name, key in (
        ('afv', 'afv_rel'), ('preflight', 'preflight_rel'), ('receipt', 'run_receipt_rel'))}
    for name, field in (('afv', 'afv_sha256'), ('preflight', 'preflight_sha256'), ('receipt', 'run_receipt_sha256')):
        require_hash(paths[name], legacy[field], 'legacy ' + name)
    pre = load_json(paths['preflight'])
    run = load_json(paths['receipt'])
    for key in ('volume_tree_sha256', 'model_tree_sha256', 'code_tree_sha256',
                'model_entry_sha256', 'guard_sha256'):
        historical = pre.get('entry_sha256' if key == 'model_entry_sha256' else key)
        if historical != checks[key]:
            fail(f'legacy AFV {key} does not match current source/code')
    if (pre['zone_origin_xyz'] != cfg['origin_xyz'] or pre['zone_size_xyz'] != cfg['size_xyz'] or
        pre['block_size'] != cfg['block_size'] or pre['resource_limits'] != {
            'rss_bytes': cfg['rss_cap_bytes'], 'wall_seconds': cfg['wall_cap_seconds'],
            'checkpoint_bytes': cfg['checkpoint_cap_bytes']} or
        run['preflight_sha256'] != legacy['preflight_sha256']):
        fail('legacy AFV preflight/config mismatch')
    arm = next((a for a in run['arms'] if a['name'] == 'resume'), None)
    if not arm or arm['exit_code'] != 0 or arm['output_sha256'] != legacy['afv_sha256']:
        fail('legacy resumed AFV receipt mismatch')
    argv = arm['argv']
    for flag, expected in (
        ('--origin', list(map(str, cfg['origin_xyz']))), ('--size', list(map(str, cfg['size_xyz']))),
        ('--coordinate-space', [source['frame']]), ('--native-scale', [str(cfg['native_scale'])]),
        ('--voxel-size', [str(cfg['voxel_size_um'])]), ('--device', [cfg['device']]),
        ('--threshold', [str(cfg['threshold'])]), ('--min-length', [str(cfg['min_length'])]),
        ('--black-distance', [str(cfg['black_distance'])]), ('--max-join-angle', [str(cfg['max_join_angle'])]),
        ('--block-size', [str(cfg['block_size'])])):
        if arg_values(argv, flag, len(expected)) != expected:
            fail(f'legacy command differs at {flag}')
    for flag in ('--cpu-tiled-conv3d', '--no-extend', '--no-mirror', '--checkpoint-dir'):
        if argv.count(flag) != 1:
            fail(f'legacy command differs at {flag}')
    return paths['afv']


def check_schema17(path, label):
    path = Path(path)
    if not path.exists():
        return
    if path.is_symlink() or not path.is_file():
        fail(f'{label} is not a regular file: {path}')
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        version = db.execute('PRAGMA user_version').fetchone()[0]
        if version != 17:
            fail(f'{label} has schema {version}; current native requires 17; reimport from the pinned AFV into a new workdir, no in-place migration')
        if db.execute('PRAGMA journal_mode').fetchone()[0].lower() != 'delete':
            fail(f'{label} is not finalized as standalone DELETE-journal SQLite')
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            fail(f'{label} SQLite integrity failed')
    if any(Path(str(path) + suffix).exists() for suffix in ('-wal', '-shm')):
        fail(f'{label} has SQLite sidecars')


def import_module(path):
    spec = importlib.util.spec_from_file_location('pinned_afvp_importer', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stage_fingerprint(contract, operator_hash, *dependencies):
    return canonical_hash([contract, operator_hash, *dependencies])


def model_runtime(model_python):
    """Capture the interpreter and every installed distribution before inference."""
    script = '''import hashlib, importlib.metadata, json, pathlib, platform, sys
binary = pathlib.Path(sys.executable).resolve()
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
packages = sorted((d.metadata['Name'].lower(), d.version)
                  for d in importlib.metadata.distributions())
print(json.dumps({'python': platform.python_version(), 'implementation': platform.python_implementation(),
                  'machine': platform.machine(), 'binary_sha256': digest, 'packages': packages}, sort_keys=True))'''
    proc = subprocess.run([str(model_python), '-c', script], capture_output=True,
                          text=True, check=False, timeout=30)
    if proc.returncode != 0:
        fail(f'model Python runtime probe failed: {proc.returncode}')
    return json.loads(proc.stdout)


def validate_generated_afv(manifest, root, paths, model_dir, importer, output):
    module = import_module(importer)
    reviewed = root / manifest['legacy']['afv_rel']
    require_hash(reviewed, manifest['legacy']['afv_sha256'], 'reviewed AFV metadata template')
    with module.open_afv(reviewed) as (_, reference), module.open_afv(output) as (db, actual):
        expected = dict(reference['generator'])
        expected['model'] = str(model_dir)
        expected['volume'] = str(paths['volume'])
        for key in ('frame', 'root'):
            if actual[key] != reference[key]:
                fail(f'fresh AFV {key} differs from pinned source frame')
        if actual['generator'] != expected:
            fail('fresh AFV generator/source/settings differ from pinned contract')
        fiber_count = point_count = 0
        for row in module.fibers(db):
            fiber_count += 1
            point_count += row[3]
        if (fiber_count != actual['fiber_count'] or point_count != actual['point_count'] or
            db.execute('PRAGMA quick_check').fetchone()[0] != 'ok'):
            fail('fresh AFV catalog, blocks, or database integrity differs from complete metadata')
    return {'fiber_count': fiber_count, 'point_count': point_count,
            'frame': actual['frame'], 'root': actual['root'], 'generator': actual['generator']}


def verify_stage(path, receipt_path, fingerprint):
    path, receipt_path = Path(path), Path(receipt_path)
    if not path.exists() and not receipt_path.exists():
        return None
    if not path.is_file() or not receipt_path.is_file():
        fail(f'incomplete stage; inspect before resume: {path} / {receipt_path}')
    receipt = load_json(receipt_path)
    if receipt.get('fingerprint') != fingerprint or receipt.get('output_sha256') != sha_file(path):
        fail(f'stale or unverified stage; refuse reuse: {path}')
    return receipt


def verify_run_identity(manifest, workdir):
    """Bind an incomplete checkpoint to its full operator/manifest/thread identity."""
    path = workdir / 'cpu_thread_run_identity.json'
    expected = {'schema': 1, 'contract_sha256': manifest['contract_sha256'],
                'operator_sha256': sha_file(__file__), 'cpu_threads': manifest['config']['cpu_threads']}
    if path.exists() or path.is_symlink():
        if path.is_symlink() or not path.is_file() or load_json(path) != expected:
            fail('CPU thread run identity differs; refuse checkpoint or stage reuse')
        return
    if any((workdir / name).exists() for name in
           ('checkpoint', 'attempts', 'fibers.afv', 'afv.stage.json')):
        fail('existing model work lacks CPU thread run identity; use a new workdir')
    write_exclusive(path, expected)


def run_model(manifest, root, paths, model_dir, model_python, importer, workdir, fingerprint):
    cfg, source = manifest['config'], manifest['source']
    output, receipt_path = workdir / 'fibers.afv', workdir / 'afv.stage.json'
    verify_run_identity(manifest, workdir)
    old = verify_stage(output, receipt_path, fingerprint)
    if old:
        return output, 'reused'
    if not model_python:
        fail('fresh model run requires --model-python; reviewed AFV reuse is the default')
    if shutil.disk_usage(workdir).free < 20 * 1024**3:
        fail('less than 20 GiB free for the frozen model run')
    checkpoint = workdir / 'checkpoint'
    if checkpoint.is_symlink():
        fail('checkpoint symlink refused')
    attempts_dir = workdir / 'attempts'
    if attempts_dir.is_symlink():
        fail('attempts directory symlink refused')
    existing = [int(p.name) for p in attempts_dir.iterdir() if p.is_dir() and
                p.name.isdecimal()] if attempts_dir.exists() else []
    attempt = attempts_dir / f'{max(existing, default=0) + 1:03d}'
    attempt.mkdir(parents=True, exist_ok=False)
    argv = [str(model_python), str(paths['guard']), '--entry', str(paths['entry']),
        '--volume', str(paths['volume']), '--origin', *map(str, cfg['origin_xyz']),
        '--size', *map(str, cfg['size_xyz']), '--coordinate-space', source['frame'],
        '--model', str(model_dir), '--native-scale', str(cfg['native_scale']),
        '--voxel-size', str(cfg['voxel_size_um']), '--device', cfg['device'], '--progress', 'json',
        '--threshold', str(cfg['threshold']), '--min-length', str(cfg['min_length']),
        '--black-distance', str(cfg['black_distance']), '--max-join-angle', str(cfg['max_join_angle']),
        '--block-size', str(cfg['block_size']), '--no-extend', '--no-mirror', '--cpu-tiled-conv3d',
        '--output', str(output), '--checkpoint-dir', str(checkpoint)]
    env = os.environ.copy()
    env.pop('PYTHONPATH', None)
    env.pop('AFV_CANDIDATE_SRC', None)
    env.update(AFV_MAX_RSS_BYTES=str(cfg['rss_cap_bytes']), AFV_RSS_LOG=str(attempt / 'rss.jsonl'),
               AFV_CPU_THREADS=str(cfg['cpu_threads']))
    timed_out = False
    with (attempt / 'stdout.jsonl').open('x') as stdout, (attempt / 'stderr.txt').open('x') as stderr:
        try:
            process = subprocess.run(argv, env=env, stdout=stdout, stderr=stderr,
                                     timeout=cfg['wall_cap_seconds'], check=False)
            exit_code = process.returncode
        except subprocess.TimeoutExpired:
            timed_out, exit_code = True, 124
    checkpoint_bytes = sum(p.stat().st_size for p in checkpoint.rglob('*') if p.is_file()) if checkpoint.exists() else 0
    write_exclusive(attempt / 'command.json', {'argv': argv, 'exit_code': exit_code,
        'timed_out': timed_out, 'checkpoint_bytes': checkpoint_bytes})
    if checkpoint_bytes > cfg['checkpoint_cap_bytes']:
        fail(f'checkpoint exceeds cap; inspect {checkpoint}')
    if exit_code != 0 or not output.is_file():
        fail(f'model stopped (exit {exit_code}); inspect {attempt}. If output is absent, rerun the same command to resume the pinned checkpoint; if present without receipt, stop for manual audit')
    validated = validate_generated_afv(manifest, root, paths, model_dir, importer, output)
    write_exclusive(receipt_path, {'fingerprint': fingerprint, 'output_sha256': sha_file(output),
        'command_receipt': str((attempt / 'command.json').relative_to(workdir)),
        'validated_afv': validated})
    return output, 'executed'


def verify_native(portable, afv, local_id, shape):
    from vc_object_store import ObjectStore
    if any(Path(str(portable) + suffix).exists() for suffix in ('-wal', '-shm')):
        fail('portable main file has sidecars')
    before = sha_file(portable)
    with sqlite3.connect(afv.resolve().as_uri() + '?mode=ro', uri=True) as db:
        meta = {k: json.loads(v) for k, v in db.execute('SELECT key,value FROM metadata')}
        catalog = list(db.execute('SELECT id,name,family,point_count,length,annotation FROM fibers ORDER BY id'))
        rows = list(db.execute('SELECT fiber_id,first_segment,points FROM blocks ORDER BY fiber_id,first_segment'))
    points = {}
    for fid, start, blob in rows:
        prev = points.get(fid, b'')
        if prev and (start != len(prev) // 24 - 1 or prev[-24:] != blob[:24]):
            fail(f'AFV source block discontinuity: {fid}')
        if not prev and start != 0:
            fail(f'AFV source block offset: {fid}')
        points[fid] = prev + (blob[24:] if prev else blob)
    with ObjectStore.open(str(portable), read_only=True) as store:
        by_id = {r['meta']['source']['afv']['fiber_id']: r for r in store.objects_by_kind('fiber')}
        if len(by_id) != len(catalog):
            fail('native fiber count mismatch')
        for fid, name, family, count, length, annotation in catalog:
            obj = by_id[fid]
            if (obj['uuid'] != str(uuid.uuid5(uuid.UUID(meta['uuid']), f'fiber:{fid}')) or
                obj['name'] != name or obj['fiber']['family'] != family or
                obj['fiber']['line_point_count'] != count or obj['fiber']['length'] != length or
                obj['meta']['source']['afv']['annotation'] != json.loads(annotation) or
                obj['meta']['coordinates'] != {'volume_uuid': local_id, 'scale_factor': 1}):
                fail(f'native record/provenance mismatch: {fid}')
            rev = store.current_geometry(obj['uuid'])['uuid']
            raw = points[fid]
            if (store.read_geometry_array(rev, 'line_points') != raw or
                store.read_geometry_array(rev, 'control_points') != raw[:24] + raw[-24:] or
                store.read_geometry_array(rev, 'control_point_ids') != struct.pack('<2q', 0, 1)):
                fail(f'native geometry mismatch: {fid}')
        if store.object(meta['uuid'])['meta']['afv']['metadata'] != meta:
            fail('collection metadata mismatch')
        selected = store.select_objects(object_kind='fiber', volume=local_id, limit=len(catalog) + 1)
        bounds = [0, 0, 0, *reversed(shape)]
        region = store.spatial_regions(bounds, object_kind='fiber', volume=local_id)
        if len(selected) != len(catalog) or len({r['object_uuid'] for r in region}) != len(catalog):
            fail('native volume/region query mismatch')
    if sha_file(portable) != before or any(Path(str(portable) + x).exists() for x in ('-wal', '-shm')):
        fail('read-only query mutated portable store')
    return {'fibers': len(catalog), 'points': sum(r[3] for r in catalog),
        'exact_geometry_arrays': 3 * len(catalog), 'region_rows': len(region),
        'bound_query_count': len(selected), 'main_only_read_only': True}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=('status', 'run'))
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--task-root', type=Path, required=True)
    p.add_argument('--model-dir', type=Path, required=True)
    p.add_argument('--volume-dir', type=Path, help='Override the local CT path; content pins still apply')
    p.add_argument('--importer', type=Path, required=True)
    p.add_argument('--native-pythonpath', type=Path, required=True)
    p.add_argument('--workdir', type=Path)
    p.add_argument('--model-python', type=Path)
    p.add_argument('--fresh-afv', action='store_true')
    args = p.parse_args()
    root, model_dir, importer = args.task_root.resolve(), args.model_dir.resolve(), args.importer.resolve()
    sys.path.insert(0, str(args.native_pythonpath.resolve()))
    manifest = load_json(args.manifest)
    if manifest.get('schema') != 3:
        fail('unsupported manifest schema; exact-current fresh operator requires schema 3')
    if (args.mode != 'run' or not args.fresh_afv or not args.model_python):
        fail('exact-current operator requires run --fresh-afv --model-python')
    if (manifest['source'].get('current_python_commit') !=
            '8ff06f7620dcb663ed327028dbb8a0cf7e9a8198' or
        manifest['source'].get('generator_patch_sha256') !=
            '8154fe7358f8ab2c1bbc27eaefe929901fa7ce55790f7b708d2a7d06c58a9c2f' or
        manifest['source'].get('current_native_commit') !=
            '8ff06f7620dcb663ed327028dbb8a0cf7e9a8198' or
        manifest['source'].get('official_importer_sha256') !=
            '9a6d97d97409499b362798c13e73f70d3fc52524efab52496db45ac1d9d25031' or
        manifest['source'].get('standalone_patch_sha256') !=
            '5dc56f0754e1a73b23dd12c802597b4455372c561f539388d866f561be3081d0'):
        fail('exact-current source/importer patch provenance differs')
    paths, checks = verify_contract(manifest, root, model_dir, importer,
                                    args.native_pythonpath.resolve(), args.volume_dir)
    legacy_source = None if args.fresh_afv else legacy_afv(manifest, root, checks)
    legacy = manifest['legacy']
    if args.mode == 'status':
        if args.fresh_afv:
            fail('--fresh-afv is only valid with run')
        portable = root / legacy['portable_rel']
        receipt = root / legacy['portable_receipt_rel']
        require_hash(portable, legacy['portable_sha256'], 'reviewed portable store')
        require_hash(receipt, legacy['portable_receipt_sha256'], 'reviewed portable receipt')
        if load_json(receipt)['relocated_main_only_sha256_unchanged'] != legacy['portable_sha256']:
            fail('portable receipt disagrees with artifact')
        native = verify_native(portable, legacy_source, manifest['source']['local_volume_id'], manifest['source']['shape_zyx'])
        print(json.dumps({'contract_sha256': manifest['contract_sha256'], 'afv': 'reused reviewed run',
                          'portable': 'reused reviewed artifact', 'native_query': native}, indent=2))
        return
    if not args.workdir:
        fail('run requires --workdir')
    if args.workdir.is_symlink():
        fail('workdir symlink refused')
    workdir = args.workdir.resolve()
    if not workdir.is_relative_to(root) or workdir == root or any(
        workdir == x or workdir.is_relative_to(x) for x in (paths['volume'], paths['registered_volume'], paths['code'], model_dir)):
        fail('workdir must be task-owned and separate from pinned inputs')
    workdir.mkdir(parents=True, exist_ok=True)
    if workdir.is_symlink():
        fail('workdir symlink refused')
    operator_hash = sha_file(__file__)
    runtime = None
    if args.fresh_afv:
        if not args.model_python:
            fail('fresh model run requires --model-python')
        runtime = model_runtime(args.model_python.absolute())
        if canonical_hash(runtime) != manifest['pins']['fresh_runtime_sha256']:
            fail('model Python/runtime package set differs from frozen fresh-run environment')
    afv_fingerprint = stage_fingerprint(manifest['contract_sha256'], operator_hash,
                                        'afv', canonical_hash(runtime) if runtime else 'reviewed')
    if args.fresh_afv:
        afv, afv_status = run_model(manifest, root, paths, model_dir,
                                    args.model_python.absolute(), importer, workdir,
                                    afv_fingerprint)
    else:
        afv, afv_status = legacy_source, 'reused reviewed run'
    importer_module = import_module(importer)
    with importer_module.open_afv(afv) as (_, afv_meta):
        if afv_meta['frame'].get('vc_open_data_coordinate_space') != manifest['source']['frame']:
            fail('AFV frame mismatch before import')
    afv_sha = sha_file(afv)
    from vc_object_store import ObjectStore
    unbound = workdir / 'unbound.vcobj'
    import_receipt = workdir / 'import.stage.json'
    import_fingerprint = stage_fingerprint(manifest['contract_sha256'], operator_hash,
        'import', afv_sha, checks['importer_sha256'])
    check_schema17(unbound, 'existing imported store')
    if verify_stage(unbound, import_receipt, import_fingerprint):
        import_status = 'reused'
    else:
        with tempfile.TemporaryDirectory(prefix='.import-', dir=workdir) as tmp:
            staged = Path(tmp) / 'staged-v17.vcobj'
            importer_module.import_afv(afv, staged, unbound=True, author='operator-local',
                                       batch_size=32, progress=False)
            check_schema17(staged, 'importer-published staged store')
            with ObjectStore.open(str(staged), read_only=True) as store:
                if store.object_count('fiber') != afv_meta['fiber_count']:
                    fail('imported fiber count mismatch; no output published')
            os.link(staged, unbound)
        write_exclusive(import_receipt, {'fingerprint': import_fingerprint,
            'output_sha256': sha_file(unbound), 'source_afv_sha256': afv_sha,
            'schema': 17, 'standalone_finalization': 'pinned importer DELETE-before-publication'})
        import_status = 'executed'
    portable = workdir / 'portable-bound.vcobj'
    bound_receipt = workdir / 'portable.stage.json'
    bound_fingerprint = stage_fingerprint(manifest['contract_sha256'], operator_hash,
        'portable', sha_file(unbound), checks['registered_volume_tree_sha256'],
        checks['importer_sha256'])
    check_schema17(portable, 'existing portable store')
    if verify_stage(portable, bound_receipt, bound_fingerprint):
        portable_status = 'reused'
    else:
        with tempfile.TemporaryDirectory(prefix='.bound-', dir=workdir) as tmp:
            staged = Path(tmp) / 'staged.vcobj'
            shutil.copy2(unbound, staged)
            with ObjectStore.open(str(staged), author='operator-local') as store:
                fibers = store.objects_by_kind('fiber')
                if len(fibers) != afv_meta['fiber_count']:
                    fail('staged fiber count mismatch')
                coordinates = {'volume_uuid': manifest['source']['local_volume_id'],
                               'scale_factor': 1}
                updates = [(item['uuid'], 'coordinates', coordinates) for item in fibers]
                updates.extend([
                    (afv_meta['uuid'], 'coordinates', coordinates),
                    (afv_meta['uuid'], 'local_binding', {
                        'scope': 'task-local crop only',
                        'image_tiff_sha256': manifest['source']['source_tiff_sha256'],
                        'crop_origin_global_xyz': manifest['source']['crop_origin_global_xyz'],
                        'source_frame': manifest['source']['frame'],
                        'local_volume_id': manifest['source']['local_volume_id']}),
                ])
                store.set_meta_many(updates)
            importer_module.finalize_staged_db(staged)
            check_schema17(staged, 'bound staged store')
            os.link(staged, portable)
        native = verify_native(portable, afv, manifest['source']['local_volume_id'],
                               manifest['source']['shape_zyx'])
        write_exclusive(bound_receipt, {'fingerprint': bound_fingerprint,
            'output_sha256': sha_file(portable), 'source_unbound_sha256': sha_file(unbound),
            'native_query': native, 'schema': 17,
            'standalone_finalization': 'pinned importer helper DELETE-before-publication'})
        portable_status = 'executed'
    native = verify_native(portable, afv, manifest['source']['local_volume_id'],
                           manifest['source']['shape_zyx'])
    result = {'contract_sha256': manifest['contract_sha256'], 'operator_sha256': operator_hash,
              'afv': afv_status, 'afv_sha256': afv_sha, 'import': import_status,
              'import_sha256': sha_file(unbound), 'portable': portable_status,
              'portable_sha256': sha_file(portable), 'native_query': native,
              'source_and_model_not_bundled': True, 'public_scan_identity_claimed': False}
    result_path = workdir / 'RUN_RESULT.json'
    if not result_path.exists():
        write_exclusive(result_path, result)
    else:
        saved = load_json(result_path)
        if (saved.get('contract_sha256') != manifest['contract_sha256'] or
            saved.get('portable_sha256') != result['portable_sha256']):
            fail('existing run result disagrees; no overwrite')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(f'AFV operator refused: {error}', file=sys.stderr)
        raise SystemExit(1)
