# Source and license scope

The runner, review rule/viewport helpers, renderer, model-free tests, templates, and documentation in this archive are task-authored additions under the project owner's previously approved, scoped MIT grant in `LICENSE-TASK-ADDITIONS.txt`. They are adapted from the earlier private task-owned review operator; this archive contains no personal paths, source data, checkpoints or model assets.

The rule reconstructs the selected crossing and crop-pair behavior of `CanadaApollo6/vesuvius-spiral-chains` at pinned commit `87dc53454943bd5c4462aabaab2d01355c31bea9`. The upstream source remains Apache-2.0; `LICENSE-UPSTREAM-APACHE-2.0.txt` preserves its notice. This archive does not include or relicense the upstream source, the separately versioned guarded runner, or any prediction/CT/annotation payload.

An installed package or public release is not implied by this private source archive. Keep the upstream and task-authored notices when composing source distributions.
