#!/usr/bin/env python3
"""No-data guards for source identity, cached coverage and abstention."""
from __future__ import annotations

import hashlib
import json
import tempfile
from pathlib import Path

import review_rule
import view_helpers
from run_review import run, source_context


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def fails(call, expected: str) -> None:
    try:
        call()
    except (ValueError, AssertionError) as exc:
        assert expected in str(exc), (expected, str(exc))
    else:
        raise AssertionError(f'expected refusal: {expected}')


review_rule.test_classification()
assert review_rule.classify_step({'kept': '1', 'bridged': '0', 'dr': '2'},
                                 {'chosen_pair': None})[:2] == ('not_evaluable', 'selected_crop_pair_missing')
with tempfile.TemporaryDirectory(prefix='autowind-review-code-test-') as tmp:
    root = Path(tmp)
    mask = root / 'mask.zarr'
    array = mask / '0/.zarray'
    array.parent.mkdir(parents=True)
    array.write_text(json.dumps({'zarr_format': 2, 'shape': [192, 192, 192],
                                 'chunks': [192, 192, 192], 'dtype': '|u1',
                                 'fill_value': 0, 'dimension_separator': '/'}))
    chunk = mask / '0/0/0/0'
    chunk.parent.mkdir(parents=True)
    chunk.write_bytes(b'cached-synthetic-chunk')
    asset = 'https://example.invalid/source.zarr'
    key = '0/0/0/0'
    receipt = root / 'payload.json'
    receipt.write_text(json.dumps({'source_asset': asset,
                                   'rows': [{'key': key, 'bytes': chunk.stat().st_size,
                                             'sha256': sha(chunk)}],
                                   'absent_recheck_before': {'rows': [{'key': '0/0/0/1', 'status': 404}]},
                                   'absent_recheck_after': {'rows': [{'key': '0/0/0/1', 'status': 404}]}}))
    item = {'asset_url': asset, 'volume_id': 'synthetic-volume', 'frame_id': 'synthetic-frame',
            'zarray_sha256': sha(array), 'mask_root': str(mask), 'receipt_kind': 'payload',
            'payload': {'path': str(receipt), 'sha256': sha(receipt)}, 'voxel_um': 9.6}
    ctx = source_context(item)
    assert source_context({**item, 'volume_id': 'different'})['identity_sha256'] != ctx['identity_sha256']
    fails(lambda: source_context({**item, 'asset_url': asset + '/wrong'}), 'different source')
    assert view_helpers.coverage(mask, ctx['head'], ctx['get'], key)['status'] == 'verified_present'
    assert view_helpers.coverage(mask, ctx['head'], ctx['get'], '0/0/0/1')['status'] == 'verified_sparse_404'
    chunk.write_bytes(b'corrupted')
    assert view_helpers.coverage(mask, ctx['head'], ctx['get'], key)['status'] == 'cached_payload_mismatch'
    existing = root / 'existing'
    existing.mkdir()
    fails(lambda: run(root / 'missing.json', existing), 'refusing overwrite')
print('PASS: source/volume identity, sparse/payload coverage, explicit not-evaluable, overwrite refusal')
