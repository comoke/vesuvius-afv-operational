#!/usr/bin/env python3
"""Source-bound viewport geometry and cached-chunk coverage helpers."""
from __future__ import annotations
import hashlib,json
from pathlib import Path

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def find_points(chains: list[dict], q: dict):
    matches = []
    for ch in chains:
        if int(ch['z']) != q['z'] or float(ch['theta']) != q['theta']:
            continue
        for i, (a, b) in enumerate(zip(ch['r'][:-1], ch['r'][1:])):
            if abs(a - q['r_a']) < 1e-8 and abs(b - q['r_b']) < 1e-8:
                matches.append((ch['pts'][i], ch['pts'][i + 1], i))
    return matches

def keys_for(z, ymin, ymax, xmin, xmax):
    return [f'0/{z // 192}/{yy}/{xx}'
            for yy in range(ymin // 192, ymax // 192 + 1)
            for xx in range(xmin // 192, xmax // 192 + 1)]

def coverage(mask: Path, head: dict, get: dict, key: str):
    path = mask / key
    h = head.get(key)
    g = get.get(key)
    if h is not None and h['http_status'] == 404 and not path.exists():
        return {'key': key, 'status': 'verified_sparse_404'}
    if h is None or h['http_status'] != 200 or g is None:
        return {'key': key, 'status': 'missing_source_receipt_or_unverified_chunk'}
    if not path.is_file():
        return {'key': key, 'status': 'missing_cached_payload'}
    digest = sha(path)
    expected_size = g['bytes']
    if digest != g['sha256'] or path.stat().st_size != expected_size or h['content_length'] != expected_size:
        return {'key': key, 'status': 'cached_payload_mismatch'}
    return {'key': key, 'status': 'verified_present', 'sha256': digest, 'bytes': expected_size}
