# Read-only guarded autowind review operator (private source candidate)

This code-only package turns one **complete, trusted local guarded autowind run** into a source-bound review queue and contact sheet. It never solves crops or edits chains. The substantive cue is fixed: a kept, unbridged step of integer size at least 2 whose selected crop-pair endpoint has `multi=1`. A cue is a human-review item, not an identified error or calibrated probability.

## Inputs and exact boundary

Use the separately versioned guarded runner at its exact plan-pinned `guarded.py` path, the same-host Python environment that created the plan, and the complete run's plan/workdir/output. `prepare_guarded_review.py` imports that runner, checks its runtime/source/input fingerprint and every committed checkpoint receipt, requires an exclusive output-owner marker and a V4 finish receipt for the same plan/workdir, and requires recorded no-solve assembly. Trusted local pickle is then read by `run_review.py`; never use untrusted checkpoint bytes.

Copy `source_contract.example.json` and fill in the exact public prediction asset URL, a source-admitted volume and frame, level-0 Zarr metadata hash, local mask path, verified payload receipt path/hash and voxel size. The builder requires this mask, receipt, metadata and voxel size to be bound by the guarded plan. The payload receipt must have the guarded runner's verified present-object rows and before/after 404 absence rows. The declared volume/frame are **operator-admitted facts**; this code does not infer physical registration or independent labels. The current builder supports the guarded local payload-receipt route, not generic remote Zarr or an original legacy HEAD/GET plan.

The packaged source dependencies are Python 3.14-compatible NumPy, Zarr and Pillow, plus the pinned guarded runner and its full upstream/runtime dependencies for `prepare`. The tested host was macOS arm64/Python 3.14.9. This is a source package, not a wheel, dependency lock or fresh-OS installer. It contains no CT, masks, annotations, model weights, checkpoint/output data, binaries, private paths or user identity. Use the separately versioned guarded V4 source archive with its attested finish receipt. Historical guarded V3/review V2 archives remain separate and unchanged; V2 manifests cannot enter this attested reader.

## Run

Extract this archive to a new directory. In the **same** environment used for the complete guarded run, use absolute paths and a new destination for each command:

```sh
python prepare_guarded_review.py /absolute/guarded.py /absolute/PLAN.json \
  /absolute/RUN_ROOT /absolute/SOURCE_CONTRACT.json /absolute/NEW_REVIEW_INPUTS
python run_review.py /absolute/NEW_REVIEW_INPUTS/MANIFEST.json \
  /absolute/NEW_REVIEW_OUTPUT
```

The first command resolves its new destination to an absolute path, then writes a frozen `PROTOCOL.json`, full checkpoint `INVENTORY.json`, source/run `MANIFEST.json` and `PREPARE_RECEIPT.json`. The second rejects legacy manifests, rechecks the pinned guarded adapter, plan, checkpoint set, output-owner and full finish receipt before output creation, then rebuilds saved steps against `steps.csv`, records missing or invalid selected metadata as `not_evaluable`, fixes every viewport before pixel reads, and verifies each cached mask chunk before rendering. An absent or unverified chunk is labeled as missing context, not background. The destination must not exist. After rendering, the reader rechecks the complete finish/output/checkpoint identity before writing `COMPLETE.json` last with output hashes. If inputs drift during review, it exits nonzero and leaves `INCOMPLETE.json` with no completion marker; intermediate rendered files may remain for diagnosis. A same-source/plan rerun may reproduce the same cue; no input is automatically corrected.

Focused no-data tests:

```sh
python test_model_free.py
python test_attested_schema.py
```

For a real run, independently check source-admission provenance and the generated receipt chain. A bounded same-source 20-commit no-solver assembly and review replay, post-prepare and controlled post-render mutations, legacy-manifest rejection and wrong-source refusal are documented outside this archive. The finish receipt is a local drift check, not a signature or a power-loss guarantee. The review output does not establish physical sheet identity, winding truth, human-review precision, quality improvement, cross-volume registration or generic portability.
