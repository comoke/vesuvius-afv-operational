#!/usr/bin/env python3
"""Create a source-bound review manifest from a complete trusted guarded run.

The declared volume/frame remain caller-admitted facts; this code does not
establish physical registration or make trusted pickle safe for arbitrary input.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

from run_review import source_context


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def guarded_module(path: Path):
    spec = importlib.util.spec_from_file_location('pinned_guarded_review_input', path)
    if spec is None or spec.loader is None:
        raise ValueError('cannot load guarded adapter')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepare(guarded_path: Path, plan_path: Path, workdir: Path, contract_path: Path,
            destination: Path) -> dict:
    destination = destination.resolve()
    if destination.exists():
        raise ValueError('destination exists; refusing overwrite')
    guarded_path, plan_path, workdir, contract_path = (p.resolve() for p in
                                                        (guarded_path, plan_path, workdir, contract_path))
    package = Path(__file__).resolve().parent
    g = guarded_module(guarded_path)
    plan = g.load_plan(plan_path)
    if sha(guarded_path) != plan['runtime']['guarded_sha256']:
        raise ValueError('guarded adapter differs from plan runtime')
    g.verify_inputs(plan)
    expected_manifest = {'plan_sha256': g.json_sha(plan), 'source_commit': plan['source_commit'],
                         'crops': list(plan['crops'])}
    if json.loads((workdir / 'MANIFEST.json').read_text()) != expected_manifest:
        raise ValueError('run manifest mismatch')
    committed, pending = g.verify_committed_set(workdir, plan)
    if pending or set(committed) != set(plan['crops']):
        raise ValueError('incomplete committed crop set')
    out = Path(plan['options']['out']).resolve()
    marker = out / '.guarded-output-owner.json'
    if not out.is_dir() or marker.is_symlink() or json.loads(marker.read_text()) != {
            'plan_sha256': g.json_sha(plan), 'workdir': str(workdir)}:
        raise ValueError('output owner does not match plan/workdir')
    if not hasattr(g, 'verify_finish_receipt'):
        raise ValueError('guarded adapter lacks an attested finish receipt')
    finish = g.verify_finish_receipt(workdir, plan)
    ar = json.loads((out / 'autowind_run.json').read_text())
    if ar['options'].get('no_solve') is not True:
        raise ValueError('assembly is not recorded as complete no-solve output')
    for name in ('chains.json', 'steps.csv', 'summary.json'):
        if not (out / name).is_file():
            raise ValueError(f'missing assembled {name}')

    source = json.loads(contract_path.read_text())
    if source.get('receipt_kind') != 'payload':
        raise ValueError('this builder requires a verified payload receipt contract')
    if (Path(source['mask_root']).resolve() != Path(plan['config']['mask']).resolve()
            or source['voxel_um'] != plan['options']['voxel_um']):
        raise ValueError('declared source mask/frame scale differs from plan')
    receipt = Path(source['payload']['path']).resolve()
    if (str(receipt) not in plan['input_sha256']
            or plan['input_sha256'][str(receipt)] != source['payload']['sha256']):
        raise ValueError('source receipt is not bound by guarded plan')
    source_context(source)  # format, URL, array and receipt identity checks
    array = Path(source['mask_root']) / '0/.zarray'
    if plan['input_sha256'].get(str(array.resolve())) != source['zarray_sha256']:
        raise ValueError('source array is not bound by guarded plan')

    source_code = Path(plan['source_root']) / 'tools/auto_windings.py'
    if not source_code.is_file() or str(source_code.resolve()) not in plan['input_sha256']:
        raise ValueError('upstream code is not bound by guarded plan')
    source_sha = sha(source_code)
    if plan['input_sha256'][str(source_code.resolve())] != source_sha:
        raise ValueError('upstream code changed')
    rule = package / 'review_rule.py'
    view = package / 'view_helpers.py'
    proto = json.loads((package / 'protocol.template.json').read_text())
    proto['source_code_sha256'] = source_sha
    proto['review_rule_sha256'] = sha(rule)
    proto['input_scope'] = f"complete guarded run {g.json_sha(plan)}; admitted {source['volume_id']}"
    summary = json.loads((out / 'summary.json').read_text())
    row = {'label': 'guarded_run', 'output_dir': str(out),
           'steps_csv_sha256': sha(out / 'steps.csv'), 'chains_json_sha256': sha(out / 'chains.json'),
           'summary_json_sha256': sha(out / 'summary.json'),
           'summary_chains': summary['chains'], 'summary_steps': summary['steps_total'],
           'plan_path': str(plan_path), 'plan_sha256': sha(plan_path), 'checkpoints': [],
           'checkpoint_count': len(committed)}
    for name in sorted(committed):
        check = workdir / 'committed' / name.removesuffix('.pkl') / 'checkpoint.pkl'
        row['checkpoints'].append({'name': name, 'path': str(check), 'sha256': sha(check),
                                   'bytes': check.stat().st_size,
                                   'receipt_sha256': sha(check.with_name('receipt.json')),
                                   'provenance': 'guarded_committed'})
    if (row['steps_csv_sha256'] != finish['outputs_sha256']['steps.csv']
            or row['chains_json_sha256'] != finish['outputs_sha256']['chains.json']
            or row['summary_json_sha256'] != finish['outputs_sha256']['summary.json']
            or [{'name': x['name'], 'checkpoint_sha256': x['sha256'],
                 'receipt_sha256': x['receipt_sha256']} for x in row['checkpoints']]
            != finish['checkpoints']):
        raise ValueError('review inventory differs from verified finish snapshot')
    if g.verify_finish_receipt(workdir, plan) != finish:
        raise ValueError('guarded finish changed while preparing review')
    destination.mkdir(parents=True, exist_ok=False)
    protocol_path = destination / 'PROTOCOL.json'
    write(protocol_path, proto)
    inventory = {'status': 'VALIDATED_SAVED_INPUTS', 'protocol_sha256': sha(protocol_path),
                 'source_code_sha256': source_sha, 'runs': [row]}
    inventory_path = destination / 'INVENTORY.json'
    write(inventory_path, inventory)
    manifest = {'schema': 'autowind_review_operator_v2_attested', 'status': 'VALIDATED_SAVED_INPUTS',
                'guarded_adapter': {'path': str(guarded_path), 'sha256': sha(guarded_path)},
                'guarded_plan': {'path': str(plan_path), 'sha256': sha(plan_path)},
                'guarded_workdir': str(workdir), 'guarded_output': str(out),
                'guarded_finish': {'path': str(out / g.FINISH_RECEIPT),
                                   'sha256': sha(out / g.FINISH_RECEIPT)},
                'inventory': {'path': str(inventory_path), 'sha256': sha(inventory_path)},
                'protocol': {'path': str(protocol_path), 'sha256': sha(protocol_path)},
                'upstream_source': {'path': str(source_code), 'sha256': source_sha},
                'rule_source': {'path': str(rule), 'sha256': sha(rule)},
                'flag_module': {'path': str(rule), 'sha256': sha(rule)},
                'viewport_module': {'path': str(view), 'sha256': sha(view)},
                'sources': {'primary': source}, 'run_sources': {'guarded_run': 'primary'},
                'review_id_prefix': 'GUARDED-DR2',
                'display': {'title': f"Source-bound review · {source['volume_id']}",
                            'subtitle': 'Binary prediction support; selected multi-run step for human review',
                            'footer': 'Review cue only · no material identity or winding truth established'}}
    manifest_path = destination / 'MANIFEST.json'
    write(manifest_path, manifest)
    receipt_out = {'status': 'READY_FOR_READ_ONLY_REVIEW', 'guarded_plan_sha256': sha(plan_path),
                   'guarded_manifest_sha256': sha(workdir / 'MANIFEST.json'),
                   'output_owner_sha256': sha(marker), 'source_contract_sha256': sha(contract_path),
                   'guarded_finish_receipt_sha256': sha(out / g.FINISH_RECEIPT),
                   'source_identity_sha256': source_context(source)['identity_sha256'],
                   'protocol_sha256': sha(protocol_path), 'inventory_sha256': sha(inventory_path),
                   'manifest_sha256': sha(manifest_path), 'complete_committed': len(committed),
                   'no_solver_or_chain_changes': True}
    write(destination / 'PREPARE_RECEIPT.json', receipt_out)
    return receipt_out


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('guarded_adapter', type=Path)
    ap.add_argument('guarded_plan', type=Path)
    ap.add_argument('guarded_workdir', type=Path)
    ap.add_argument('source_contract', type=Path)
    ap.add_argument('new_review_inputs_dir', type=Path)
    args = ap.parse_args()
    print(json.dumps(prepare(args.guarded_adapter, args.guarded_plan, args.guarded_workdir,
                             args.source_contract, args.new_review_inputs_dir), indent=2))
