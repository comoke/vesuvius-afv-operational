#!/usr/bin/env python3
"""Legacy review manifest must not be accepted as an attested run."""
import json
import tempfile
from pathlib import Path

from run_review import run

with tempfile.TemporaryDirectory(prefix='attested_schema_test_') as tmp:
    root = Path(tmp)
    legacy = root / 'legacy.json'
    legacy.write_text(json.dumps({'schema': 'autowind_review_operator_v1',
                                  'status': 'VALIDATED_SAVED_INPUTS'}) + '\n')
    destination = root / 'output'
    try:
        run(legacy, destination)
    except ValueError as exc:
        assert 'legacy manifest refused' in str(exc), str(exc)
    else:
        raise AssertionError('legacy review manifest accepted')
    assert not destination.exists()

print('PASS: legacy manifest refused before output')
