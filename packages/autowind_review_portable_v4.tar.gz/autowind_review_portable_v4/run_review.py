#!/usr/bin/env python3
"""Build a review-only queue and contact sheet from admitted saved autowind runs.

The supplied manifest pins the existing reconstruction and viewport helpers. No
solver is imported or run. Only already admitted local prediction chunks are read.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def pinned_path(item: dict, name: str) -> Path:
    path = Path(item['path'])
    if not path.is_absolute():
        raise ValueError(f'{name}: expected an absolute path')
    if not path.is_file() or sha(path) != item['sha256']:
        raise ValueError(f'{name}: missing or changed pinned file: {path}')
    return path


def pinned_module(item: dict, name: str):
    path = pinned_path(item, name)
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f'{name}: cannot import {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def source_context(item: dict) -> dict:
    for key in ('asset_url', 'volume_id', 'frame_id', 'mask_root', 'zarray_sha256'):
        if not isinstance(item.get(key), str) or not item[key]:
            raise ValueError(f'source missing {key}')
    mask = Path(item['mask_root'])
    if not mask.is_absolute():
        raise ValueError('source mask path must be absolute')
    array = mask / '0/.zarray'
    if not array.is_file() or sha(array) != item['zarray_sha256']:
        raise ValueError('source array metadata changed')
    meta = json.loads(array.read_text())
    if meta['chunks'] != [192, 192, 192] or meta['dtype'] != '|u1' or meta['fill_value'] != 0:
        raise ValueError('source array contract changed')
    if item['receipt_kind'] == 'legacy_head_get':
        hp = pinned_path(item['head'], 'head receipt')
        gp = pinned_path(item['get'], 'get receipt')
        heads = json.loads(hp.read_text())['head_results']
        get_doc = json.loads(gp.read_text())
        if get_doc['frozen_head'] != hp.name:
            raise ValueError('get receipt references a different head receipt')
        gets = get_doc['results']
        if any(x['url'] != item['asset_url'].rstrip('/') + '/' + x['key'] for x in heads):
            raise ValueError('head receipt belongs to a different source')
        head = {x['key']: x for x in heads}
        present = {x['key']: x for x in gets}
        if len(head) != len(heads) or len(present) != len(gets):
            raise ValueError('duplicate source receipt key')
        for key, row in present.items():
            if key not in head or head[key]['http_status'] != 200 or head[key]['content_length'] != row['bytes']:
                raise ValueError(f'get/head mismatch: {key}')
        receipt_hashes = [sha(hp), sha(gp)]
    elif item['receipt_kind'] == 'payload':
        rp = pinned_path(item['payload'], 'payload receipt')
        obj = json.loads(rp.read_text())
        if obj['source_asset'] != item['asset_url']:
            raise ValueError('payload receipt belongs to a different source')
        rows = obj['rows']
        present = {x['key']: x for x in rows}
        if len(present) != len(rows):
            raise ValueError('duplicate payload key')
        pre_rows = obj['absent_recheck_before']['rows']
        post_rows = obj['absent_recheck_after']['rows']
        before = {x['key']: x['status'] for x in pre_rows}
        after = {x['key']: x['status'] for x in post_rows}
        if len(before) != len(pre_rows) or len(after) != len(post_rows):
            raise ValueError('duplicate sparse absence key')
        if before != after or any(status != 404 for status in before.values()):
            raise ValueError('sparse absence was not verified twice')
        head = {key: {'http_status': 404} for key in before}
        if set(head) & set(present):
            raise ValueError('source key both present and absent')
        head.update({key: {'http_status': 200, 'content_length': row['bytes']}
                     for key, row in present.items()})
        receipt_hashes = [sha(rp)]
    else:
        raise ValueError('unsupported source receipt kind')
    identity = {key: item[key] for key in ('asset_url', 'volume_id', 'frame_id', 'zarray_sha256')}
    identity['receipt_sha256'] = receipt_hashes
    return {'item': item, 'mask': mask, 'meta': meta, 'head': head, 'get': present,
            'identity': identity, 'identity_sha256': digest(identity)}


def queue_rows(result: dict, prefix: str) -> list[dict]:
    rows = []
    for i, q in enumerate(result['deduplicated_queue'], 1):
        first = q['runs'][0]['label']
        run = next(r for r in result['runs'] if r['label'] == first)
        flag = next(f for f in run['flags'] if (f['z'], f['theta'], f['r_a'], f['r_b']) ==
                    (q['z'], q['theta'], q['r_a'], q['r_b']))
        rows.append({'review_id': f'{prefix}-{i:02d}', 'z': q['z'], 'theta_deg': q['theta'],
                     'r_a_vox': q['r_a'], 'r_b_vox': q['r_b'], 'dr': q['dr'],
                     'p_err_saved': flag['p_err'], 'selected_crop': q['selected']['crop'],
                     'selected_pair_multi': '/'.join(map(str, q['selected']['pair_multi'])),
                     'run_provenance': ';'.join(r['label'] for r in q['runs']),
                     'disposition': 'human_review_only'})
    return rows


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def make_viewports(result: dict, inventory: dict, sources: dict, run_sources: dict,
                   view, prefix: str) -> list[dict]:
    runs = {r['label']: r for r in inventory['runs']}
    checked_runs = {r['label']: r for r in result['runs']}
    output = []
    for i, q in enumerate(result['deduplicated_queue'], 1):
        label = q['runs'][0]['label']
        run = runs[label]
        source = sources[run_sources[label]]
        chains_path = Path(run['output_dir']) / 'chains.json'
        if sha(chains_path) != run['chains_json_sha256']:
            raise ValueError(f'changed chain: {label}')
        found = view.find_points(json.loads(chains_path.read_text()), q)
        row = {'id': f'{prefix}-{i:02d}', 'z': q['z'], 'theta_deg': q['theta'],
               'r_a_vox': q['r_a'], 'r_b_vox': q['r_b'], 'dr': q['dr'],
               'reason': q['reason'], 'selected': q['selected'],
               'run_provenance': [v['label'] for v in q['runs']],
               'chains_json_sha256': run['chains_json_sha256'],
               'checkpoint_set_sha256': checked_runs[label]['checkpoint_set_sha256'],
               'source_identity_sha256': source['identity_sha256'],
               'source_mask': str(source['mask']),
               'source_array_zarray_sha256': source['item']['zarray_sha256']}
        if len(found) != 1:
            row['coverage_status'] = 'missing_unique_chain_coordinate_context'
            row['match_count'] = len(found)
            output.append(row)
            continue
        a, b, index = found[0]
        if len(a) != 3 or len(b) != 3 or abs(a[0] - q['z']) >= 1e-6 or abs(b[0] - q['z']) >= 1e-6:
            raise ValueError('chain endpoint frame mismatch')
        row.update({'chain_index': index, 'endpoint_a_zyx': a, 'endpoint_b_zyx': b})
        ymin = math.floor(min(a[1], b[1])) - 8
        ymax = math.ceil(max(a[1], b[1])) + 8
        xmin = math.floor(min(a[2], b[2])) - 8
        xmax = math.ceil(max(a[2], b[2])) + 8
        shape = source['meta']['shape']
        if not (0 <= q['z'] < shape[0] and 0 <= ymin <= ymax < shape[1] and 0 <= xmin <= xmax < shape[2]):
            raise ValueError('viewport outside admitted source array')
        row['viewport_zyx_inclusive'] = [[q['z'], q['z']], [ymin, ymax], [xmin, xmax]]
        row['required_chunks'] = [view.coverage(source['mask'], source['head'], source['get'], key)
                                  for key in view.keys_for(q['z'], ymin, ymax, xmin, xmax)]
        statuses = {v['status'] for v in row['required_chunks']}
        row['coverage_status'] = ('complete_cached' if statuses == {'verified_present'}
                                  else 'complete_with_verified_sparse'
                                  if statuses <= {'verified_present', 'verified_sparse_404'}
                                  else 'missing_or_unverified_context')
        output.append(row)
    return output


def run(manifest_path: Path, destination: Path) -> dict:
    if not __debug__:
        raise RuntimeError('Python -O is unsupported: pinned helper invariants use assert')
    if destination.exists():
        raise ValueError(f'output exists; refusing overwrite: {destination}')
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('schema') != 'autowind_review_operator_v2_attested' or manifest.get('status') != 'VALIDATED_SAVED_INPUTS':
        raise ValueError('attested review manifest required; legacy manifest refused')
    guarded_path = pinned_path(manifest['guarded_adapter'], 'guarded adapter')
    guarded = pinned_module(manifest['guarded_adapter'], 'attested_guarded_adapter')
    if not hasattr(guarded, 'verify_finish_receipt') or not hasattr(guarded, 'FINISH_RECEIPT'):
        raise ValueError('guarded adapter lacks attested finish support')
    plan_path = pinned_path(manifest['guarded_plan'], 'guarded plan')
    workdir = Path(manifest['guarded_workdir'])
    out = Path(manifest['guarded_output'])
    if (not workdir.is_absolute() or workdir.is_symlink() or workdir.resolve() != workdir
            or not (workdir / 'committed').is_dir() or not out.is_absolute()
            or out.is_symlink() or out.resolve() != out):
        raise ValueError('unsafe guarded workdir or output path')
    finish_path = pinned_path(manifest['guarded_finish'], 'guarded finish receipt')
    if finish_path != out / guarded.FINISH_RECEIPT:
        raise ValueError('finish receipt is outside guarded output')
    plan = guarded.load_plan(plan_path)
    if plan['runtime']['guarded_sha256'] != sha(guarded_path):
        raise ValueError('guarded adapter differs from plan runtime')
    guarded.verify_inputs(plan)
    expected_run_manifest = {'plan_sha256': guarded.json_sha(plan),
                             'source_commit': plan['source_commit'], 'crops': list(plan['crops'])}
    if json.loads((workdir / 'MANIFEST.json').read_text()) != expected_run_manifest:
        raise ValueError('guarded workdir manifest mismatch')
    if json.loads((out / '.guarded-output-owner.json').read_text()) != {
            'plan_sha256': guarded.json_sha(plan), 'workdir': str(workdir)}:
        raise ValueError('guarded output owner mismatch')
    finish = guarded.verify_finish_receipt(workdir, plan)
    if sha(finish_path) != manifest['guarded_finish']['sha256']:
        raise ValueError('guarded finish receipt changed during verification')
    inventory_path = pinned_path(manifest['inventory'], 'inventory')
    protocol_path = pinned_path(manifest['protocol'], 'protocol')
    source_path = pinned_path(manifest['upstream_source'], 'upstream source')
    flag = pinned_module(manifest['flag_module'], 'review_flag_core')
    view = pinned_module(manifest['viewport_module'], 'review_viewport_core')
    inventory = json.loads(inventory_path.read_text())
    protocol = json.loads(protocol_path.read_text())
    if inventory['source_code_sha256'] != sha(source_path) or protocol['source_code_sha256'] != sha(source_path):
        raise ValueError('source code is inconsistent with frozen inventory/protocol')
    if inventory['protocol_sha256'] != sha(protocol_path):
        raise ValueError('inventory/protocol mismatch')
    # The bundled rule source is pinned by both the protocol and the module entry.
    if (protocol['review_rule_sha256'] != sha(pinned_path(manifest['rule_source'], 'rule source'))
            or manifest['flag_module']['sha256'] != protocol['review_rule_sha256']):
        raise ValueError('review rule source changed')
    sources = {key: source_context(item) for key, item in manifest['sources'].items()}
    run_sources = manifest['run_sources']
    runs_in = inventory['runs']
    if len(runs_in) != 1:
        raise ValueError('attested review requires one complete guarded run')
    row = runs_in[0]
    if (row['plan_path'] != str(plan_path) or row['plan_sha256'] != sha(plan_path)
            or row['output_dir'] != str(out)
            or row['checkpoint_count'] != len(finish['checkpoints'])
            or row['chains_json_sha256'] != finish['outputs_sha256']['chains.json']
            or row['steps_csv_sha256'] != finish['outputs_sha256']['steps.csv']
            or row['summary_json_sha256'] != finish['outputs_sha256']['summary.json']):
        raise ValueError('review inventory differs from attested guarded output')
    inventory_checkpoints = [
        {'name': x['name'], 'checkpoint_sha256': x['sha256'],
         'receipt_sha256': x['receipt_sha256']}
        for x in sorted(row['checkpoints'], key=lambda x: x['name'])]
    if inventory_checkpoints != finish['checkpoints']:
        raise ValueError('review checkpoint set differs from attested guarded finish')
    labels = [r['label'] for r in runs_in]
    if len(labels) != len(set(labels)) or set(labels) != set(run_sources):
        raise ValueError('run/source mapping incomplete or duplicated')
    if not set(run_sources.values()) <= set(sources):
        raise ValueError('run references unknown source')
    inspected = []
    for row in runs_in:
        source = sources[run_sources[row['label']]]
        saved_plan = json.loads(Path(row['plan_path']).read_text())
        if 'crops' in saved_plan:
            if Path(saved_plan['config']['mask']).resolve() != source['mask'].resolve():
                raise ValueError(f"run/source mask mismatch: {row['label']}")
            if saved_plan['options']['voxel_um'] != source['item']['voxel_um']:
                raise ValueError(f"run/source voxel scale mismatch: {row['label']}")
        else:
            prefix = source['item']['asset_url'].rstrip('/') + '/'
            if any(not url.startswith(prefix) for url in saved_plan['required_level0_head_urls']):
                raise ValueError(f"run/source URL mismatch: {row['label']}")
            if saved_plan['mask_level0_shape_zyx'] != source['meta']['shape']:
                raise ValueError(f"run/source array shape mismatch: {row['label']}")
        checked = flag.inspect_run(row)
        checkpoint_set = [(x['name'], x['sha256']) for x in sorted(row['checkpoints'], key=lambda x: x['name'])]
        checked['checkpoint_set_sha256'] = digest(checkpoint_set)
        checked['source_identity_sha256'] = source['identity_sha256']
        inspected.append(checked)
    queue: dict[tuple, dict] = {}
    for checked in inspected:
        for f in checked['flags']:
            key = (checked['source_identity_sha256'], checked['checkpoint_set_sha256'],
                   f['z'], f['theta'], f['r_a'], f['r_b'], f['dr'],
                   tuple(f['selected']['pair_multi']), tuple(f['selected']['pair_winding']))
            if key not in queue:
                queue[key] = {'z': f['z'], 'theta': f['theta'], 'r_a': f['r_a'],
                              'r_b': f['r_b'], 'dr': f['dr'], 'selected': f['selected'],
                              'reason': 'kept_unbridged_dr_ge_2_with_selected_multi_run_endpoint',
                              'action': 'human_review_only', 'runs': [],
                              'source_identity_sha256': checked['source_identity_sha256'],
                              'checkpoint_set_sha256': checked['checkpoint_set_sha256']}
            queue[key]['runs'].append({'label': checked['label'],
                                       'steps_csv_sha256': checked['steps_csv_sha256'],
                                       'step_k': f['step_k']})
    result = {'status': 'COMPLETE_REVIEW_ONLY', 'manifest_sha256': sha(manifest_path),
              'inventory_sha256': sha(inventory_path), 'protocol_sha256': sha(protocol_path),
              'runs': inspected, 'deduplicated_queue': list(queue.values()),
              'interpretation_limit': 'review workload only; no winding truth or chain correction'}
    prefix = manifest['review_id_prefix']
    if not isinstance(prefix, str) or not prefix or any(x in prefix for x in '/\\\n'):
        raise ValueError('invalid review ID prefix')
    review_rows = queue_rows(result, prefix)
    view_rows = make_viewports(result, inventory, sources, run_sources, view, prefix)
    destination.mkdir(parents=True, exist_ok=False)
    (destination / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    coverage = {'status': 'COMPLETE_REVIEW_ONLY', 'manifest_sha256': sha(manifest_path),
                'runs': [{'label': r['label'], 'step_coverage': r['step_coverage'],
                          'not_evaluable_steps': r['not_evaluable_steps']}
                         for r in inspected],
                'queue_items': len(queue),
                'viewport_coverage': {v['id']: v['coverage_status'] for v in view_rows}}
    (destination / 'COVERAGE.json').write_text(json.dumps(coverage, indent=2) + '\n')
    fields = ['review_id', 'z', 'theta_deg', 'r_a_vox', 'r_b_vox', 'dr', 'p_err_saved',
              'selected_crop', 'selected_pair_multi', 'run_provenance', 'disposition']
    write_csv(destination / 'REVIEW_QUEUE.csv', review_rows, fields)
    unknown = [{'run': r['label'], **x} for r in inspected for x in r['not_evaluable_steps']]
    write_csv(destination / 'NOT_EVALUABLE.csv', unknown,
              ['run', 'z', 'theta', 'r_a', 'r_b', 'reason'])
    (destination / 'VIEWPORT_PLAN.json').write_text(json.dumps({
        'status': 'FROZEN_VIEWPORTS_BEFORE_PIXEL_READ', 'manifest_sha256': sha(manifest_path),
        'queue_result_sha256': sha(destination / 'RESULT.json'), 'rows': view_rows,
        'no_mask_pixels_read': True}, indent=2) + '\n')
    lines = ['# Saved autowind review queue', '',
             'Rule: kept, unbridged `dr>=2` with `multi=1` at an actual selected crop-pair endpoint. Review only; these are not proven errors.', '',
             '| ID | Z | θ° | Radii (vox) | Saved p_err | Selected crop | Endpoint multi | Runs |',
             '|---|---:|---:|---:|---:|---|---|---|']
    for r in review_rows:
        lines.append(f"| {r['review_id']} | {r['z']} | {r['theta_deg']:g} | {r['r_a_vox']:g}→{r['r_b_vox']:g} | {r['p_err_saved']:.3f} | {r['selected_crop']} | {r['selected_pair_multi']} | {r['run_provenance']} |")
    lines.extend(['', f'{len(unknown)} eligible steps were not evaluable; see `NOT_EVALUABLE.csv` and `COVERAGE.json`.',
                  'Source, volume, frame and checkpoint-set hashes are recorded in `RESULT.json` and `VIEWPORT_PLAN.json`.',
                  'This queue measures review workload, not physical sheet identity, flag precision or winding accuracy.', ''])
    (destination / 'REVIEW_QUEUE.md').write_text('\n'.join(lines))
    from render_sheet import render
    render(destination / 'VIEWPORT_PLAN.json', destination, manifest['display'])
    try:
        if (guarded.verify_finish_receipt(workdir, plan) != finish
                or sha(finish_path) != manifest['guarded_finish']['sha256']):
            raise ValueError('finish receipt changed during review')
    except Exception as exc:
        (destination / 'INCOMPLETE.json').write_text(json.dumps({
            'status': 'INCOMPLETE_INPUT_DRIFT',
            'reason': 'guarded finish, output or checkpoint identity changed during review',
            'no_review_completion': True}, indent=2) + '\n')
        raise RuntimeError('attested inputs changed during review; output incomplete') from exc
    receipt = {'status': 'COMPLETE_REVIEW_ONLY', 'manifest_sha256': sha(manifest_path),
               'inventory_sha256': sha(inventory_path), 'review_items': len(queue),
               'not_evaluable_steps': len(unknown),
               'outputs_sha256': {p.name: sha(p) for p in sorted(destination.iterdir()) if p.is_file()},
               'no_solver_or_chain_changes': True}
    (destination / 'COMPLETE.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return {'review_items': len(queue), 'not_evaluable_steps': len(unknown),
            'coverage': coverage['viewport_coverage'], 'output': str(destination)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('validated_manifest', type=Path)
    parser.add_argument('new_output_dir', type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.validated_manifest, args.new_output_dir), indent=2))
