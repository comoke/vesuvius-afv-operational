#!/usr/bin/env python3
"""Render admitted cached-mask viewports without chain edits."""
from __future__ import annotations

import hashlib
import json
import textwrap
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import zarr

FONT = '/System/Library/Fonts/Supplemental/Arial.ttf'
W, H = 410, 350


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def font(size):
    if Path(FONT).is_file():
        return ImageFont.truetype(FONT, size=size)
    return ImageFont.load_default(size=size)


def verified_roi(row):
    if row['coverage_status'] not in ('complete_cached', 'complete_with_verified_sparse'):
        return None
    mask = Path(row['source_mask'])
    assert sha(mask / '0/.zarray') == row['source_array_zarray_sha256']
    for chunk in row['required_chunks']:
        if chunk['status'] == 'verified_present':
            p = mask / chunk['key']
            assert p.stat().st_size == chunk['bytes'] and sha(p) == chunk['sha256']
        else:
            assert chunk['status'] == 'verified_sparse_404' and not (mask / chunk['key']).exists()
    (_, _), (y0, y1), (x0, x1) = row['viewport_zyx_inclusive']
    a = zarr.open_group(str(mask), mode='r')['0']
    return np.asarray(a[row['z'], y0:y1 + 1, x0:x1 + 1]) > 0


def render(plan_path: Path, destination: Path, display: dict):
    plan = json.loads(plan_path.read_text())
    assert plan['status'] == 'FROZEN_VIEWPORTS_BEFORE_PIXEL_READ'
    rows = plan['rows']
    columns = 3
    grid_rows = max(1, (len(rows) + columns - 1) // columns)
    canvas = Image.new('RGB', (columns * W + 30, grid_rows * H + 95), (248, 249, 250))
    draw = ImageDraw.Draw(canvas)
    draw.text((22, 16), display['title'], font=font(23), fill=(28, 37, 48))
    draw.text((22, 48), display['subtitle'],
              font=font(13), fill=(65, 74, 85))
    stats = []
    for i, row in enumerate(rows):
        px = 15 + (i % columns) * W
        py = 78 + (i // columns) * H
        draw.rounded_rectangle((px, py, px + W - 10, py + H - 8), radius=8,
                               fill=(255, 255, 255), outline=(204, 211, 219), width=1)
        draw.text((px + 12, py + 9), f"{row['id']}   z {row['z']} · θ {row['theta_deg']:g}°",
                  font=font(16), fill=(25, 35, 45))
        draw.text((px + 12, py + 30), f"r {row['r_a_vox']:.2f} → {row['r_b_vox']:.2f} · kept +{row['dr']} · multi {'/'.join(map(str,row['selected']['pair_multi']))}",
                  font=font(13), fill=(55, 63, 72))
        left, top, box_w, box_h = px + 78, py + 55, 235, 204
        draw.rectangle((left - 1, top - 1, left + box_w, top + box_h), fill=(236, 239, 242), outline=(155, 166, 178))
        roi = verified_roi(row)
        if roi is None:
            draw.text((left + 15, top + 78), 'MISSING SOURCE COVERAGE', font=font(13), fill=(145, 40, 40))
            stats.append({'id': row['id'], 'coverage_status': row['coverage_status'], 'positive_voxels': None})
        else:
            hh, ww = roi.shape
            scale = min(box_w / ww, box_h / hh)
            rw, rh = max(1, round(ww * scale)), max(1, round(hh * scale))
            image = Image.fromarray(np.where(np.flipud(roi), 50, 233).astype(np.uint8), mode='L').convert('RGB')
            image = image.resize((rw, rh), Image.Resampling.NEAREST)
            ix = left + (box_w - rw) // 2
            iy = top + (box_h - rh) // 2
            canvas.paste(image, (ix, iy))
            draw.rectangle((ix - 1, iy - 1, ix + rw, iy + rh), outline=(106, 118, 130), width=1)
            (_, _), (ymin, ymax), (xmin, xmax) = row['viewport_zyx_inclusive']
            def pos(point):
                return (ix + (point[2] - xmin + .5) * rw / ww,
                        iy + (ymax - point[1] + .5) * rh / hh)
            a = pos(row['endpoint_a_zyx']); b = pos(row['endpoint_b_zyx'])
            draw.line((a, b), fill=(37, 114, 193), width=3)
            for p, color, label in [(a, (16, 142, 86), 'A'), (b, (225, 116, 17), 'B')]:
                x, y = p
                draw.ellipse((x - 6, y - 6, x + 6, y + 6), fill=color, outline=(255, 255, 255), width=2)
                draw.text((x + 7, y - 9), label, font=font(13), fill=color, stroke_width=1, stroke_fill=(255, 255, 255))
            for p, m in [(a, row['selected']['pair_multi'][0]), (b, row['selected']['pair_multi'][1])]:
                if m == 1:
                    x, y = p
                    draw.ellipse((x - 10, y - 10, x + 10, y + 10), outline=(160, 40, 175), width=2)
            stats.append({'id': row['id'], 'coverage_status': row['coverage_status'],
                          'positive_voxels': int(roi.sum()), 'viewport_shape_yx': [hh, ww]})
        draw.text((px + 12, py + 265), f"coverage: {row['coverage_status']} · {len(row.get('required_chunks', []))} chunk(s)",
                  font=font(12), fill=(45, 99, 73) if roi is not None else (145, 40, 40))
        if 'endpoint_a_zyx' in row and 'endpoint_b_zyx' in row:
            draw.text((px + 12, py + 282), f"A YX {row['endpoint_a_zyx'][1]:.1f},{row['endpoint_a_zyx'][2]:.1f} · B YX {row['endpoint_b_zyx'][1]:.1f},{row['endpoint_b_zyx'][2]:.1f}",
                      font=font(12), fill=(69, 77, 85))
        runs = ', '.join(row['run_provenance'])
        for k, line in enumerate(textwrap.wrap('runs: ' + runs, width=60)[:2]):
            draw.text((px + 12, py + 299 + 15 * k), line, font=font(11), fill=(77, 84, 92))
        draw.text((px + 12, py + 330), f"selected crop: {row['selected']['crop']}", font=font(11), fill=(77, 84, 92))
    draw.text((22, grid_rows * H + 83), display['footer'],
              font=font(12), fill=(85, 61, 91))
    image_path = destination / 'CONTACT_SHEET.png'
    receipt_path = destination / 'RENDER_RECEIPT.json'
    assert not image_path.exists() and not receipt_path.exists()
    canvas.save(image_path, optimize=True)
    receipt_path.write_text(json.dumps({'status': 'COMPLETE_REVIEW_ONLY',
                                        'viewport_plan_sha256': sha(plan_path),
                                        'contact_sheet_sha256': sha(image_path),
                                        'items': stats,
                                        'no_new_data_or_chain_changes': True}, indent=2) + '\n')
    print(json.dumps({'items': len(stats), 'coverage': [x['coverage_status'] for x in stats],
                      'image_sha256': sha(image_path)}))
