#!/usr/bin/env python3
"""Review-only selected-crop reconstruction; no generator writes or task paths."""
from __future__ import annotations
import csv,hashlib,json,pickle
from collections import Counter,defaultdict
from pathlib import Path

def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def selected_pair(lst: list[tuple[float, list[dict], str]], a: dict, b: dict):
    hold = []
    for tc, cr, name in lst:
        ia = [x for x in cr if abs(x['t'] - a['t']) <= 2 and 'w' in x]
        ib = [x for x in cr if abs(x['t'] - b['t']) <= 2 and 'w' in x]
        if ia and ib:
            hold.append((abs((a['t'] + b['t']) / 2 - tc), ia[0], ib[0], name))
    hold.sort(key=lambda h: h[0])
    return hold

def reconstruct(rays: dict) -> list[dict]:
    """Mirror pinned assemble ownership/pair selection; omit confidence scoring."""
    rows = []
    for (z, theta), lst in sorted(rays.items()):
        lst.sort(key=lambda x: x[0])
        allx = sorted([(x['t'], abs(x['t'] - tc), x)
                       for tc, cr, _ in lst for x in cr], key=lambda v: v[0])
        own, cl = [], []
        for v in allx + [(1e18, 0, None)]:
            if cl and v[0] - cl[-1][0] > 2:
                own.append(min(cl, key=lambda q: q[1])[2])
                cl = []
            cl.append(v)
        seq = []
        for x in own:
            if seq:
                h = selected_pair(lst, seq[-1], x)
                if h and round(h[0][2]['w'] - h[0][1]['w']) == 0:
                    continue
            seq.append(x)
        for k, (a, b) in enumerate(zip(seq[:-1], seq[1:])):
            h = selected_pair(lst, a, b)
            rows.append({'z': z, 'theta': theta, 'k': k,
                         'r_a': a['t'], 'r_b': b['t'],
                         'dr': None if not h else round(h[0][2]['w'] - h[0][1]['w']),
                         'chosen_pair': None if not h else h[0]})
    return rows

def classify_step(saved: dict, rebuilt: dict) -> tuple[str, str | None, dict | None]:
    """Return status, reason, chosen endpoint evidence. Missing multi is unknown."""
    if int(saved['kept']) != 1 or int(saved['bridged']) != 0 or saved['dr'] == '' or int(saved['dr']) < 2:
        return 'not_in_rule', None, None
    pair = rebuilt['chosen_pair']
    if pair is None:
        return 'not_evaluable', 'selected_crop_pair_missing', None
    a, b = pair[1], pair[2]
    if 'multi' not in a or 'multi' not in b:
        return 'not_evaluable', 'selected_crossing_multi_missing', None
    if type(a['multi']) not in (int, bool) or type(b['multi']) not in (int, bool) or a['multi'] not in (0, 1) or b['multi'] not in (0, 1):
        return 'not_evaluable', 'selected_crossing_multi_invalid', None
    evidence = {'crop': pair[3], 'pair_radii': [a['t'], b['t']],
                'pair_multi': [int(a['multi']), int(b['multi'])],
                'pair_winding': [float(a['w']), float(b['w'])]}
    return ('flag' if a['multi'] or b['multi'] else 'clear'), None, evidence

def test_classification() -> None:
    saved = {'kept': '1', 'bridged': '0', 'dr': '2'}
    rebuilt = {'chosen_pair': (0, {'t': 1, 'w': -3, 'multi': 1},
                               {'t': 2, 'w': -1, 'multi': 0}, 'crop.pkl')}
    assert classify_step(saved, rebuilt)[0] == 'flag'
    assert classify_step(saved, {'chosen_pair': None})[:2] == ('not_evaluable', 'selected_crop_pair_missing')
    for value, reason in [(None, 'selected_crossing_multi_missing'),
                          (2, 'selected_crossing_multi_invalid')]:
        a = {'t': 1, 'w': -3}
        if value is not None:
            a['multi'] = value
        changed = {'chosen_pair': (0, a, {'t': 2, 'w': -1, 'multi': 0}, 'crop.pkl')}
        assert classify_step(saved, changed)[:2] == ('not_evaluable', reason)
    assert classify_step({**saved, 'dr': '1'}, rebuilt)[0] == 'not_in_rule'
    assert classify_step({**saved, 'kept': '0'}, rebuilt)[0] == 'not_in_rule'
    assert classify_step({**saved, 'bridged': '1'}, rebuilt)[0] == 'not_in_rule'

def inspect_run(run: dict) -> dict:
    out = Path(run['output_dir'])
    assert sha(out / 'steps.csv') == run['steps_csv_sha256']
    assert sha(out / 'chains.json') == run['chains_json_sha256']
    assert sha(out / 'summary.json') == run['summary_json_sha256']
    plan_path = Path(run['plan_path'])
    assert sha(plan_path) == run['plan_sha256']
    plan = json.loads(plan_path.read_text())
    rays = defaultdict(list)
    for c in sorted(run['checkpoints'], key=lambda v: v['name']):
        p = Path(c['path'])
        raw = p.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == c['sha256'] and len(raw) == c['bytes']
        if 'receipt_sha256' in c:
            assert sha(p.with_name('receipt.json')) == c['receipt_sha256']
        crop, result = pickle.loads(raw)  # hash-pinned accepted local checkpoint only
        assert set(crop) == {'zc', 'zs', 'theta', 'k', 'rk', 'o'}
        assert f"{crop['zc']}_{int(crop['theta'])}_{crop['k']}.pkl" == c['name']
        if 'crops' in plan:
            assert crop == plan['crops'][c['name']]
        if result:
            assert set(result) == set(crop['zs'])
            for z, seg in result.items():
                assert set(seg) == {'tc', 'cr', 'tlo', 'thi'} and isinstance(seg['cr'], list)
                rays[(int(z), float(crop['theta']))].append((float(seg['tc']), seg['cr'], c['name']))
    rebuilt = reconstruct(rays)
    with (out / 'steps.csv').open(newline='') as f:
        saved = list(csv.DictReader(f))
    assert len(saved) == len(rebuilt) == run['summary_steps'], (run['label'], len(saved), len(rebuilt))
    count = Counter()
    flags = []
    unknowns = []
    for s, b in zip(saved, rebuilt):
        assert (int(s['z']), float(s['theta']), int(s['k']), float(s['r_a']), float(s['r_b']),
                None if s['dr'] == '' else int(s['dr'])) == (b['z'], b['theta'], b['k'], b['r_a'], b['r_b'], b['dr']), (run['label'], s, b)
        status, reason, evidence = classify_step(s, b)
        count[status] += 1
        if status == 'flag':
            flags.append({'z': b['z'], 'theta': b['theta'], 'r_a': b['r_a'], 'r_b': b['r_b'],
                          'dr': b['dr'], 'p_err': float(s['p_err']), 'selected': evidence,
                          'step_k': b['k']})
        if status == 'not_evaluable':
            unknowns.append({'z': b['z'], 'theta': b['theta'], 'r_a': b['r_a'],
                             'r_b': b['r_b'], 'reason': reason})
    assert sum(count.values()) == len(saved)
    return {'label': run['label'], 'steps_csv_sha256': run['steps_csv_sha256'],
            'chains_json_sha256': run['chains_json_sha256'],
            'checkpoint_count': len(run['checkpoints']), 'rays_with_segments': len(rays),
            'summary_chains': run['summary_chains'], 'summary_steps': len(saved),
            'step_coverage': dict(count), 'flags': flags, 'not_evaluable_steps': unknowns}
