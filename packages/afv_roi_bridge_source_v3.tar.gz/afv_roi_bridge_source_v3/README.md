# Native AFV ROI candidate bridge

This package contains two scripts. `export_native_fiber_roi.py` selects full,
unchanged native fiber lines whose segments intersect a closed, source-aligned
ROI. `bridge_native_roi.py` verifies that candidate pack against the unchanged
source store, exports the selected fibers through the upstream Fiber JSON v4
transport, imports them into a new native object store, and checks a relocated
main-file-only read. Neither script creates patch links, constraints, sheet
labels, or geometry edits.

Both scripts reject symlinked leaf or parent components in the declared
source/pack/output paths before resolving them. This is a narrow accidental
alias guard for supplied paths, not an adversarial filesystem or concurrent
writer security guarantee.

## Requirements

Use a compatible Python and the `vc_object_store` native binding built from
ScrollPrize/villa commit `39a8cf3a124bdd5540ee826e1cb30047c8dc8c85`.
This archive does not include the binding, source CT, original AFV, object
store, model weights, or private review results. Paths in specs are supplied
by the operator; outputs must be new directories.

This source package V3 preserves the reviewed V2 exporter and V5
bridge path guard. Earlier candidates remain historical.

Run:

```sh
PYTHONPATH=/path/to/pinned/native/python python export_native_fiber_roi.py export_spec.json
PYTHONPATH=/path/to/pinned/native/python python bridge_native_roi.py bridge_spec.json
```

`export_spec.json` needs `store`, its SHA-256, `volume_meta`, its SHA-256,
`volume_zarray`, its SHA-256, `volume_id`, `coordinate_space`, `voxel_um`,
`roi_xyz` as six closed-box XYZ coordinates, and `output`. The pinned private
fixture uses an explicitly registered local 512-cube, 64-cube CT chunks,
source level 0 and scale 1. The exporter hashes the observed local CT chunks
and verifies their stability; it does not authenticate their remote origin.

`bridge_spec.json` needs `source_store`, `source_store_sha256`, `pack_dir`,
`output`, `expected_volume_id`, and `expected_coordinate_space`. The bridge
requires a complete ROI pack, verifies every source object and geometry
revision, and refuses nonempty branch edges because this bounded fixture has
none. It records source and imported revision UUIDs separately: import creates
new revisions even when UUIDs and geometry are preserved. Upstream ingestion
adds `source.filename` while preserving the original `source.afv` fields.

The native API already supplies spatial queries and Fiber JSON v4 transport.
This package is a provenance-bound operator bridge for a specific local
geometry selection. `vc_object_links --link-fiber-patches` is a separate
downstream constraint consumer that requires stored patch objects and a CT
volume. Those patch objects are absent from this seven-fiber candidate store;
no constraint or quality result is claimed here. No public scan ID is inferred.

## Source and license

The bridge uses the MIT-declared `vc_object_store` package at the pinned Villa commit.
Villa's MIT notice is included as `LICENSE-UPSTREAM-VILLA-MIT.txt`. The separate
VC3D/volume-cartographer viewer is GPL-3.0-or-later; its source and executable
are not included here. Our original scripts and tests have the scoped MIT
grant in `LICENSE-TASK-ADDITIONS.txt`. See `NOTICE.md`. This source-only package is not a standalone installer.
