# Attribution and scope of the source package

The project owner approved an MIT grant for **original task-authored code additions** on 2026-10-29. `LICENSE-TASK-ADDITIONS.txt` applies to those additions and associated original task-authored package documentation. Individual contributor names and copyright assignments are not asserted by this archive.

| Material | Provenance and applicable boundary |
| --- | --- |
| `TASK_AUTHORED_MEMORY_RESTART_V5.patch` | Original task-10 opt-in CPU tiling/checkpoint changes against open PR #1934 head `2d8577ed2aaf6b2cd7a5a023bb824538cd20b0e0`; the task-authored delta is covered by `LICENSE-TASK-ADDITIONS.txt`. The PR code appearing as context retains its own notice. |
| `AFV_MAIN8FF_CODE_ONLY.patch` | Composite text patch onto official Villa `8ff06f7620dcb663ed327028dbb8a0cf7e9a8198`. It includes PR #1934 code, the reviewed task-10 delta, and narrow task-6 current-main integration and packaging changes. This archive grants MIT only to the original task-authored portions, not an assertion of ownership over unchanged PR or Villa source. The patch preserves a copy of Villa's root MIT notice in the target `vesuvius/LICENSE`. |
| Candidate manifest, receipts and documentation | Original task-authored packaging material is within the grant. Machine receipts describe local tests; their inclusion does not broaden the grant to external dependencies or generated data. |
| Optional `extend/gap_model.pt` | Excluded. PR #1934 contains the 44,878-byte checkpoint, but its separate asset provenance and redistribution terms are unresolved. No grant is made for it here. |
| External nnU-Net model, CT, native build, dependency wheels | Not included and not licensed by this archive. Reproduction requires separately obtained, pinned prerequisites. |
| VC3D GUI | Not included. The `volume-cartographer/` viewer has its own GPLv3-or-later notice; this MIT grant does not relicense it. |
| Separate schema-17 importer portability archive | Not included. Its reviewed importer patch and synthetic test are in the companion V5 source package; that package carries its own notices. |

Preserve each upstream notice and review the separate terms of any third-party assets or dependencies before distributing them.
