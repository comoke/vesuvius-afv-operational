"""Generate an Automated Fiber Volume (.afv) from a zone of a CT volume.

The zone is processed in blocks. In each block a fiber model predicts vertical
and horizontal fiber probabilities and smooth polylines are fitted to them
(see ``splines``). The blocks' polylines are then stitched into long fibers,
optionally extended across gaps (see ``extend``), cleaned (see ``cleanup``)
and written in native L0 coordinates, ready to open in VC3D.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
import signal
import sys
import tempfile
import time
import traceback
from collections import OrderedDict
from pathlib import Path
from typing import Any, Iterator, Sequence

import numpy as np

from .afv import Fiber, write_afv
from .cleanup import TOLERANCE, ExteriorBlack, clean


DEFAULT_MODEL = "Qualzz20/afv_fiber_9um"
DEFAULT_THRESHOLD = 60.0
DEFAULT_MAX_JOIN_ANGLE = 45.0
DEFAULT_MIN_LENGTH = 100.0
DEFAULT_BLACK_DISTANCE = 16.0
# Voxel sizes of the scans DEFAULT_MODEL was trained on, in micrometres.
DEFAULT_MODEL_VOXEL_SIZES = (8.64, 9.362)
DEFAULT_BLOCK_SIZE = 512
# Each block is predicted with this much context on every side, so the
# splines of neighbouring blocks overlap and can be joined.
BLOCK_MARGIN = 32
GAP_MODEL = Path(__file__).parent / "extend" / "gap_model.pt"


class Reporter:
    """Progress as text on stderr, or as JSON lines on stdout for VC3D.

    JSON events have an ``event`` of ``progress`` (with ``stage``, ``message``
    and the completed ``fraction`` of the run), ``plan`` (the ``blocks``, each
    an ``origin`` and ``size`` in volume voxels), ``block`` (the ``index`` of
    a block and its new ``state``), ``preview`` (the ``path`` of a .afv with
    the fibers stitched so far), ``warning``, ``done`` or ``error``.
    """

    STAGES = {"read": (0.0, 0.01), "model": (0.01, 0.04), "blocks": (0.04, 0.85), "stitch": (0.85, 0.97), "write": (0.97, 1.0)}

    def __init__(self, json_lines: bool):
        self.json_lines = json_lines
        self.stage = None
        self.last = 0.0

    def emit(self, event: str, **fields: Any) -> None:
        if self.json_lines:
            print(json.dumps({"event": event, **fields}), flush=True)
        elif event == "progress":
            print(f"[{fields['fraction']:6.1%}] {fields['message']}", file=sys.stderr, flush=True)
        elif event == "done":
            print(f"Wrote {fields['fibers']} fibers to {fields['output']}", flush=True)
        elif event in ("warning", "error"):
            print(f"{event}: {fields['message']}", file=sys.stderr, flush=True)

    def __call__(self, stage: str, message: str, done: int = 0, total: int = 0) -> None:
        now = time.monotonic()
        if stage == self.stage and done < total and now - self.last < 0.5:
            return
        self.stage, self.last = stage, now
        start, end = self.STAGES[stage]
        fraction = start + (end - start) * (done / total if total else 0.0)
        self.emit("progress", stage=stage, message=message, fraction=round(fraction, 4))


def open_volume(location: str, level: int):
    import zarr

    from vesuvius.data.utils import open_zarr

    store = open_zarr(location)
    if isinstance(store, zarr.Group):
        if str(level) not in store:
            raise ValueError(f"The volume has no array {level}")
        store = store[str(level)]
    elif level != 0:
        raise ValueError("--level selects an array of an OME-Zarr group")
    if store.ndim != 3:
        raise ValueError(f"Expected a 3D volume, got shape {store.shape}")
    return store


def zone_slices(shape_zyx: Sequence[int], origin_xyz: Sequence[int], size_xyz: Sequence[int]) -> tuple[slice, ...]:
    zone = []
    for axis, extent, start, size in zip("zyx", shape_zyx, reversed(origin_xyz), reversed(size_xyz)):
        if start < 0 or size < 1 or start + size > extent:
            raise ValueError(f"The zone [{start}, {start + size}) exceeds the volume along {axis} (size {extent})")
        zone.append(slice(start, start + size))
    return tuple(zone)


def zone_blocks(origin_xyz: Sequence[int], size_xyz: Sequence[int], block: int) -> list[tuple[list[int], list[int]]]:
    """The zone cut into blocks of ``block`` voxels, the last ones shorter, x varying fastest."""
    if block < 1:
        raise ValueError("--block-size must be at least 1")
    axes = [[(o + start, min(block, s - start)) for start in range(0, s, block)] for o, s in zip(origin_xyz, size_xyz)]
    return [([x, y, z], [sx, sy, sz]) for z, sz in axes[2] for y, sy in axes[1] for x, sx in axes[0]]


class RegionReader:
    """Reads small regions of a volume through a cache of its storage chunks.

    Chunks leaving the memory cache are kept in ``spill`` when it is given, so
    that each chunk of a remote volume is downloaded once.
    """

    def __init__(self, volume, budget: int = 64 * 1024**2, spill: Path | None = None):
        self.volume = volume
        self.spill = spill
        self.chunks = np.asarray(volume.chunks, dtype=int)
        self.shape = np.asarray(volume.shape, dtype=int)
        self.cache: OrderedDict[tuple[int, ...], np.ndarray] = OrderedDict()
        self.budget = budget
        self.bytes = 0

    def _chunk(self, key: tuple[int, ...]) -> np.ndarray:
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        stored = self.spill / ("_".join(map(str, key)) + ".npy") if self.spill else None
        if stored and stored.exists():
            block = np.load(stored)
        else:
            start = np.asarray(key) * self.chunks
            block = np.asarray(self.volume[tuple(slice(int(a), int(b)) for a, b in zip(start, np.minimum(start + self.chunks, self.shape)))])
            if stored:
                np.save(stored, block)
        self.cache[key] = block
        self.bytes += block.nbytes
        while self.bytes > self.budget and len(self.cache) > 1:
            self.bytes -= self.cache.popitem(last=False)[1].nbytes
        return block

    def __call__(self, low_xyz: Sequence[int], high_xyz: Sequence[int]) -> np.ndarray:
        low, high = np.asarray(low_xyz, dtype=int)[::-1], np.asarray(high_xyz, dtype=int)[::-1]
        out = np.empty(tuple(high - low), dtype=self.volume.dtype)
        for key in np.ndindex(tuple((high - 1) // self.chunks - low // self.chunks + 1)):
            key = tuple(int(k) for k in np.asarray(key) + low // self.chunks)
            start = np.asarray(key) * self.chunks
            a, b = np.maximum(low, start), np.minimum(high, start + self.chunks)
            out[tuple(slice(int(x), int(y)) for x, y in zip(a - low, b - low))] = self._chunk(key)[
                tuple(slice(int(x), int(y)) for x, y in zip(a - start, b - start))
            ]
        return out


def select_device(name: str):
    import torch

    if name != "auto":
        return torch.device(name)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def resolve_model(model: str) -> tuple[Path, dict[str, str]]:
    """An nnU-Net export folder, or a Hugging Face repository fetched into the Hugging Face cache."""
    path = Path(model).expanduser()
    if path.exists():
        return path, {"model": str(path.resolve())}
    # Hugging Face repository IDs are "name" or "owner/name".
    if model.startswith((".", "/", "~")) or model.count("/") > 1 or "\\" in model or ":" in model:
        raise FileNotFoundError(f"Model folder not found: {model}")
    from huggingface_hub import snapshot_download

    folder = Path(snapshot_download(repo_id=model))
    # Snapshot folders are named after the repository commit.
    return folder, {"model": model, "revision": folder.name}


def load_network(folder: Path, device) -> tuple[Any, tuple[int, int, int]]:
    from .predict import FIBER_LABELS

    # Compiling takes longer than predicting a zone; set nnUNet_compile=true to compile anyway.
    os.environ.setdefault("nnUNet_compile", "false")
    from vesuvius.utils.models.load_nnunet_model import load_model

    # The loader prints to stdout, which carries the JSON progress events.
    with contextlib.redirect_stdout(sys.stderr):
        info = load_model(str(folder), device=str(device))
    if info["dataset_json"].get("labels") != FIBER_LABELS:
        raise ValueError(f"Not a fiber model: expected the classes {FIBER_LABELS}")
    if list(info["configuration_manager"].normalization_schemes) != ["ZScoreNormalization"]:
        raise ValueError("Only z-score normalized models are supported")
    if list(info["plans_manager"].transpose_forward) != [0, 1, 2]:
        raise ValueError("Only models without axis transposition are supported")
    return info["network"], tuple(int(p) for p in info["patch_size"])


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vesuvius.afv_spline_generator",
        description="Predict fibers in a zone of a CT volume and write them as an Automated Fiber Volume (.afv) for VC3D.",
    )
    parser.add_argument("--volume", required=True, help="Zarr or OME-Zarr volume: local path, http(s):// or s3:// URL")
    parser.add_argument("--level", type=int, default=0, help="Array of an OME-Zarr group read as the volume (default: 0)")
    parser.add_argument("--origin", type=int, nargs=3, required=True, metavar=("X", "Y", "Z"), help="First voxel of the zone")
    parser.add_argument("--size", type=int, nargs=3, required=True, metavar=("X", "Y", "Z"), help="Size of the zone in voxels")
    parser.add_argument("--output", type=Path, required=True, help="New .afv file; existing files are never replaced")
    parser.add_argument(
        "--coordinate-space",
        required=True,
        help="VC3D coordinate identity of the volume (its vc-open-data-coordinate-space tag); VC3D opens the file only on that volume",
    )
    parser.add_argument(
        "--native-scale",
        type=int,
        default=1,
        help="Native L0 voxels per voxel of the volume, 2^level of the coordinate identity (default: 1)",
    )
    parser.add_argument("--voxel-size", type=float, help="Native voxel size in micrometres, for lengths in millimetres")
    parser.add_argument("--source-path", help="Native source volume recorded with the fibers")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"nnU-Net fiber model: folder or Hugging Face repository (default: {DEFAULT_MODEL})")
    parser.add_argument(
        "--mirror",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Test-time mirroring: better predictions, about 8x slower (default: off)",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=DEFAULT_THRESHOLD,
        help=f"Minimum fiber probability in percent (default: {DEFAULT_THRESHOLD:g})",
    )
    parser.add_argument(
        "--block-size",
        type=int,
        default=DEFAULT_BLOCK_SIZE,
        help=f"The zone is processed in cubes of this many voxels per side (default: {DEFAULT_BLOCK_SIZE})",
    )
    parser.add_argument(
        "--extend",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Join fibers across gaps inside the zone with the gap model: longer fibers, several times slower (default: off)",
    )
    parser.add_argument(
        "--max-join-angle",
        type=float,
        default=DEFAULT_MAX_JOIN_ANGLE,
        help=f"Cut inferred joins turning more than this many degrees, measured over 8 voxels on each side; 180 keeps them all (default: {DEFAULT_MAX_JOIN_ANGLE:g})",
    )
    parser.add_argument(
        "--min-length",
        type=float,
        default=DEFAULT_MIN_LENGTH,
        help=f"Remove fibers shorter than this many voxels; 0 keeps them all (default: {DEFAULT_MIN_LENGTH:g})",
    )
    parser.add_argument(
        "--black-distance",
        type=float,
        default=DEFAULT_BLACK_DISTANCE,
        help=f"Remove fibers passing within this many voxels of the black outside the papyrus (CT value 0); 0 keeps them all (default: {DEFAULT_BLACK_DISTANCE:g})",
    )
    parser.add_argument("--preview-dir", type=Path, help="Folder receiving a .afv of the fibers stitched so far after each block")
    parser.add_argument("--checkpoint-dir", type=Path, help="Opt in to local, hash-bound block checkpoint/resume (CPU tiled, no extension or preview)")
    parser.add_argument("--window-checkpoint-dir", type=Path, help="Opt in to recovery of completed prediction windows inside each unfinished block")
    parser.add_argument("--window-checkpoint-max-mib", type=int, default=1024, help="Per-block window-cache budget in MiB, including staging (default: 1024)")
    parser.add_argument("--device", default="auto", help="auto (default), cuda, cuda:N, mps or cpu")
    parser.add_argument(
        "--cpu-tiled-conv3d", action="store_true",
        help="Opt in to 128 MiB output-Z Conv3d tiling for CPU, mirror-off 128³ fiber inference",
    )
    parser.add_argument("--progress", choices=("text", "json"), default="text", help="Progress as text on stderr, or JSON lines on stdout")
    return parser


def generate(args: argparse.Namespace, report: Reporter) -> dict[str, Any]:
    import torch

    from .predict import predict_fibers
    from .splines import extract_splines, threshold_to_u8

    output = args.output.expanduser().absolute()
    if output.suffix.lower() != ".afv":
        raise ValueError("The output must be a .afv file")
    if output.exists():
        raise FileExistsError(f"{output} already exists")
    if not output.parent.is_dir():
        raise FileNotFoundError(f"The folder {output.parent} does not exist")
    window_root = getattr(args, "window_checkpoint_dir", None)
    if window_root is not None:
        if args.extend or args.preview_dir is not None or not getattr(args, "cpu_tiled_conv3d", False) or args.mirror or args.device != "cpu":
            raise ValueError("Window recovery requires CPU tiling, mirror off, no extension and no preview")
        root = Path(window_root).expanduser().absolute()
        if any(p.is_symlink() for p in (root, *root.parents)):
            raise ValueError("Window checkpoint path may not traverse a symlink")
        root = root.resolve()
        from . import checkpoint as checkpoint_module
        protected = [Path(args.volume).expanduser().resolve(strict=True),
                     Path(args.model).expanduser().resolve(strict=True), Path(__file__).parents[1].resolve(),
                     Path(checkpoint_module.__file__).parents[1].resolve()]
        if not protected[0].is_dir() or not protected[1].is_dir():
            raise ValueError("Window recovery requires local volume and model directories")
        if any(root == p or root in p.parents or p in root.parents for p in protected):
            raise ValueError("Window cache must be separate from volume, model and source trees")
        if getattr(args, "checkpoint_dir", None) is not None:
            other = Path(args.checkpoint_dir).expanduser().resolve()
            if root == other or root in other.parents or other in root.parents:
                raise ValueError("Window and block cache directories must be separate")
        if args.window_checkpoint_max_mib < 1:
            raise ValueError("Window checkpoint budget must be positive")
        window_root = root
    checkpoint_dir = getattr(args, "checkpoint_dir", None)
    if checkpoint_dir is not None:
        if args.extend or args.preview_dir is not None or not getattr(args, "cpu_tiled_conv3d", False) or args.mirror:
            raise ValueError("Checkpoint mode requires CPU tiling, mirror off, no extension and no preview")
        if not Path(args.volume).expanduser().is_dir() or not Path(args.model).expanduser().is_dir():
            raise ValueError("Checkpoint mode requires local volume and model directories")
    if args.native_scale < 1:
        raise ValueError("--native-scale must be at least 1")
    threshold = threshold_to_u8(args.threshold)
    if args.voxel_size is not None and not args.voxel_size > 0:
        raise ValueError("--voxel-size must be positive")
    if not 0 <= args.max_join_angle <= 180:
        raise ValueError("--max-join-angle must be between 0 and 180")
    if args.min_length < 0 or args.black_distance < 0:
        raise ValueError("--min-length and --black-distance cannot be negative")
    if args.model == DEFAULT_MODEL and args.voxel_size:
        effective = args.voxel_size * args.native_scale
        if not 8.0 <= effective <= 10.0:
            report.emit(
                "warning",
                message=f"This model was trained on {' and '.join(map(str, DEFAULT_MODEL_VOXEL_SIZES))} µm scans; this volume has {effective:g} µm voxels.",
            )

    report("read", "Opening the volume")
    volume = open_volume(args.volume, args.level)
    zone_slices(volume.shape, args.origin, args.size)
    blocks = zone_blocks(args.origin, args.size, args.block_size)
    if window_root is not None and len(blocks) != 1:
        raise ValueError("Window recovery V1 supports a single block; choose one ROI/block or increase --block-size")
    shape_xyz = np.asarray(volume.shape[::-1], dtype=int)
    report.emit("plan", blocks=[{"origin": origin, "size": size} for origin, size in blocks], block_size=args.block_size)
    if args.preview_dir is not None and not args.preview_dir.is_dir():
        raise FileNotFoundError(f"The folder {args.preview_dir} does not exist")

    device = select_device(args.device)
    cpu_tiled_conv3d = getattr(args, "cpu_tiled_conv3d", False)
    if cpu_tiled_conv3d and device.type != "cpu":
        raise ValueError("--cpu-tiled-conv3d requires a CPU device")
    if checkpoint_dir is not None and device.type != "cpu":
        raise ValueError("Checkpoint mode requires a CPU device")
    report("model", f"Loading {args.model} on {device}")
    if device.type == "cpu":
        report.emit("warning", message="No GPU found: predicting on the CPU is very slow.")
    folder, provenance = resolve_model(args.model)
    network, patch = load_network(folder, device)
    mirror = args.mirror
    if cpu_tiled_conv3d and (mirror or patch != (128, 128, 128)):
        raise ValueError("--cpu-tiled-conv3d requires mirror off and a 128³ model window")

    from .extend.stitch import Stitcher

    frame = {
        "vc_open_data_coordinate_space": args.coordinate_space,
        "vc_open_data_source_coordinate_level": 0,
        "vc_open_data_source_coordinate_scale_factor": 1,
    }
    root = {"type": "vc3d_fiber_collection", "version": 1, "scale": 1, **frame, "coordinate_order": "XYZ", "coordinate_units": "voxel"}
    if args.source_path:
        root["vc_open_data_source_path"] = args.source_path
    if args.voxel_size:
        root["vc_open_data_source_original_resolution"] = args.voxel_size
        root["voxel_size_mm"] = args.voxel_size / 1000
    if args.native_scale == 1:
        # Only known exactly when the volume is the native volume.
        root["coordinate_base_shape_zyx"] = list(volume.shape)
    generator = {
        "name": "vesuvius.afv_spline_generator",
        **provenance,
        "mirror": mirror,
        "threshold_percent": args.threshold,
        "volume": args.volume,
        "level": args.level,
        "origin_xyz": list(args.origin),
        "size_xyz": list(args.size),
        "native_scale": args.native_scale,
        "block_size": args.block_size,
        "block_margin": BLOCK_MARGIN,
        "extend": args.extend,
        "max_join_angle_degrees": args.max_join_angle,
        "min_length_voxels": args.min_length,
        "black_distance_voxels": args.black_distance,
        "point_tolerance_voxels": TOLERANCE,
    }
    if cpu_tiled_conv3d:
        generator["cpu_tiled_conv3d_max_im2col_mib"] = 128
    if args.extend:
        from .extend.ct_support import CTSupport
        from .extend.gap_model import Predictor, geometry_features

        gap_model = Predictor(GAP_MODEL)
        voxel_microns = args.voxel_size * args.native_scale if args.voxel_size else float(gap_model.metadata["voxelMicrons"])
        generator["gap_model"] = gap_model.metadata.get("modelName", GAP_MODEL.name)

    def write(path: Path, traces: list[dict[str, Any]]) -> dict[str, Any]:
        return write_afv(path, afv_fibers(traces, args.native_scale, args.voxel_size), frame=frame, root=root, metadata={"generator": generator})

    names = {"V": "vertical", "H": "horizontal"}
    count = len(blocks)
    black = None
    if args.black_distance > 0:
        black = ExteriorBlack(np.maximum(np.asarray(args.origin) - BLOCK_MARGIN, 0),
                              np.minimum(np.asarray(args.origin) + np.asarray(args.size) + BLOCK_MARGIN, shape_xyz))
    with contextlib.ExitStack() as resources:
        if checkpoint_dir is not None:
            from .checkpoint import Checkpoint
            checkpoint = resources.enter_context(Checkpoint(checkpoint_dir, args, folder, Path(__file__).parents[1], blocks, frame))
        else:
            checkpoint = None
        scratch = resources.enter_context(tempfile.TemporaryDirectory(prefix="afv-stitch-"))
        stitcher = Stitcher(scratch)
        try:
            for index, (origin, size) in enumerate(blocks):
                label = f"Block {index + 1} of {count}"

                def step(fraction: float, message: str) -> None:
                    report("blocks", f"{label} · {message}", int(1000 * (index + fraction)), 1000 * count)

                low = np.maximum(np.asarray(origin) - BLOCK_MARGIN, 0)
                high = np.minimum(np.asarray(origin) + np.asarray(size) + BLOCK_MARGIN, shape_xyz)
                report.emit("block", index=index, state="reading")
                step(0.0, "reading the CT")
                ct = np.asarray(volume[tuple(slice(int(a), int(b)) for a, b in zip(low[::-1], high[::-1]))])
                if black is not None:
                    black.add(ct, low)
                if checkpoint is not None and index < checkpoint.completed_count:
                    traces = checkpoint.load(index, ct)
                    report.emit("block", index=index, state="replayed")
                else:
                    report.emit("block", index=index, state="predicting")
                    probabilities = predict_fibers(
                        network,
                        ct,
                        patch,
                        device=device,
                        mirror=mirror,
                        cpu_tiled_conv3d=cpu_tiled_conv3d,
                        window_checkpoint_dir=window_root,
                        window_checkpoint_max_bytes=getattr(args, "window_checkpoint_max_mib", 1024) * 1024**2,
                        window_contract=dict(frame=frame, origin_xyz=origin, size_xyz=size,
                            low_xyz=low.tolist(), high_xyz=high.tolist(), source=provenance),
                        window_event=(lambda event, window: report.emit(event, block=index, window=window)) if window_root is not None else None,
                        progress=lambda done, total: step(0.05 + 0.8 * done / total, f"predicting fibers · window {done} of {total}"),
                    )
                    report.emit("block", index=index, state="splines")

                    def spline_progress(family: str, done: int, total: int) -> None:
                        part = (0 if family == "V" else 1) + (done / total if total else 1)
                        step(0.85 + 0.05 * part, f"fitting {names[family]} fibers · {done} of {total} pieces")

                    traces = extract_splines(probabilities, threshold, spline_progress)
                    del probabilities
                report.emit("block", index=index, state="stitching")
                step(0.95, f"joining {len(traces)} fibers to the neighbouring blocks")
                stitcher.add_block(f"block-{index}", low.tolist(), (high - low).tolist(), traces,
                                   (np.asarray(origin), np.asarray(origin) + np.asarray(size)))
                if checkpoint is not None and index >= checkpoint.completed_count:
                    checkpoint.commit(index, ct, traces)
                del ct
                report.emit("block", index=index, state="stitched")
                if args.preview_dir is not None:
                    preview = args.preview_dir.expanduser().absolute() / f"preview-{index + 1:04d}.afv"
                    shown = clean(stitcher.stitched(), args.max_join_angle, args.min_length)
                    write(preview, shown)
                    report.emit("preview", path=str(preview), fibers=len(shown))
            del network
            if device.type == "cuda":
                torch.cuda.empty_cache()

            if args.extend:
                (Path(scratch) / "ct").mkdir()
                ct_support = CTSupport(RegionReader(volume, spill=Path(scratch) / "ct"), shape_xyz)

                def score(proposals: list[dict[str, Any]], row: dict[str, Any]) -> np.ndarray:
                    features = np.stack(
                        [geometry_features(p["a"], p["b"], p["context"], family=row["family"], voxel_microns=voxel_microns) for p in proposals]
                    )
                    return gap_model.score(features)

                def measure(a: np.ndarray, b: np.ndarray) -> dict[str, Any]:
                    evidence = ct_support.features(a, b)
                    return dict(state="available" if evidence["valid"] else "unavailable", status=evidence["status"])

                owner = {}
                for cid in stitcher.chain_ids():
                    curve = stitcher.catalog.get_curve(cid, include_provenance=False)
                    middle = np.asarray(curve["points"][len(curve["points"]) // 2])
                    owner[cid] = next(
                        (i for i, (o, sz) in enumerate(blocks) if np.all(middle >= o) and np.all(middle < np.asarray(o) + sz)),
                        int(np.argmin([np.linalg.norm(middle - (np.asarray(o) + np.asarray(sz) / 2)) for o, sz in blocks])),
                    )
                remaining = np.bincount(list(owner.values()), minlength=count)
                for index in range(count):
                    report.emit("block", index=index, state="extending" if remaining[index] else "done")
                order = stitcher.chain_ids()

                def expand_progress(done: int, total: int) -> None:
                    if done:
                        block = owner[order[done - 1]]
                        remaining[block] -= 1
                        if remaining[block] == 0:
                            report.emit("block", index=int(block), state="done")
                    report("stitch", f"Extending fibers across gaps · {done} of {total}", done, total)

                traces = stitcher.expand(score, measure, expand_progress)
            else:
                for index in range(count):
                    report.emit("block", index=index, state="done")
                traces = stitcher.stitched()
        finally:
            stitcher.close()

        if checkpoint is not None:
            checkpoint.check_identity()
        report("stitch", f"Cleaning {len(traces)} fibers", 1, 1)
        traces = clean(traces, args.max_join_angle, args.min_length, black, args.black_distance)
        report("write", f"Writing {len(traces)} fibers")
        written = write(output, traces)
        return {"output": str(output), "fibers": written["fiber_count"], "points": written["point_count"], "uuid": written["uuid"]}


def afv_fibers(traces: list[dict[str, Any]], native_scale: int, voxel_size: float | None) -> Iterator[Fiber]:
    families = {0: "V", 1: "H"}
    for index, trace in enumerate(traces, 1):
        points = np.asarray(trace["points"], dtype=np.float64) * native_scale
        length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
        family = families[trace["family"]]
        annotation = {
            "type": "vc3d_fiber",
            "version": 1,
            "sequence": index,
            "hv_classification": {"manual_tag": family},
            "control_points": [points[0].tolist(), points[-1].tolist()],
            "length_voxels": length,
        }
        if voxel_size:
            annotation["length_mm"] = length * voxel_size / 1000
        if trace.get("gaps"):
            # Point index ranges bridging a gap between two observed pieces.
            annotation["inferred_gap_point_ranges"] = trace["gaps"]
        yield Fiber(name=f"fiber_{index}", family=family, points=points, annotation=annotation)


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    report = Reporter(args.progress == "json")
    # Cancelling from VC3D terminates the process: unwind so that no
    # temporary file is left behind.
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(128 + signal.SIGTERM))
    try:
        result = generate(args, report)
    except Exception as error:
        traceback.print_exc(file=sys.stderr)
        report.emit("error", message=str(error) or type(error).__name__)
        return 1
    report.emit("done", fraction=1.0, **result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
