"""Opt-in AFV CPU Conv3d output-Z tiling with complete convolution halos."""
import torch
import torch.nn.functional as F

ORIGINAL_FORWARD=torch.nn.Conv3d.forward

def tiled_forward(layer, x, *, max_im2col_bytes=128*1024**2):
    if max_im2col_bytes < 1:
        raise ValueError('max_im2col_bytes must be positive')
    if x.device.type != 'cpu' or layer.padding_mode != 'zeros':
        return ORIGINAL_FORWARD(layer,x)
    if x.ndim != 5:
        return ORIGINAL_FORWARD(layer,x)
    if any(not isinstance(getattr(layer,key),tuple) or len(getattr(layer,key))!=3
           or not all(isinstance(v,int) for v in getattr(layer,key))
           for key in ('kernel_size','dilation','stride','padding')):
        return ORIGINAL_FORWARD(layer,x)
    kz,ky,kx=layer.kernel_size
    dz,dy,dx=layer.dilation
    sz,sy,sx=layer.stride
    pz,py,px=layer.padding
    out_z=(x.shape[2]+2*pz-dz*(kz-1)-1)//sz+1
    # Conservative im2col bound for a full convolution on this input.
    bytes_per_output_z=(x.shape[1]//layer.groups)*kz*ky*kx*x.shape[3]*x.shape[4]*x.element_size()
    if bytes_per_output_z*out_z <= max_im2col_bytes:
        return ORIGINAL_FORWARD(layer,x)
    tile_z=max(1,min(out_z,max_im2col_bytes//max(bytes_per_output_z,1)))
    padded=F.pad(x,(0,0,0,0,pz,pz)) if pz else x
    out_y=(x.shape[3]+2*py-dy*(ky-1)-1)//sy+1
    out_x=(x.shape[4]+2*px-dx*(kx-1)-1)//sx+1
    out=torch.empty((x.shape[0],layer.out_channels,out_z,out_y,out_x),
                    dtype=x.dtype,device=x.device)
    for z0 in range(0,out_z,tile_z):
        z1=min(out_z,z0+tile_z)
        lo=z0*sz
        hi=(z1-1)*sz+dz*(kz-1)+1
        y=F.conv3d(padded[:,:,lo:hi],layer.weight,layer.bias,
                   stride=layer.stride,padding=(0,py,px),dilation=layer.dilation,
                   groups=layer.groups)
        if y.shape[2] != z1-z0:
            raise AssertionError((y.shape,z0,z1))
        out[:,:,z0:z1].copy_(y)
        del y
    return out
