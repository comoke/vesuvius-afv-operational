"""Opt-in, local block checkpoints; transient stitch catalogues are always rebuilt."""
from __future__ import annotations

import errno
import fcntl
import hashlib
import importlib.metadata
import platform
import sys
import json
import os
import stat
import tempfile
from pathlib import Path

import numpy as np

VERSION = 1


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _open_regular(path: Path):
    """Open the named file without following a symlink, including at read time."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError as error:
        if error.errno == errno.ELOOP:
            raise ValueError(f'Checkpoint symlink is not allowed: {path.name}') from error
        raise
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise ValueError(f'Checkpoint member is not a regular file: {path.name}')
    return os.fdopen(fd, 'rb')


def _file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with _open_regular(path) as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def _tree(root: Path, *, python_only: bool = False) -> str:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError(f"Checkpoint identity needs a local directory: {root}")
    files = sorted(p for p in root.rglob('*') if p.is_file() and (not python_only or p.suffix == '.py'))
    if not files:
        raise ValueError(f"Checkpoint identity has no files: {root}")
    digest = hashlib.sha256()
    for path in files:
        if path.is_symlink():
            raise ValueError(f"Checkpoint identity refuses symlink: {path}")
        digest.update(str(path.relative_to(root)).encode())
        digest.update(b'\0')
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
    return digest.hexdigest()


def _atomic_json(path: Path, value) -> None:
    fd, name = tempfile.mkstemp(prefix='.checkpoint-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True, separators=(',', ':'), allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        _sync_dir(path.parent)
    finally:
        Path(name).unlink(missing_ok=True)


def _sync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _ct_sha(ct: np.ndarray) -> str:
    data = np.ascontiguousarray(ct)
    digest = hashlib.sha256()
    digest.update(str(data.dtype).encode())
    digest.update(json.dumps(data.shape).encode())
    digest.update(memoryview(data).cast('B'))
    return digest.hexdigest()


class Checkpoint:
    """One writer; a contiguous, hash-checked block prefix is the only reusable state."""

    def __init__(self, directory: Path, args, model_folder: Path, code_root: Path, blocks, frame):
        self.directory = Path(directory).expanduser().resolve()
        self.paths = (Path(args.volume).expanduser().resolve(strict=True),
                      Path(model_folder).expanduser().resolve(strict=True),
                      Path(code_root).resolve(strict=True))
        if not self.paths[0].is_dir() or not self.paths[1].is_dir():
            raise ValueError('Checkpoint mode requires local volume and model directories')
        if any(parent == self.directory or parent in self.directory.parents for parent in self.paths):
            raise ValueError('Checkpoint directory must be outside source, model and code trees')
        self.directory.mkdir(parents=True, exist_ok=True)
        lock_path = self.directory / '.lock'
        if lock_path.is_symlink():
            raise ValueError('Checkpoint lock symlink is not allowed')
        lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        self.lock = os.fdopen(lock_fd, 'a+b')
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            config = {key: str(value) if isinstance(value, Path) else value
                      for key, value in vars(args).items()
                      if key not in ('checkpoint_dir', 'progress', 'preview_dir')}
            identity = self._identity(config, blocks, frame)
            self.plan_sha = _sha(json.dumps(identity, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())
            self.index_path = self.directory / 'index.json'
            if self.index_path.is_symlink():
                raise ValueError('Checkpoint index symlink is not allowed')
            if self.index_path.exists():
                with _open_regular(self.index_path) as stream:
                    self.index = json.load(stream)
                if self.index.get('version') != VERSION or self.index.get('identity') != identity or self.index.get('plan_sha256') != self.plan_sha:
                    raise ValueError('Checkpoint source, model, code, config or frame mismatch')
            else:
                if any(p.name != '.lock' for p in self.directory.iterdir()):
                    raise ValueError('Checkpoint directory has uncommitted files but no index')
                self.index = dict(version=VERSION, identity=identity, plan_sha256=self.plan_sha, completed=[])
                _atomic_json(self.index_path, self.index)
            completed = self.index.get('completed')
            if not isinstance(completed, list) or len(completed) > len(blocks):
                raise ValueError('Invalid checkpoint block index')
            self._check_completed(completed)
            self.completed_count = len(completed)
        except BaseException:
            self.close()
            raise

    def _identity(self, config, blocks, frame):
        volume, model, code = self.paths
        packages = {name: importlib.metadata.version(name) for name in
                    ('numpy', 'scipy', 'scikit-image', 'torch', 'zarr', 'nnunetv2')}
        return json.loads(json.dumps(dict(volume_sha256=_tree(volume), model_sha256=_tree(model),
                    code_sha256=_tree(code, python_only=True), runtime=dict(
                        python=sys.version, platform=platform.platform(), packages=packages),
                    config=config, frame=frame, blocks=blocks), sort_keys=True, allow_nan=False))

    def _check_completed(self, completed):
        for i, item in enumerate(completed):
            expected = f'block-{i:06d}.npz'
            if not isinstance(item, dict) or item.get('name') != expected or not isinstance(item.get('sha256'), str):
                raise ValueError('Incomplete or out-of-order checkpoint index')
            path = self.directory / expected
            if path.is_symlink():
                raise ValueError(f'Checkpoint block {i} symlink is not allowed')
            if not path.is_file() or _file_sha(path) != item['sha256']:
                raise ValueError(f'Incomplete or corrupt checkpoint block {i}')

    def check_identity(self):
        if self._identity(self.index['identity']['config'],
                          self.index['identity']['blocks'],
                          self.index['identity']['frame']) != self.index['identity']:
            raise ValueError('Checkpoint inputs changed during execution')
        self._check_completed(self.index['completed'])

    def load(self, index: int, ct: np.ndarray):
        if index >= self.completed_count:
            raise ValueError('Block is not committed')
        item = self.index['completed'][index]
        if _ct_sha(ct) != item['ct_sha256']:
            raise ValueError(f'Block {index} CT changed')
        path = self.directory / item['name']
        if path.is_symlink():
            raise ValueError(f'Checkpoint block {index} symlink is not allowed')
        with _open_regular(path) as stream:
            digest = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
            if digest.hexdigest() != item['sha256']:
                raise ValueError(f'Block {index} checkpoint changed')
            stream.seek(0)
            with np.load(stream, allow_pickle=False) as data:
                if set(data.files) != {'plan', 'index', 'ct_sha', 'families', 'offsets', 'points'}:
                    raise ValueError('Invalid checkpoint fields')
                if str(data['plan']) != self.plan_sha or int(data['index']) != index or str(data['ct_sha']) != item['ct_sha256']:
                    raise ValueError('Checkpoint block identity mismatch')
                families, offsets, points = data['families'], data['offsets'], data['points']
                if (families.dtype != np.dtype('uint8') or offsets.dtype != np.dtype('int64')
                        or points.dtype != np.dtype('float64') or points.ndim != 2 or points.shape[1] != 3
                        or offsets.shape != (len(families) + 1,) or offsets[0] != 0 or offsets[-1] != len(points)
                        or np.any(np.diff(offsets) < 2) or np.any(~np.isin(families, [0, 1]))
                        or not np.isfinite(points).all()):
                    raise ValueError('Invalid checkpoint trace schema')
                return [('V' if int(families[i]) == 0 else 'H', points[int(offsets[i]):int(offsets[i+1])].copy())
                        for i in range(len(families))]

    def commit(self, index: int, ct: np.ndarray, traces) -> None:
        if index != self.completed_count:
            raise ValueError('Checkpoint blocks must commit in order')
        families = np.asarray([0 if family == 'V' else 1 if family == 'H' else 255
                               for family, _ in traces], dtype=np.uint8)
        points = [np.asarray(line, dtype=np.float64) for _, line in traces]
        if np.any(families == 255) or any(p.ndim != 2 or p.shape[1] != 3 or len(p) < 2 or not np.isfinite(p).all() for p in points):
            raise ValueError('Invalid block traces')
        offsets = np.r_[0, np.cumsum([len(p) for p in points])].astype(np.int64)
        joined = np.concatenate(points) if points else np.empty((0, 3), dtype=np.float64)
        ct_sha = _ct_sha(ct)
        name = f'block-{index:06d}.npz'
        fd, temporary = tempfile.mkstemp(prefix=f'.{name}.', suffix='.partial', dir=self.directory)
        try:
            with os.fdopen(fd, 'wb') as stream:
                np.savez_compressed(stream, plan=np.asarray(self.plan_sha), index=np.asarray(index),
                                    ct_sha=np.asarray(ct_sha), families=families,
                                    offsets=offsets, points=joined)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.directory / name)
            _sync_dir(self.directory)
            item = dict(name=name, sha256=_file_sha(self.directory / name), ct_sha256=ct_sha)
            updated = dict(self.index, completed=[*self.index['completed'], item])
            _atomic_json(self.index_path, updated)
            self.index = updated
            self.completed_count += 1
        finally:
            Path(temporary).unlink(missing_ok=True)

    def close(self):
        if hasattr(self, 'lock') and not self.lock.closed:
            self.lock.close()

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()
