"""Opt-in recovery of completed CPU prediction windows within an AFV block.

The stored arrays are float32, pre-weight, three-channel probabilities. Replay
uses the original accumulation loop and order. This is a local single-writer
process-crash protocol, not a power-loss or hostile-concurrent-writer guarantee.
"""
from __future__ import annotations

import fcntl
import hashlib
import inspect
import json
import math
import marshal
import os
import platform
import stat
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch

from .checkpoint import _atomic_json, _ct_sha, _file_sha, _open_regular, _sync_dir

VERSION = 1


def canonical(value):
    return json.loads(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False))


def config_value(value):
    """Bind non-state forward configuration; fail closed on unknown objects."""
    if value is None or type(value) in (str, int, float, bool):
        return value
    if isinstance(value, (tuple, list)):
        return [config_value(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted((config_value(v) for v in value), key=lambda v: json.dumps(v, sort_keys=True))
    if isinstance(value, dict) and all(isinstance(k, str) for k in value):
        return {k: config_value(v) for k, v in sorted(value.items())}
    if isinstance(value, torch.Tensor):
        if value.device.type != 'cpu':
            raise ValueError('Window recovery configuration tensor must be on CPU')
        return dict(tensor_shape=list(value.shape), tensor_dtype=str(value.dtype),
                    tensor_sha256=_ct_sha(value.detach().contiguous().numpy()))
    if inspect.isfunction(value):
        # The admitted residual blocks use a closure-free identity lambda for skip.
        # General functions with globals/closures are deliberately unsupported.
        if (value.__closure__ or value.__code__.co_names or value.__defaults__ or value.__kwdefaults__
                or any(isinstance(c, type(value.__code__)) for c in value.__code__.co_consts)):
            raise ValueError('Window recovery refuses configuration functions with globals, closures or defaults')
        path = inspect.getsourcefile(value)
        if not path or not Path(path).is_file():
            raise ValueError('Window recovery cannot identify configuration function source')
        return dict(function=value.__module__ + '.' + value.__qualname__,
                    source_sha256=_file_sha(Path(path)),
                    code_sha256=hashlib.sha256(marshal.dumps(value.__code__)).hexdigest())
    if isinstance(value, type):
        path = inspect.getsourcefile(value)
        if not path or not Path(path).is_file():
            raise ValueError('Window recovery cannot identify configuration type')
        return dict(type=value.__module__ + '.' + value.__qualname__, source_sha256=_file_sha(Path(path)))
    raise ValueError(f'Unsupported model configuration type: {type(value).__name__}')


def model_identity(network):
    """Conservative identity for the admitted, eval-only CPU float32 model."""
    if any(m.training for m in network.modules()):
        raise ValueError('Window recovery requires all model modules in eval mode')
    sources = {}
    configuration = []
    for module in network.modules():
        if module._forward_hooks or module._forward_pre_hooks:
            raise ValueError('Window recovery refuses model forward hooks')
        if 'forward' in module.__dict__:
            raise ValueError('Window recovery refuses instance-patched model forwards')
        cls = type(module)
        name = cls.__module__ + '.' + cls.__qualname__
        path = inspect.getsourcefile(cls)
        if not path or not Path(path).is_file():
            raise ValueError(f'Window recovery cannot identify model class source: {name}')
        sources[name] = _file_sha(Path(path))
        attrs = {key: config_value(value) for key, value in vars(module).items()
                 if key not in ('_parameters', '_buffers', '_modules')}
        buffers = {key: config_value(value) for key, value in module._buffers.items()}
        configuration.append(dict(class_name=name, attributes=attrs, buffers=buffers))
    state = hashlib.sha256()
    for name, value in sorted(network.state_dict().items()):
        if not isinstance(value, torch.Tensor) or value.device.type != 'cpu':
            raise ValueError('Window recovery requires ordinary CPU model tensors')
        data = value.detach().contiguous().numpy()
        state.update(json.dumps([name, list(value.shape), str(value.dtype)]).encode() + b'\0' + _ct_sha(data).encode())
    return dict(state_sha256=state.hexdigest(), representation=repr(network), sources=sources, configuration=configuration)


def prediction_identity(network, ct, image, patch, pad, windows, contract):
    here = Path(__file__).parent
    implementation = {name: _file_sha(here / name) for name in
                      ('predict.py', 'tiled_conv3d.py', 'window_checkpoint.py', 'checkpoint.py')}
    return canonical(dict(version=VERSION, ct_sha256=_ct_sha(ct),
        normalized_padded_image_sha256=_ct_sha(image), ct_shape=ct.shape,
        image_shape=image.shape, patch=patch, pad=pad, windows=windows,
        model=model_identity(network), implementation=implementation, contract=contract,
        runtime=dict(python=sys.version, platform=platform.platform(), torch=torch.__version__,
            numpy=np.__version__, threads=torch.get_num_threads(),
            interop_threads=torch.get_num_interop_threads(),
            deterministic=torch.are_deterministic_algorithms_enabled(),
            mkldnn_enabled=torch.backends.mkldnn.enabled,
            default_dtype=str(torch.get_default_dtype()))))


class WindowCheckpoint:
    def __init__(self, directory, identity, shape, count, max_bytes, event=None):
        self.directory = Path(directory).expanduser().absolute()
        self.shape = tuple(shape)
        self.count = int(count)
        self.event = event or (lambda *_: None)
        if (len(self.shape) != 4 or self.shape[0] != 3 or
                any(type(n) is not int or n <= 0 for n in self.shape) or self.count < 1):
            raise ValueError('Invalid prediction window shape/count')
        self.payload_limit = math.prod(self.shape) * 4 + 1024
        self.max_bytes = int(max_bytes)
        # Include one in-flight payload and bounded index/temporary bookkeeping.
        self.required_bytes = (self.count + 1) * self.payload_limit + 1024**2
        if self.max_bytes < self.required_bytes:
            raise ValueError(f'Window cache budget too small: need at least {self.required_bytes} bytes')
        if any(p.is_symlink() for p in (self.directory, *self.directory.parents)):
            raise ValueError('Window cache directory may not traverse a symlink')
        self.directory = self.directory.resolve()
        self.identity = canonical(identity)
        self.identity_sha = hashlib.sha256(json.dumps(self.identity, sort_keys=True,
            separators=(',', ':')).encode()).hexdigest()
        self.directory.mkdir(parents=True, exist_ok=True)
        fd = os.open(self.directory / '.lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd)
            raise ValueError('Window lock is not a regular file')
        self.lock = os.fdopen(fd, 'a+b')
        try:
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.index_path = self.directory / 'index.json'
            if self.index_path.exists() or self.index_path.is_symlink():
                with _open_regular(self.index_path) as stream:
                    if os.fstat(stream.fileno()).st_size > 1024**2:
                        raise ValueError('Window index is too large')
                    self.index = json.load(stream)
                if (self.index.get('version') != VERSION or self.index.get('identity') != self.identity or
                        self.index.get('identity_sha256') != self.identity_sha or
                        self.index.get('shape') != list(self.shape) or self.index.get('count') != self.count):
                    raise ValueError('Window checkpoint input/model/code/runtime/contract mismatch')
            else:
                if any(p.name != '.lock' for p in self.directory.iterdir()):
                    raise ValueError('Window cache has uncommitted files but no index')
                self.index = dict(version=VERSION, identity=self.identity, identity_sha256=self.identity_sha,
                                  shape=list(self.shape), count=self.count, completed=[])
                _atomic_json(self.index_path, self.index)
            completed = self.index.get('completed')
            if not isinstance(completed, list) or len(completed) > self.count:
                raise ValueError('Invalid completed-window index')
            for i, item in enumerate(completed):
                if not isinstance(item, dict) or item.get('name') != self.name(i):
                    raise ValueError('Window index is not a contiguous prefix')
                self._read(i)
            self.completed_count = len(completed)
            self._budget()
        except BaseException:
            self.close()
            raise

    @staticmethod
    def name(index):
        return f'window-{index:06d}.npy'

    def _budget(self):
        used = 0
        for p in self.directory.iterdir():
            if p.is_symlink() or not p.is_file():
                raise ValueError('Window cache contains a non-regular member')
            used += p.stat().st_size
        # Preserve orphan data from an interrupted commit; never trust it.
        remaining = self.count - len(self.index['completed'])
        if used + remaining * self.payload_limit + self.payload_limit > self.max_bytes:
            raise ValueError('Window cache exceeds budget, including uncommitted data')
        available = os.statvfs(self.directory).f_bavail * os.statvfs(self.directory).f_frsize
        if remaining * self.payload_limit + self.payload_limit > available:
            raise OSError('Insufficient disk space for window cache')

    def _read(self, index):
        item = self.index['completed'][index]
        with _open_regular(self.directory / self.name(index)) as stream:
            size = os.fstat(stream.fileno()).st_size
            if size != item.get('bytes') or size > self.payload_limit:
                raise ValueError('Window payload size changed or exceeds bound')
            data = stream.read(self.payload_limit + 1)
            if hashlib.sha256(data).hexdigest() != item.get('sha256'):
                raise ValueError('Window payload hash mismatch')
            stream.seek(0)
            array = np.load(stream, allow_pickle=False, max_header_size=512)
        if (array.dtype != np.dtype('float32') or array.shape != self.shape or
                not array.flags.c_contiguous or not np.isfinite(array).all() or
                np.any(array < 0) or np.any(array > 1)):
            raise ValueError('Invalid probability window')
        return array

    def _assert_open(self):
        if not hasattr(self, 'lock') or self.lock.closed:
            raise ValueError('Window checkpoint is closed')

    def load(self, index):
        self._assert_open()
        if not 0 <= index < self.count:
            raise ValueError('Window index out of range')
        if index >= self.completed_count:
            return None
        array = self._read(index)
        self.event('window_replayed', index)
        return torch.from_numpy(array)

    def commit(self, index, probability):
        self._assert_open()
        if not 0 <= index < self.count or index != self.completed_count:
            raise ValueError('Windows must commit in order')
        array = np.ascontiguousarray(probability.detach().cpu().numpy())
        if (array.dtype != np.dtype('float32') or array.shape != self.shape or
                not np.isfinite(array).all() or np.any(array < 0) or np.any(array > 1)):
            raise ValueError('Invalid probability to checkpoint')
        self._budget()
        fd, temporary = tempfile.mkstemp(prefix=f'.{self.name(index)}.', suffix='.partial', dir=self.directory)
        try:
            with os.fdopen(fd, 'wb') as stream:
                np.save(stream, array, allow_pickle=False)
                stream.flush()
                os.fsync(stream.fileno())
            target = self.directory / self.name(index)
            os.replace(temporary, target)
            _sync_dir(self.directory)
            self.event('window_payload_published', index)
            item = dict(name=target.name, sha256=_file_sha(target), bytes=target.stat().st_size)
            updated = dict(self.index, completed=[*self.index['completed'], item])
            _atomic_json(self.index_path, updated)
            self.index = updated
            self.completed_count += 1
            self.event('window_committed', index)
        finally:
            Path(temporary).unlink(missing_ok=True)

    def close(self):
        if hasattr(self, 'lock') and not self.lock.closed:
            self.lock.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
