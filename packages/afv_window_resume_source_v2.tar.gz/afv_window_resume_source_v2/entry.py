"""Task-local executable; loads candidate modules without editing installed wheel."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
import time

HERE=Path(__file__).resolve().parent
CANDIDATE=HERE/'candidate'
import torch
import vesuvius.afv_spline_generator as package

PINS={'predict.py':'8230b6f18f93e15de5ab5838c5a7e82b3d2ec0134fb79214ba028d07d14a6b35',
      'cli.py':'0cf32bfb572125c2be97021a6f71b76759030dda392d7e3201480d6925acf62e',
      'checkpoint.py':'e29212090dc2711489baac411122b4b4d57908ab9e28e8fa60769e90a2346a69',
      'tiled_conv3d.py':'4b9592c7d80122e488f7ead9c207bda50b9b1d3e854f26ffcd2b86d9a5bb49de'}
BASE=Path(package.__file__).parent
for name,wanted in PINS.items():
    assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==wanted
assert not os.environ.get('PYTHONPATH')
torch.set_num_threads(2)
original_load=torch.load
def load(path,*args,**kwargs):
    if str(path).endswith('checkpoint_final.pth'):
        kwargs['weights_only']=True
    return original_load(path,*args,**kwargs)
torch.load=load
if os.environ.get('WINDOW_BASELINE')!='1':
    for name in ('window_checkpoint','predict','cli'):
        full='vesuvius.afv_spline_generator.'+name
        spec=importlib.util.spec_from_file_location(full,CANDIDATE/(name+'.py'))
        mod=importlib.util.module_from_spec(spec)
        sys.modules[full]=mod
        setattr(package,name,mod)
        spec.loader.exec_module(mod)
from vesuvius.afv_spline_generator import cli,predict

original_predict=predict.predict_fibers
def observed(*args,**kwargs):
    start=time.monotonic()
    result=original_predict(*args,**kwargs)
    print(json.dumps({'event':'probabilities','sha256':hashlib.sha256(result.tobytes()).hexdigest(),
        'shape':list(result.shape),'seconds':time.monotonic()-start}),flush=True)
    return result
predict.predict_fibers=observed
if __name__=='__main__':
    raise SystemExit(cli.main())
