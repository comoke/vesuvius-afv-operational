# AFV intra-block window recovery — opt-in source addition

This opt-in extension saves completed prediction windows inside one unfinished AFV block. The existing block checkpoint can only reuse a block after all its predictions and spline processing finish. If this candidate is interrupted, its next invocation replays committed pre-weight float32 probability windows in the original accumulation order and computes only the remaining windows.

This is a separately versioned source addition. It leaves the default AFV generator unchanged and requires the exact installed runtime and admitted inputs described below.

## Supported scope

- Exactly one AFV block per invocation, local CT/model, CPU, mirror off, 128³ model windows, existing tiled Conv3d path, eval-only model, no extension or preview.
- The tested model is the already admitted `Qualzz20/afv_fiber_9um` export using `ResidualEncoderUNet`; other architectures are not validated. Unknown model configuration objects, active forward hooks and instance-patched forwards refuse.
- A cache belongs to the exact raw CT, full normalized/padded CT, model state/configuration/class source, prediction code, patch/window order, frame/ROI contract, runtime and CPU thread settings. This binds the actual inputs used, without claiming independent scientific truth.
- Single writer on the same local filesystem. Committed arrays are checksum verified without pickle. Data published before an interrupted index commit is untrusted and recomputed. Atomic replacement may overwrite that unindexed same-window payload; committed windows are not evicted automatically.
- A capacity check covers all windows plus one in-flight payload and index allowance before creating the cache. V1 refuses multiple blocks to keep this a complete-job budget. Cache must be outside source/model/CT trees. It is not a power-loss guarantee or protection against a hostile process changing code/files concurrently.

## Existing runtime prerequisite

Use the already reviewed installed AFV runtime built from Villa `8ff06f7620dcb663ed327028dbb8a0cf7e9a8198`, Qualzz PR #1934, and the accepted AFV memory/block-restart additions. This candidate does not install software or download models. `entry.py` checks four installed source SHA-256 values before loading task-local candidate modules. It does not edit the installed wheel.

Source origin: [Qualzz's AFV generator PR](https://github.com/ScrollPrize/villa/pull/1934). The November 1 live metadata check still found PR head `2d8577ed2aaf6b2cd7a5a023bb824538cd20b0e0`; its `predict.py` has no window persistence. This is a bounded source comparison, not a claim that prediction caching is a new general algorithm.

## Use

Extract the source-only archive into its own directory. Choose a separate existing output directory and an external cache directory. Run with the existing reviewed Python environment, replacing the uppercase placeholders:

```sh
PYTHONDONTWRITEBYTECODE=1 MODEL_PYTHON entry.py \
  --volume LOCAL_CT_ZARR --model LOCAL_MODEL_DIRECTORY \
  --origin X Y Z --size SX SY SZ --block-size 512 \
  --output OUTPUT_DIRECTORY/fibers.afv \
  --coordinate-space EXACT_LOCAL_FRAME --native-scale 1 --voxel-size MICRONS \
  --device cpu --no-mirror --no-extend --cpu-tiled-conv3d \
  --window-checkpoint-dir SEPARATE_CACHE_DIRECTORY \
  --window-checkpoint-max-mib 128 --progress json
```

`MODEL_PYTHON` denotes the executable path, not a literal shell variable assignment. On interruption, repeat with the same inputs/settings and cache. If a final output already exists, the AFV CLI refuses replacement; choose a new output filename for a warm verification. Do not set the experiment-only `WINDOW_BASELINE` variable, which bypasses the candidate for control runs.

Each 128³ probability window uses 24 MiB plus a small NPY header. The tested three-window cache uses about 72 MiB plus its identity index. A full 512³ input has 343 windows before considering boundary context, so its cache would require over 8 GiB and a suitably increased explicit budget. Larger jobs, GPU, multi-block retention, distributed filesystems and another host remain unverified.

## Verification

`test_candidate.py` runs a small synthetic model and validates exact blended output after interruption, warm reuse, input/model mismatch, lock/corruption/budget refusal, and orphan recomputation. Run it with the existing reviewed environment:

```sh
PYTHONDONTWRITEBYTECODE=1 MODEL_PYTHON test_candidate.py
```

The source-only `RESULT_SUMMARY.json` records a bounded three-window result. A separate 27-window same-source test reused 18 committed windows and computed nine after interruption; completed arms preserved 305 fibers and 7,208 points, with exact probability bytes and seven AFV tables except generated UUID. Paired native readback preserved 915 geometry arrays. The recovery invocation took 61.575 seconds versus 176.170 seconds for full recomputation, with 679,863,737 bytes of cache storage. These are same-host observations, not a general speed gain. Frozen run receipts remain outside this source archive. The new work establishes saved computation with identical outputs; it does not establish fiber accuracy, winding correctness, readable text, or prize eligibility.
