# Scope and provenance

The AFV generator and prediction/blending workflow originate with Qualzz's Villa PR #1934. Villa's MIT license is retained in `LICENSE-UPSTREAM-VILLA-MIT.txt`.

`candidate/checkpoint.py`, `candidate/tiled_conv3d.py`, and the previously present memory/restart parts of `candidate/cli.py` and `candidate/predict.py` are the earlier accepted task additions. Their existing scoped MIT notice is retained in `LICENSE-EXISTING-TASK-ADDITIONS.txt`; that grant applies to those existing additions only.

The new original `candidate/window_checkpoint.py`, new window-recovery hunks in `cli.py.patch` and `predict.py.patch`, and original entry/test/documentation content are released under the scoped MIT grant in `LICENSE-TASK-WINDOW-ADDITIONS.txt`. This grant does not relicense upstream Villa code or earlier task additions.

This source-only archive contains no model weights, CT, AFV, native object-store geometry, native executable, credentials, or personal absolute paths. Upstream third-party runtime packages remain external prerequisites under their own licenses. No GPL VC3D executable source is bundled.
