from pathlib import Path
import importlib.util
import json
import os
import sys
import tempfile
import unittest
import numpy as np
import torch

HERE=Path(__file__).resolve().parent
import vesuvius.afv_spline_generator as package
for name in ('window_checkpoint','predict'):
    full='vesuvius.afv_spline_generator.'+name
    spec=importlib.util.spec_from_file_location(full,HERE/'candidate'/(name+'.py'))
    mod=importlib.util.module_from_spec(spec);sys.modules[full]=mod;setattr(package,name,mod);spec.loader.exec_module(mod)
from vesuvius.afv_spline_generator.window_checkpoint import WindowCheckpoint
from vesuvius.afv_spline_generator.predict import predict_fibers

torch.set_num_threads(2)
class Tests(unittest.TestCase):
    def test_real_blend_protocol(self):
        network=torch.nn.Sequential(torch.nn.Conv3d(1,4,1,bias=True)).eval()
        torch.manual_seed(10)
        ct=np.random.default_rng(203).integers(0,255,(129,65,160),dtype=np.uint8)
        events=[]
        kwargs=dict(device=torch.device('cpu'),mirror=False,cpu_tiled_conv3d=True)
        expected=predict_fibers(network,ct,(128,128,128),**kwargs)
        with tempfile.TemporaryDirectory(dir=HERE/'evidence') as directory:
            path=Path(directory)/'cache'
            def stop_after_first(event,index):
                events.append((event,index))
                if event=='window_committed' and index==0:raise InterruptedError('injected')
            with self.assertRaises(InterruptedError):
                predict_fibers(network,ct,(128,128,128),window_checkpoint_dir=path,
                    window_event=stop_after_first,**kwargs)
            resumed_events=[]
            actual=predict_fibers(network,ct,(128,128,128),window_checkpoint_dir=path,
                window_event=lambda *x:resumed_events.append(x),**kwargs)
            self.assertTrue(np.array_equal(expected,actual))
            self.assertEqual(sum(e=='window_replayed' for e,_ in resumed_events),1)
            warm=[]
            self.assertTrue(np.array_equal(actual,predict_fibers(network,ct,(128,128,128),
                window_checkpoint_dir=path,window_event=lambda *x:warm.append(x),**kwargs)))
            self.assertFalse(any(e=='window_network_start' for e,_ in warm))
            changed=ct.copy();changed.flat[0]^=1
            with self.assertRaisesRegex(ValueError,'mismatch'):
                predict_fibers(network,changed,(128,128,128),window_checkpoint_dir=path,**kwargs)
            with torch.no_grad():network[0].bias[0]+=1
            with self.assertRaisesRegex(ValueError,'mismatch'):
                predict_fibers(network,ct,(128,128,128),window_checkpoint_dir=path,**kwargs)
    def test_storage_protocol(self):
        shape=(3,2,2,2);p=torch.full(shape,0.25)
        with tempfile.TemporaryDirectory(dir=HERE/'evidence') as directory:
            path=Path(directory)/'cache'
            with WindowCheckpoint(path,{'id':1},shape,2,2**22) as cache:
                cache.commit(0,p)
                self.assertTrue(torch.equal(cache.load(0),p))
                with self.assertRaises(BlockingIOError):WindowCheckpoint(path,{'id':1},shape,2,2**22)
            with self.assertRaisesRegex(ValueError,'mismatch'):WindowCheckpoint(path,{'id':2},shape,2,2**22)
            payload=path/'window-000000.npy';data=payload.read_bytes();payload.write_bytes(data[:-1])
            with self.assertRaisesRegex(ValueError,'size'):WindowCheckpoint(path,{'id':1},shape,2,2**22)
    def test_orphan_recomputed(self):
        shape=(3,2,2,2);p=torch.full(shape,0.25)
        with tempfile.TemporaryDirectory(dir=HERE/'evidence') as directory:
            path=Path(directory)/'cache'
            def crash(event,index):
                if event=='window_payload_published':raise InterruptedError()
            with self.assertRaises(InterruptedError):
                with WindowCheckpoint(path,{'id':1},shape,2,2**22,crash) as cache:cache.commit(0,p)
            with WindowCheckpoint(path,{'id':1},shape,2,2**22) as cache:
                self.assertIsNone(cache.load(0));cache.commit(0,p+0.1)
                self.assertTrue(torch.equal(cache.load(0),p+0.1))
    def test_budget_before_create(self):
        with tempfile.TemporaryDirectory(dir=HERE/'evidence') as directory:
            path=Path(directory)/'cache'
            with self.assertRaisesRegex(ValueError,'budget'):WindowCheckpoint(path,{},(3,128,128,128),3,1024)
            self.assertFalse(path.exists())

if __name__=='__main__':unittest.main(verbosity=2)
