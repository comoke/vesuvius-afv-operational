# Schema-17 standalone AFV file handoff — source package V5

This source-only package contains the reviewed small patch to the exact Villa 8ff AFV importer and a deterministic **one-fiber synthetic** test. It requires no CT, labels, model, weights or saved real AFV. The test makes a task-owned copy of the exact upstream importer, applies the patch there, imports the same synthetic AFV with original and patched code, and checks a fresh main-file-only read-only open, exact geometry bytes, ordinary writable WAL behavior and failure-before-publication. It never edits the upstream checkout.

V5 preserves the reviewed V4 patch, test and helper code bytes. It updates the release documentation and package metadata to 0.1.4. `LICENSE-TASK-ADDITIONS.txt` covers original task-authored additions under the owner's MIT grant; Villa's `LICENSE` is retained byte-for-byte. `NOTICE.md` distinguishes these scopes. Earlier V3 and V4 archives remain unchanged as historical receipts.

## Exact prerequisites

- Python 3.14.9 and NumPy 2.5.4. The package's local wheel uses setuptools 84.0.0 as its build backend. `pip` resolves these from official PyPI when not already cached; no dependency wheel is bundled.
- Git for `git apply` against a task-owned copy; Villa source at `8ff06f7620dcb663ed327028dbb8a0cf7e9a8198`, with `vc_object_store/scripts/import_afv.py` SHA-256 `9a6d97d97409499b362798c13e73f70d3fc52524efab52496db45ac1d9d25031`.
- A separately built `vc_object_store` Python extension for the chosen Python ABI. `BUILD_NATIVE.md` records the exact source revisions, build options and macOS dependencies from the accepted 8ff build. The native binary is external and must be supplied via `--native-pythonpath`.

From a **clean extraction** in a new task-owned directory, install this package into an isolated venv, then run both entry points:

```sh
python3.14 -m venv "$WORK_DIR/venv"
"$WORK_DIR/venv/bin/python" -m pip install .
"$WORK_DIR/venv/bin/python" -m pip check
"$WORK_DIR/venv/bin/vc-afv-standalone-demo" --help
"$WORK_DIR/venv/bin/vc-afv-standalone-readback" --help

"$WORK_DIR/venv/bin/vc-afv-standalone-demo" \
  --native-pythonpath "$NATIVE_BUILD/python" \
  --upstream-importer "$VILLA/vc_object_store/scripts/import_afv.py" \
  --output-dir "$WORK_DIR/synthetic-one-fiber" \
  --require-baseline-failure
```

`WORK_DIR`, `NATIVE_BUILD` and `VILLA` are operator-selected task-owned paths. `--output-dir` must **not exist**. The optional `--expected-native-sha256` pins a specific local binary; the accepted Mac's binary hash is in `UPSTREAM_PINS.json`. Omit `--require-baseline-failure` on other platforms: the baseline main-file-only open failure was observed on this Mac and is recorded even when another SQLite build behaves differently. Patched main-file-only success and exact geometry are always required.

The demo writes `RESULT.json` and small synthetic files only inside the chosen output directory. The package source contains the patch and wrapper, not the upstream importer source or native module. `NOTICE.md` separates upstream code, the task-4 patch, task-6 test wrapper and external dependency licenses; both MIT notices are carried as package license files. Real cached Scroll 3 operator results are described in `REAL_EVIDENCE_REF.md` but their inputs and outputs are not distributed. This synthetic test demonstrates the file-only handoff; it does not establish scientific quality, VC3D GUI behavior or cross-platform native builds.
