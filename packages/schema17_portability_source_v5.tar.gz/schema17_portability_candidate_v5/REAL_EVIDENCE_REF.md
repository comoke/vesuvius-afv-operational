# Separate real-run evidence

The cached Scroll 3 installed-wheel → schema-17 current-native operator result is **not** bundled here. That result used a saved AFV, external CT/model, a task-local volume binding and an exact native build; it verified 192 fibers, 4,756 points and 576 exact geometry arrays. These real inputs and outputs are not redistributed by this source package.

This package's one-fiber result is a reproducibility check for the narrower **standalone main-file publication fix**. It is not a scientific result or a substitute for the cached real-run evidence.
