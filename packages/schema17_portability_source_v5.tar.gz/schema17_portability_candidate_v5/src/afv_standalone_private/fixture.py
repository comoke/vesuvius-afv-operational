"""Deterministic one-fiber AFV fixture with no CT or model dependency."""
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import struct

RAW = struct.pack('<6d', 0, 0, 0, 1, 1, 1)
CONTROL_IDS = struct.pack('<2q', 0, 1)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def make_afv(path):
    path = Path(path)
    if path.exists() or path.is_symlink():
        raise FileExistsError(path)
    metadata = {
        'uuid': 'bd6d13fc-409d-4b58-a198-69e9136160de',
        'complete': True, 'fiber_count': 1, 'point_count': 2,
        'frame': {}, 'root': {'coordinate_order': 'XYZ', 'coordinate_units': 'voxel'},
    }
    with sqlite3.connect(path) as db:
        db.executescript('''PRAGMA application_id=1447249475; PRAGMA user_version=1;
            CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE fibers(id INTEGER PRIMARY KEY,name TEXT,family TEXT,point_count INTEGER,length REAL,
                min_x REAL,max_x REAL,min_y REAL,max_y REAL,min_z REAL,max_z REAL,annotation TEXT);
            CREATE TABLE blocks(id INTEGER PRIMARY KEY,fiber_id INTEGER,first_segment INTEGER,points BLOB,
                UNIQUE(fiber_id,first_segment));''')
        db.executemany('INSERT INTO metadata VALUES(?,?)',
                       [(key, json.dumps(value)) for key, value in metadata.items()])
        db.execute('INSERT INTO fibers VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                   (0, 'one fiber', 'H', 2, math.sqrt(3), 0, 1, 0, 1, 0, 1, '{}'))
        db.execute('INSERT INTO blocks(fiber_id,first_segment,points) VALUES(?,?,?)',
                   (0, 0, RAW))
    return sha(path)
