"""Fresh-process read-only validation of one standalone synthetic store."""
import argparse
import json
from pathlib import Path
import struct
import sys

from .fixture import CONTROL_IDS, RAW, sha


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-pythonpath', type=Path, required=True)
    parser.add_argument('--store', type=Path, required=True)
    args = parser.parse_args(argv)
    native = args.native_pythonpath.resolve(strict=True)
    sys.path.insert(0, str(native))
    from vc_object_store import ObjectStore
    module = Path(sys.modules['vc_object_store'].__file__).resolve()
    if module != native / 'vc_object_store/__init__.py':
        raise RuntimeError(f'native module origin differs: {module}')
    before = sha(args.store)
    with ObjectStore.open(str(args.store.resolve()), read_only=True) as store:
        fibers = store.objects_by_kind('fiber')
        if len(fibers) != 1:
            raise RuntimeError(f'expected one fiber, got {len(fibers)}')
        revision = store.current_geometry(fibers[0]['uuid'])['uuid']
        arrays = {
            'line_points': RAW,
            'control_points': RAW,
            'control_point_ids': CONTROL_IDS,
        }
        for name, expected in arrays.items():
            if store.read_geometry_array(revision, name) != expected:
                raise RuntimeError(f'{name} differs from source bytes')
    if sha(args.store) != before:
        raise RuntimeError('read-only open changed the store')
    if any(Path(str(args.store) + suffix).exists() for suffix in ('-wal', '-shm')):
        raise RuntimeError('read-only open created SQLite sidecars')
    print(json.dumps({'status': 'pass', 'store_sha256': before,
                      'fiber_uuid': fibers[0]['uuid'], 'exact_arrays': 3,
                      'native_module_origin': str(module)}, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
