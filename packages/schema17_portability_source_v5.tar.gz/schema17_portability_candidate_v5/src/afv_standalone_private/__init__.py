"""Private exact-source AFV standalone-publication regression package."""

__version__ = "0.1.1"
