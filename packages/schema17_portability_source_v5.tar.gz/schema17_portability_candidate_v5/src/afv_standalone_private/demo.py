"""Reproduce the exact 8ff standalone AFV import fix on synthetic data."""
import argparse
import importlib.util
from importlib.resources import as_file, files
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

from .fixture import make_afv, sha

UPSTREAM_SHA = '9a6d97d97409499b362798c13e73f70d3fc52524efab52496db45ac1d9d25031'
PATCHED_SHA = 'd4d478d9ecf5a558bcf9123cd459f0629a7215a6be6452b64a67f4547f1d1c65'
PATCH_SHA = '5dc56f0754e1a73b23dd12c802597b4455372c561f539388d866f561be3081d0'


def module_from_file(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sqlite_state(path):
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        return {'schema': db.execute('PRAGMA user_version').fetchone()[0],
                'journal': db.execute('PRAGMA journal_mode').fetchone()[0],
                'integrity': db.execute('PRAGMA integrity_check').fetchone()[0]}


def fresh_readback(native, path):
    return subprocess.run([sys.executable, '-m', 'afv_standalone_private.readback',
                           '--native-pythonpath', str(native), '--store', str(path)],
                          capture_output=True, text=True, check=False, timeout=30)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-pythonpath', type=Path, required=True,
                        help='Built vc_object_store Python package directory; binary is external')
    parser.add_argument('--upstream-importer', type=Path, required=True,
                        help='Exact 8ff06f vc_object_store/scripts/import_afv.py')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='New empty task-owned directory for synthetic outputs')
    parser.add_argument('--expected-native-sha256', help='Optional exact binary receipt for this host')
    parser.add_argument('--require-baseline-failure', action='store_true',
                        help='Require the baseline main-file-only read-only failure observed on macOS')
    args = parser.parse_args(argv)
    native = args.native_pythonpath.resolve(strict=True)
    original_file = args.upstream_importer.resolve(strict=True)
    if sha(original_file) != UPSTREAM_SHA:
        parser.error('upstream importer does not match exact 8ff source hash')
    binaries = list((native / 'vc_object_store').glob('_native*.so'))
    if len(binaries) != 1:
        parser.error('expected exactly one native vc_object_store extension')
    binary_sha = sha(binaries[0])
    if args.expected_native_sha256 and binary_sha != args.expected_native_sha256:
        parser.error('native extension hash differs from requested pin')
    sys.path.insert(0, str(native))
    from vc_object_store import ObjectStore
    native_origin = Path(sys.modules['vc_object_store'].__file__).resolve()
    if native_origin != native / 'vc_object_store/__init__.py':
        raise RuntimeError(f'native module origin differs: {native_origin}')
    original = module_from_file(original_file, 'exact_upstream_importer')
    output = args.output_dir.absolute()
    output.mkdir(parents=True, exist_ok=False)
    source_root = output / 'source-copy'
    importer_copy = source_root / 'vc_object_store/scripts/import_afv.py'
    importer_copy.parent.mkdir(parents=True)
    shutil.copy2(original_file, importer_copy)
    with as_file(files('afv_standalone_private').joinpath('WAL_STANDALONE_FIX.diff')) as patch:
        if sha(patch) != PATCH_SHA:
            raise RuntimeError('installed standalone patch differs from reviewed version')
        for check_only in (True, False):
            argv = ['git', 'apply']
            if check_only:
                argv.append('--check')
            argv.extend(['--whitespace=error', str(patch)])
            applied = subprocess.run(argv, cwd=source_root, capture_output=True,
                                     text=True, check=False, timeout=30)
            if applied.returncode != 0:
                raise RuntimeError(f'exact patch application failed: {applied.stderr[-500:]}')
    if sha(importer_copy) != PATCHED_SHA:
        raise RuntimeError('patched task-owned importer source hash differs')
    patched = module_from_file(importer_copy, 'task_owned_patched_importer')
    source = output / 'one-fiber.afv'
    source_sha = make_afv(source)

    baseline = output / 'upstream.vcobj'
    original.import_afv(source, baseline, unbound=True, author='private-demo', progress=False)
    baseline_main = output / 'upstream-main-only.vcobj'
    shutil.copy2(baseline, baseline_main)
    baseline_probe = fresh_readback(native, baseline_main)
    baseline_state = sqlite_state(baseline)
    if baseline_state['schema'] != 17 or baseline_state['journal'] != 'wal':
        raise RuntimeError(f'unexpected upstream schema/journal: {baseline_state}')
    if args.require_baseline_failure and baseline_probe.returncode == 0:
        raise RuntimeError('baseline main-file-only open unexpectedly succeeded')

    fixed = output / 'patched.vcobj'
    patched.import_afv(source, fixed, unbound=True, author='private-demo', progress=False)
    fixed_state = sqlite_state(fixed)
    if fixed_state != {'schema': 17, 'journal': 'delete', 'integrity': 'ok'}:
        raise RuntimeError(f'patched schema/journal/integrity differs: {fixed_state}')
    if any(Path(str(fixed) + suffix).exists() for suffix in ('-wal', '-shm')):
        raise RuntimeError('patched importer left sidecars')
    fixed_main = output / 'patched-main-only.vcobj'
    shutil.copy2(fixed, fixed_main)
    fixed_before = sha(fixed_main)
    fixed_probe = fresh_readback(native, fixed_main)
    if fixed_probe.returncode != 0:
        raise RuntimeError(f'patched main-only readback failed: {fixed_probe.stderr[-500:]}')
    if sha(fixed_main) != fixed_before:
        raise RuntimeError('patched main-only read changed file')
    verified = json.loads(fixed_probe.stdout)
    if verified['exact_arrays'] != 3:
        raise RuntimeError('patched geometry arrays not exact')

    writable = output / 'ordinary-writable.vcobj'
    shutil.copy2(fixed, writable)
    with ObjectStore.open(str(writable), author='private-demo') as store:
        if store.object_count('fiber') != 1:
            raise RuntimeError('ordinary writable open lost fiber')
    if sqlite_state(writable)['journal'] != 'wal':
        raise RuntimeError('ordinary writable open no longer uses WAL')

    failure = output / 'failed-finalization.vcobj'
    original_helper = patched.finalize_staged_db
    def fail_finalization(_):
        raise RuntimeError('injected finalization failure')
    patched.finalize_staged_db = fail_finalization
    try:
        try:
            patched.import_afv(source, failure, unbound=True,
                               author='private-demo', progress=False)
            raise RuntimeError('fault injection did not stop publication')
        except RuntimeError as error:
            if str(error) != 'injected finalization failure':
                raise
    finally:
        patched.finalize_staged_db = original_helper
    if failure.exists() or list(output.glob('.failed-finalization.vcobj-*')):
        raise RuntimeError('failed finalization published an output or left staging')
    if sha(source) != source_sha:
        raise RuntimeError('synthetic source changed')

    report = {
        'status': 'pass', 'scope': 'one deterministic synthetic two-point fiber; no CT/model',
        'python': sys.version.split()[0], 'native_origin': str(native_origin),
        'native_binary_sha256': binary_sha,
        'upstream_importer_sha256': sha(original_file),
        'patch_sha256': PATCH_SHA, 'patched_importer_sha256': sha(importer_copy),
        'source_afv_sha256': source_sha,
        'upstream': {'sqlite': baseline_state,
                     'main_only_readback_exit_code': baseline_probe.returncode,
                     'main_only_readback_error_tail': baseline_probe.stderr.strip().splitlines()[-1]
                     if baseline_probe.stderr.strip() else None},
        'patched': {'sqlite': fixed_state, 'main_only_readback': verified,
                    'main_only_sha256': fixed_before, 'sidecars_absent': True},
        'ordinary_writable_journal': 'wal',
        'injected_finalization_failure_published_nothing': True,
        'source_unchanged': True,
    }
    (output / 'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
