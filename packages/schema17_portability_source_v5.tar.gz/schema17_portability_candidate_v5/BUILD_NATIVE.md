# Exact native prerequisite build notes

The tested binary was built from Villa `8ff06f7620dcb663ed327028dbb8a0cf7e9a8198` and CMake-pinned `vc-delta3d` commit `103b502ad784df14c876100d87f601c0b6c46888`, with the `vc_reader` source from that same Villa checkout. Its `_native.cpython-314-darwin.so` SHA-256 is `ba6c142cfc866b7eee707f5949d7d78e4f4c3677b65e37298d851fa17d17783b`; core `libvc_objects.a` SHA-256 `904c55459c4e0934b46ab69c7f52865e952f765a2fe48f57df8b1637423e5522`. The recorded build and source hashes were inspected; **this source-only package was not tested on a fresh OS or with a new native compile**.

On the tested macOS 27.0.1 arm64 host: Apple Clang 21.0.0, CMake 4.4.2, Ninja 1.13.2, CPython 3.14.9, nanobind 3.1.0, NumPy 2.5.4, Apple SQLite 3.54.0, Homebrew `opencv 5.0.0_11`, `libomp 23.1.4` (OpenMP 5.1 API), `nlohmann-json 3.12.0`, selected `openssl@4 4.1.0`, `zstd 1.5.7_1`, and pkg-config were present. These are external vendor/registry dependencies. The native CMake project needs SQLite3, OpenSSL Crypto, nlohmann_json, zstd, OpenCV core, OpenMP and nanobind. A target host must supply compatible versions; the tested hashes are **not** portable binary hashes.

For a new task-owned checkout, fetch code only and select the exact commits:

```sh
git clone --filter=blob:none --no-checkout https://github.com/ScrollPrize/villa.git "$VILLA"
git -C "$VILLA" sparse-checkout init --cone
git -C "$VILLA" sparse-checkout set vc_object_store vc_reader
git -C "$VILLA" fetch origin 8ff06f7620dcb663ed327028dbb8a0cf7e9a8198
git -C "$VILLA" checkout --detach 8ff06f7620dcb663ed327028dbb8a0cf7e9a8198

git clone --filter=blob:none https://github.com/ScrollPrize/vc-delta3d.git "$DELTA3D"
git -C "$DELTA3D" checkout --detach 103b502ad784df14c876100d87f601c0b6c46888
```

The tested configuration had the following effective CMake options. Set `PYTHON`, `NATIVE_BUILD`, `VILLA`, and `DELTA3D` to task-owned paths. The Homebrew paths are macOS-specific and should be resolved from a target host's actual installed packages, not copied blindly:

```sh
cmake -S "$VILLA/vc_object_store" -B "$NATIVE_BUILD" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DVC_OBJECT_STORE_BUILD_ADAPTERS=ON \
  -DVC_OBJECT_STORE_BUILD_LINKING=ON \
  -DVC_OBJECT_STORE_BUILD_PYTHON=ON \
  -DVC_OBJECT_STORE_BUILD_TESTS=OFF \
  -DVC_OBJECT_STORE_BUILD_TOOLS=OFF \
  -DVC_OBJECT_STORE_READER_SOURCE="$VILLA/vc_reader" \
  -DFETCHCONTENT_SOURCE_DIR_VC_DELTA3D="$DELTA3D" \
  -DPython_EXECUTABLE="$PYTHON" \
  -Dnanobind_DIR="$("$PYTHON" -m nanobind --cmake_dir)" \
  -DCMAKE_PREFIX_PATH='/opt/homebrew/opt/libomp;/opt/homebrew' \
  -DOpenCV_DIR=/opt/homebrew/lib/cmake/opencv5 \
  -DOpenMP_CXX_FLAGS='-Xpreprocessor -fopenmp' \
  -DOpenMP_CXX_INCLUDE_DIR=/opt/homebrew/opt/libomp/include \
  -DOpenMP_CXX_LIB_NAMES=omp \
  -DOpenMP_omp_LIBRARY=/opt/homebrew/opt/libomp/lib/libomp.dylib
cmake --build "$NATIVE_BUILD" --target vc_object_bindings --parallel 2
```

The Python module should appear under `$NATIVE_BUILD/python/vc_object_store/`. Check that the upstream importer and root LICENSE hashes match `UPSTREAM_PINS.json`, and run the package's synthetic entry point with `--native-pythonpath "$NATIVE_BUILD/python"`. The source-only bundle does not install C++ libraries, alter system settings or copy the native binary. If the exact build cannot be reproduced on another host, report its dependency/toolchain error rather than treating the prebuilt Mac binary as portable.
